# R504TL209: backend ja frontend rautalangasta

**Versio 19.10.2026.** R504TL209 Full Stack -sovelluskehitys: Backend, 5 op.

## Aloita näin

1. Avaa `R504TL209_Deno_TypeScript_oppimateriaali.html` selaimessa. Se sisältää kaikki luvut, tehtävät ja kokonaisen koodipankin, ja toimii paikallisena tiedostona.
2. Aloita luvusta 00 ja etene perusteista pieniin kokeiluihin. Materiaali ei edellytä Deno-, TypeScript-, frontend-, SQL- tai Docker-osaamista ennakkoon.
3. Pura koko ZIP-paketti ennen komentojen suorittamista. Älä suorita lähdekoodia suoraan pakatun ZIPin sisältä.
4. Pidä tiedostojen nimet ja alihakemistot ennallaan. Komento suoritetaan aina tutoriaalissa nimetystä hakemistosta.

## Mitä paketissa on?

| Sijainti | Sisältö |
| --- | --- |
| `sisalto/00–12` | Opiskelijan luvut, harjoitukset, opettajan ohjeet ja koodipankki Markdown-lähteinä. |
| `esimerkit/00-kieli` | Ensimmäinen tulostus ja kommentoidut TypeScriptin rakennuspalikat. |
| `esimerkit/01-palvelin` | Pieni paikallinen Deno-verkkopalvelin. |
| `esimerkit/02-frontend-kokeilut` | Frontend-luvun viisi ensimmäistä pientä HTML-kokeilua kokonaisina tiedostoina. |
| `esimerkit/02-frontend` | Selaimen muistissa toimiva tehtävälista: HTML, CSS ja JavaScript. |
| `esimerkit/03-tietokanta` | SQLite-harjoitus: lisää, lue, muuta, poista ja käynnistä uudelleen. |
| `esimerkit/04-valmis` | Tehtävätaulun valmis Deno–TypeScript-backend, frontend, SQLite, autentikaatio, autorisointi ja testit. |
| `docker-postgres` | Kommentoitu PostgreSQL 17:n Docker-peruslabra ja SQL-skriptit. |
| `moodle-sivut` | Lukujen ja tehtävien HTML-sisällöt sivukohtaiseen Moodle-käyttöön. |
| `R504TL209_Deno_TypeScript_Moodle.json` | Aiemman materiaalin rakenteeseen perustuva sisältöpaketti. Lue alla oleva tuontirajaus. |
| `TARKISTUSRAPORTTI.md` | Todennetut ajot, selaimen kokeet ja avoimet ympäristörajaukset. |

## Kaksi teknistä polkua, samat vaatimukset

Yhteinen luento- ja follow-along-polku käyttää backendissä Denoa ja TypeScriptiä. Frontendin perusteet opetetaan HTML:llä, CSS:llä ja suoraan selaimessa toimivalla JavaScriptillä. Valmis pääesimerkki käyttää SQLitea, jotta ensimmäinen toimiva sovellus ei tarvitse erillistä tietokantapalvelinta.

Oman backendin saa toteuttaa esimerkiksi .NETillä, Javalla, Nodella, Rustilla tai C++:lla. Samat P1–P9-tehtävät, oma M1-designmuutos ja hyväksyntäkokeet koskevat kaikkia. Kirjaston ja HTTP-reittien nimet voivat erota, kun vastaavuus dokumentoidaan. Myös aiemman osaamisen näyttöpolulla täydennetään jokainen puuttuva ydintavoite.

Tietokannaksi riittää SQLite **tai** PostgreSQL Dockerissa. Dockerin P6-peruslabra on pakollinen myös SQLite-polulla. Erillisen Docker-labran PostgreSQL-kannan käynnistäminen ei yksin korvaa oman sovelluksen tietokantaintegraatiota. Koko backendin kontittaminen on vapaaehtoinen L2-lisätehtävä.

## Valmis esimerkki tarkistuspisteenä

Kun olet purkanut paketin ja asentanut Denon, voit tarkistaa valmiin esimerkin paketista:

```sh
# Siirry puretun paketin juuresta valmiin sovelluksen hakemistoon.
cd esimerkit/04-valmis
# Tarkista TypeScriptin tyypit ja lähdetiedostot.
deno task check
# Aja 11 varsinaista integraatiotestiä eristetyllä testidatalla.
deno task test
# Käynnistä palvelin ja pidä tämä terminaali auki.
deno task start
```

Avaa **http://localhost:8000**. Käytä keksittyä harjoitustunnusta ja uutta harjoitussalasanaa. Sammuta palvelin sen terminaalissa painamalla Ctrl+C. Ensimmäinen käynnistys luo paikallisen tietokannan `data/tehtavataulu.sqlite`. Lue luvun 07 selitykset ja esimerkin oma README ennen kuin muutat kokonaisuutta.

Mukana on lisäksi kaksi lyhyttä testitutoriaalia, `oikeuskoe_test.ts` ja `csrfkoe_test.ts`. Niiden komennot ovat luvussa 09. Valmiista ratkaisusta puuttuu tarkoituksella opiskelijan tehtäväksi annettu M1-määräpäivä. Se toteutetaan P4–P5:ssä ja koetellaan P8–P9:ssä.

## Moodle-käyttö

JSON sisältää kentät `metadata`, `defaults` ja `sections`; osioiden sisällä ovat `modules`. Rakenne vastaa aiemmassa kurssimateriaalissa käytettyä sisältöpakettia. **Tämä ei ole Moodlen natiivi `.mbz`-varmuuskopio, eikä Moodle yleensä tuo tällaista JSONia sellaisenaan.** Käyttö edellyttää kyseistä rakennetta lukevaa tuontiratkaisua. Sen kenttätuki, arviointiasetukset ja suoritusten seuranta tarkistetaan ennen käyttöä.

Vaihtoehtoisesti lisää Moodleen Sivu-aineisto ja kopioi sen HTML-editoriin sopiva `moodle-sivut`-tiedoston sisältö. Tiedostot ovat HTML-katkelmia, jotta koko dokumentin `html`-, `head`- ja `body`-elementtejä ei kopioida Moodle-sivun sisään. P1–P9-tehtävillä on omat kuvauskatkelmansa. Koodipankki on jaettu pienempiin ryhmiin. Määrittele deadlinet ja kurssin käyttöoikeudet oman toteutuksen mukaan.

Paketti ei ole muuttanut käytössä olevaa Moodle-kurssia. Ehdotettu pisteytys on P1–P9 yhteensä 100 pistettä; **kaikki ydintehtävät on hyväksyttävä erikseen**. Tuontiratkaisun tai Moodlen suoritusmerkintä ei yksin toteuta tätä pedagogista hyväksyntää. Opettaja vahvistaa kriteerit opiskelijoille ennen arvioitavaa työtä.

## Muokkaaminen ja lähteet

Muokattava asiasisältö on `sisalto`-hakemiston Markdown-tiedostoissa. Koodipankki on muodostettu lähdetiedostoista; päivitä myös se, jos muutat esimerkkejä. HTML:n koodi on tekstinä kopioitavissa, ei kuvina. HTML-opas ei tarvitse verkosta ladattavia fontteja, kuvia tai komentosarjoja. Teknisten lähteiden avaaminen ja työkalujen ensimmäinen asennus tarvitsevat verkkoyhteyden.

Teknisten ratkaisujen lähteet on linkitetty kyseiseen lukuun. Kurssin nimen ja työmäärän pohjana on aiemmin toimitettu R504TL209:n kuvaus: 5 op, 135 tuntia, joista 30 ohjattua ja 105 itsenäistä työtä. Materiaalin tuntijako ja pisteytys ovat uusia toteutusehdotuksia. Esimerkkisovellus, tehtävät ja kommentoitu koodi on laadittu tätä materiaalia varten.

Todellinen Deno- ja selainvarmennus on kuvattu tarkistusraportissa. Dockerin rakenne on tarkistettu staattisesti; konttien ajo pitää vielä varmentaa Docker-moottorilla opetuksen käyttöympäristössä.
