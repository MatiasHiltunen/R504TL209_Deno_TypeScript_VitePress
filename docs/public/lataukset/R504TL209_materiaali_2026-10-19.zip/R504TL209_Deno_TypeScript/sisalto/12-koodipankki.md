# 12 Täydellinen kommentoitu koodipankki

Tässä ovat toimituksen kokonaiset esimerkkitiedostot. Samat tiedostot löytyvät ZIP-paketista samoilla poluilla. Kopioi yhden tiedoston koko sisältö siihen nimettyyn tiedostoon; älä kopioi tiedostonimen otsikkoa tai koodilohkon rajausmerkkejä. Kommentit ovat osa opetusta ja ne saa säilyttää omassa työssä.

Suorituskomennot, oikea työhakemisto ja odotettu tulos löytyvät kyseisestä tutoriaaliluvusta. Kaikki tiedostot eivät käynnisty itsenäisesti: esimerkiksi `auth.ts` käyttää muita valmiin backendin tiedostoja. `04-valmis` käynnistetään sen omasta hakemistosta komennolla `deno task start`.

Valmis esimerkki ei sisällä opiskelijan omaa M1-määräpäiväratkaisua. Kaksi pientä testitutoriaalia täydentävät 11 integraatiotestin kokonaisuutta. PostgreSQL-peruslabra on pakollinen P6, koko sovelluksen Dockerfile on lisätehtävän L2 lähtöpohja.

## 12.1 Ensimmäinen ohjelma ja TypeScript

### `esimerkit/00-kieli/hei.ts`

````typescript
// console.log tulostaa sulkeisiin annetun tekstin terminaaliin.
console.log("Hei! Minun ohjelmani toimii.");
````

### `esimerkit/00-kieli/kieli.ts`

````typescript
// Tämä tiedosto suoritetaan Denossa, ei selaimessa. .ts tarkoittaa TypeScriptiä.
// Kaksi kauttaviivaa aloittaa kommentin: Deno ei suorita kommentin tekstiä.

// const antaa arvolle nimen. Kaksoispisteen string tarkoittaa tekstiä.
const nimi: string = "Aino";
// number tarkoittaa lukua. Luvun ympärille ei kirjoiteta lainausmerkkejä.
const tavoite: number = 3;
// let sallii muuttujan arvon vaihtamisen myöhemmin.
let tehty: number = 1;
// = sijoittaa uuden arvon; + laskee yhteen kaksi lukua.
tehty = tehty + 1;
// boolean on totuusarvo: true on tosi ja false on epätosi.
const valmis: boolean = tehty === tavoite;
// console.log kirjoittaa sulkeissa olevat arvot terminaaliin.
console.log("Opiskelija:", nimi);
// Pilkut erottavat toisistaan saman funktion argumentit eli syötteet.
console.log("Tehty:", tehty, "Tavoite:", tavoite, "Valmis:", valmis);

// type antaa tietomuodolle nimen; tässä olion nimi on Tehtava.
type Tehtava = {
  // id on tehtävän yksilöllinen numero, jonka tyyppi on number.
  id: number;
  // otsikko on tehtävän sisältö tekstinä.
  otsikko: string;
  // valmis kertoo totuusarvolla, onko tehtävä tehty.
  valmis: boolean;
}; // Aaltosulku päättää olion tyyppikuvauksen, puolipiste päättää määrittelyn.

// Hakasulut [] merkitsevät taulukkoa eli järjestettyä joukkoa arvoja.
const tehtavat: Tehtava[] = [
  // Aaltosulkujen sisällä on yksi olio, jonka kentillä on nimet ja arvot.
  { id: 1, otsikko: "Avaa terminaali", valmis: true },
  // Tämä toinen olio noudattaa samaa Tehtava-tyyppiä.
  { id: 2, otsikko: "Käynnistä palvelin", valmis: false },
]; // Hakasulku päättää taulukon.

// function määrittelee uudelleen käytettävän toiminnon nimeltä muodostaRivi.
// Parametri tehtava saa yhden Tehtava-olion; viimeinen string on paluuarvon tyyppi.
function muodostaRivi(tehtava: Tehtava): string {
  // if suorittaa lohkon vain silloin, kun sulkeiden ehto on tosi.
  if (tehtava.valmis) {
    // return palauttaa vastauksen ja lopettaa tämän funktion suorituksen.
    return tehtava.otsikko + " — tehty";
  } // Tähän päättyy ehdollinen lohko.
  // Tähän saavutaan vain, jos tehtävä ei ollut valmis.
  return tehtava.otsikko + " — kesken";
} // Tähän päättyy funktion määrittely.

// for...of käy taulukon arvot läpi yksi kerrallaan.
for (const tehtava of tehtavat) {
  // Funktiota kutsutaan sen nimellä ja sulkeilla; tehtava annetaan syötteeksi.
  console.log(muodostaRivi(tehtava));
} // Silmukan lohko päättyy; seuraava kierros ottaa seuraavan tehtävän.

// Nuolifunktio on lyhyempi tapa kirjoittaa funktio; => erottaa syötteen ja työn.
// filter tekee uuden taulukon arvoista, joille funktio palauttaa true.
// Huutomerkki ! kääntää totuusarvon: !false on true.
const keskeneraiset = tehtavat.filter((tehtava) => !tehtava.valmis);
// length kertoo taulukon alkioiden lukumäärän.
console.log("Keskeneräisiä:", keskeneraiset.length);

// unknown tarkoittaa arvoa, jonka muotoa emme vielä tiedä.
const ulkoinenArvo: unknown = "  Opi lisää  ";
// typeof tarkistaa arvon tyypin ohjelman ollessa käynnissä.
if (typeof ulkoinenArvo === "string") {
  // Vasta tarkistuksen jälkeen voimme turvallisesti käyttää tekstin trim-metodia.
  // trim poistaa tekstin alusta ja lopusta tyhjät merkit.
  console.log("Siistitty otsikko:", ulkoinenArvo.trim());
} // Ajonaikaisen tarkistuksen lohko päättyy.

// async kertoo, että funktio palauttaa lupauksen eli Promisen.
// Promise<string> lupaa valmistuessaan merkkijonon.
async function tervehdi(): Promise<string> {
  // Promise.resolve luo heti valmistuvan lupauksen; tässä ei tehdä verkkopyyntöä.
  // await odottaa tulosta jatkamatta tämän funktion seuraavalle riville ennen sitä.
  const tervehdys = await Promise.resolve("Perusteet toimivat!");
  // async-funktion palauttama arvo päätyy lupauksen tulokseksi.
  return tervehdys;
} // Funktion lohko päättyy.

// Deno sallii await-sanan moduulin ylimmällä tasolla eli myös funktioiden ulkopuolella.
console.log(await tervehdi());
````

## 12.2 Ensimmäinen Deno-palvelin

### `esimerkit/01-palvelin/main.ts`

````typescript
// Deno.serve käynnistää HTTP-palvelimen. Deno on ajossa olevan ympäristön nimi.
// Ensimmäinen argumentti on asetusolio, toinen argumentti pyyntöä käsittelevä funktio.
Deno.serve(
  {
    // hostname rajaa kuuntelun oman tietokoneen IPv4-osoitteeseen.
    hostname: "127.0.0.1",
    // port kertoo palvelimen käyttämän oven eli portin numeron.
    port: 8000,
  },
  // request sisältää yhden HTTP-pyynnön; => aloittaa käsittelijäfunktion.
  (request: Request): Response => {
    // URL tulkitsee osoitetekstin olioksi, josta voidaan lukea esimerkiksi polku.
    const url = new URL(request.url);
    // Tässä ensimmäisessä harjoituksessa sallitaan vain lukemiseen tarkoitettu GET.
    if (request.method !== "GET") {
      // 405 kertoo, että osoitteessa ei hyväksytä pyydettyä toimintoa.
      return new Response("Tässä harjoituksessa sallitaan vain GET.", {
        // status asettaa HTTP-vastauksen numerokoodin.
        status: 405,
        // Allow kertoo asiakkaalle, mitä HTTP-metodia osoite tukee.
        headers: { "Allow": "GET", "Content-Type": "text/plain; charset=utf-8" },
      });
    }
    // pathname on osoitteen polku, esimerkiksi /api/health.
    if (url.pathname === "/api/health") {
      // Response.json muuttaa olion JSON-tekstiksi ja asettaa sen sisältötyypin.
      return Response.json({ status: "ok", viesti: "Backend vastasi." });
    }
    // / tarkoittaa sivuston juurta eli osoitetta ilman erillistä polkua.
    if (url.pathname === "/") {
      // new luo uuden Response-olion, josta Deno lähettää HTTP-vastauksen selaimelle.
      return new Response("Hei! Palvelin toimii. Avaa seuraavaksi /api/health.", {
        // UTF-8 varmistaa, että ääkköset tulkitaan oikeina kirjaimina.
        headers: { "Content-Type": "text/plain; charset=utf-8" },
      });
    }
    // Jos mikään yllä oleva reitti ei täsmännyt, palautetaan selkeä 404-virhe.
    return Response.json({ error: "Osoitetta ei löydy." }, { status: 404 });
  }, // Pyyntöä käsittelevä funktio päättyy; Deno kutsuu sitä uudelleen seuraavalle pyynnölle.
); // Deno.serve-kutsu päättyy. Prosessi jää odottamaan pyyntöjä.
````

## 12.3 Frontendin pienet kokeilut

### `esimerkit/02-frontend-kokeilut/01-ensimmainen-sivu.html`

````html
<!-- DOCTYPE valitsee nykyisen HTML:n käsittelytavan. -->
<!doctype html>
<!-- html ympäröi sivun; lang kertoo tekstin olevan suomea. -->
<html lang="fi">
  <!-- head sisältää selaimen tarvitsemat asetukset. -->
  <head>
    <!-- UTF-8 saa ä- ja ö-kirjaimet näkymään oikein. -->
    <meta charset="utf-8">
    <!-- viewport sovittaa sivun laitteen leveyteen. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title näkyy selaimen välilehdessä. -->
    <title>Ensimmäinen harjoitukseni</title>
  </head>
  <!-- body sisältää käyttäjälle näkyvän sivun. -->
  <body>
    <!-- main kertoo, mikä alue on sivun pääsisältö. -->
    <main>
      <!-- h1 on koko sivun pääotsikko. -->
      <h1>Minun tehtävätauluni</h1>
      <!-- p muodostaa yhden tekstikappaleen. -->
      <p>Tässä harjoituksessa opin tekemään verkkosivun.</p>
      <!-- h2 aloittaa pääotsikon alaisen sisältöalueen. -->
      <h2>Tämän päivän tavoite</h2>
      <!-- Tämä p on toinen tekstikappale. -->
      <p>Osaan tallentaa HTML-tiedoston ja avata sen selaimessa.</p>
    </main>
  </body>
</html>
````

### `esimerkit/02-frontend-kokeilut/02-tyylit/index.html`

````html
<!-- Nykyisen HTML:n asiakirja. -->
<!doctype html>
<!-- Sivun kieli on suomi. -->
<html lang="fi">
  <!-- Sivun asetusten alku. -->
  <head>
    <!-- UTF-8 määrittää tekstin merkistön. -->
    <meta charset="utf-8">
    <!-- Näkymän leveys seuraa laitteen leveyttä. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Välilehden nimi. -->
    <title>CSS-kokeilu</title>
    <!-- rel kertoo tyylitiedostosta; href löytää saman kansion styles.css:n. -->
    <link rel="stylesheet" href="styles.css">
  </head>
  <!-- Käyttäjälle näkyvä sisältö alkaa. -->
  <body>
    <!-- main on sivun pääsisältö. -->
    <main>
      <!-- h1 on pääotsikko. -->
      <h1>Tehtävätaulun ulkoasu</h1>
      <!-- p on tekstikappale; class yhdistää sen CSS:n kortti-luokkaan. -->
      <p class="kortti">Tämä teksti on valkoisella kortilla.</p>
    </main>
  </body>
</html>
````

### `esimerkit/02-frontend-kokeilut/02-tyylit/styles.css`

````css
/* body valitsee sivun näkyvän sisällön juurielementin. */
body {
  /* Käytetään laitteesta löytyvää selkeää kirjasinta. */
  font-family: system-ui, sans-serif;
  /* Riviväli on 1,6 kertaa kirjasimen koko. */
  line-height: 1.6;
  /* Tumma teksti erottuu vaaleasta taustasta. */
  color: #172b3a;
  /* Tausta on vaalea siniharmaa. */
  background: #f4f7fa;
  /* Sisältö saa yhden peruskirjasinkoon verran tilaa reunoille. */
  padding: 1rem;
}

/* main valitsee pääsisällön alueen. */
main {
  /* Rivistä ei tehdä hyvin pitkää edes suurella näytöllä. */
  max-width: 44rem;
  /* Automaattiset sivumarginaalit keskittävät alueen. */
  margin-inline: auto;
}

/* Piste valitsee kaikki elementit, joilla on class="kortti". */
.kortti {
  /* Kortin tausta on valkoinen. */
  background: #ffffff;
  /* Reuna on yhden pikselin yhtenäinen tumma viiva. */
  border: 1px solid #586577;
  /* Padding jättää tilaa sisällön ja reunuksen väliin. */
  padding: 1rem;
}
````

### `esimerkit/02-frontend-kokeilut/03-painike/app.js`

````javascript
// Etsitään sivulta id="tervehdys" ja annetaan viittaukselle nimi painike.
const painike = document.querySelector("#tervehdys");
// Etsitään kappale, jonka tekstiä haluamme vaihtaa.
const viesti = document.querySelector("#viesti");

// Funktion sisällä oleva koodi suoritetaan vasta kun funktiota kutsutaan.
function tervehdi() {
  // Kirjoitetaan kappaleeseen uusi teksti turvallisesti tekstinä.
  viesti.textContent = "Hei! Painike ja JavaScript toimivat.";
}

// Click-tapahtuman tullessa selain kutsuu tervehdi-funktiota.
painike.addEventListener("click", tervehdi);
````

### `esimerkit/02-frontend-kokeilut/03-painike/index.html`

````html
<!-- Valitaan nykyinen HTML. -->
<!doctype html>
<!-- Sivun kieli on suomi. -->
<html lang="fi">
  <!-- Asetusten alku. -->
  <head>
    <!-- Merkistö on UTF-8. -->
    <meta charset="utf-8">
    <!-- Näkymä sovitetaan laitteen leveyteen. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Nimi selaimen välilehdelle. -->
    <title>Painikekokeilu</title>
    <!-- src löytää ohjelman; defer odottaa sivun rakenteen valmistumista. -->
    <script src="app.js" defer></script>
  </head>
  <!-- Näkyvän sivun alku. -->
  <body>
    <!-- main sisältää pääsisällön. -->
    <main>
      <!-- h1 nimeää koko kokeilun. -->
      <h1>Ensimmäinen toiminto</h1>
      <!-- id yhdistää painikkeen ohjelmaan; type tekee tavallisen toimintopainikkeen. -->
      <button id="tervehdys" type="button">Näytä tervehdys</button>
      <!-- id löytyy ohjelmasta; role ilmoittaa muuttuvan tekstin ruudunlukijalle. -->
      <p id="viesti" role="status">Odota painikkeen painamista.</p>
    </main>
  </body>
</html>
````

### `esimerkit/02-frontend-kokeilut/04-lomake/app.js`

````javascript
// Etsitään lomake sen id:n avulla.
const lomake = document.querySelector("#lomake");
// Etsitään tekstikenttä, jonka value sisältää kirjoitetun tekstin.
const kentta = document.querySelector("#tehtava");
// Etsitään onnistuneen tuloksen näyttöpaikka.
const tulos = document.querySelector("#tulos");
// Etsitään virheiden näyttöpaikka.
const virhe = document.querySelector("#virhe");

// Submit syntyy lomakkeen lähettämisestä painikkeella tai Enterillä.
lomake.addEventListener("submit", (event) => {
  // Estetään oletuslähetys, jotta selain pysyy tällä sivulla.
  event.preventDefault();
  // Luetaan kentän teksti ja poistetaan alun sekä lopun välilyönnit.
  const nimi = kentta.value.trim();
  // Length kertoo merkkijonon pituuden; nolla tarkoittaa tyhjää tekstiä.
  if (nimi.length === 0) {
    // Kerrotaan täsmällinen virhe tekstinä.
    virhe.textContent = "Kirjoita tehtävän nimi. Pelkät välilyönnit eivät riitä.";
    // Palautetaan kohdistus korjattavaan kenttään.
    kentta.focus();
    // Lopetetaan käsittely ennen onnistumisviestiä.
    return;
  }
  // Poistetaan edellisen yrityksen virhe.
  virhe.textContent = "";
  // Käyttäjän kirjoitus lisätään tekstinä, ei HTML-koodina.
  tulos.textContent = `Seuraava tehtäväsi: ${nimi}`;
});
````

### `esimerkit/02-frontend-kokeilut/04-lomake/index.html`

````html
<!-- Nykyisen HTML:n asiakirja. -->
<!doctype html>
<!-- lang kertoo sivun kielen. -->
<html lang="fi">
  <!-- Selaimen asetukset alkavat. -->
  <head>
    <!-- Merkistö tukee suomen kirjaimia. -->
    <meta charset="utf-8">
    <!-- Sivun leveys sovitetaan laitteen näkymään. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Välilehden otsikko. -->
    <title>Lomakekokeilu</title>
    <!-- src löytää ohjelman; defer odottaa HTML:n valmistumista. -->
    <script src="app.js" defer></script>
  </head>
  <!-- Sivulla näkyvä sisältö alkaa. -->
  <body>
    <!-- main nimeää sivun pääsisällön alueen. -->
    <main>
      <!-- h1 on sivun pääotsikko. -->
      <h1>Nimeä seuraava tehtävä</h1>
      <!-- form kokoaa lomakkeen; id antaa sille tunnisteen ohjelmaa varten. -->
      <form id="lomake">
        <!-- label näkyy koko ajan; for yhdistää nimen oikeaan kenttään. -->
        <label for="tehtava">Tehtävän nimi (pakollinen)</label>
        <!-- id yhdistää labelin; name nimeää tiedon; text on kenttätyyppi. -->
        <!-- required tekee kentästä pakollisen; maxlength rajaa pituuden. -->
        <input id="tehtava" name="title" type="text" required maxlength="200">
        <!-- submit lähettää lomakkeen myös kentästä Enteriä painettaessa. -->
        <button type="submit">Näytä tehtävä</button>
      </form>
      <!-- id löytyy koodista; role ilmoittaa tekstin muutokset rauhallisesti. -->
      <p id="tulos" role="status">Et ole vielä antanut tehtävää.</p>
      <!-- role="alert" ilmoittaa virheen heti; alue on jo valmiina DOMissa. -->
      <p id="virhe" role="alert"></p>
    </main>
  </body>
</html>
````

### `esimerkit/02-frontend-kokeilut/05-lista/app.js`

````javascript
// Taulukon sisällä on kaksi oliota; jokainen olio kuvaa yhtä tehtävää.
const tehtavat = [
  // Id erottaa tehtävän; title on nimi; done on valmiudesta kertova totuusarvo.
  { id: 1, title: "Avaa HTML-tiedosto", done: true },
  // Toisella tehtävällä on oma id, nimi ja tila.
  { id: 2, title: "Kokeile lomaketta", done: false },
];
// Etsitään HTML:n tyhjä ul-elementti.
const lista = document.querySelector("#lista");

// Funktio tekee ohjelman tiedoista näkyviä elementtejä.
function piirra() {
  // Poistetaan mahdollinen edellinen sisältö, jotta rivejä ei tule kahteen kertaan.
  lista.replaceChildren();
  // Käydään kaikki taulukon tehtävät läpi yksi kerrallaan.
  for (const tehtava of tehtavat) {
    // Luodaan yksi li-elementti; sitä ei vielä ole liitetty näkyvälle sivulle.
    const rivi = document.createElement("li");
    // Tila kerrotaan sanoin; käyttäjän nimi kirjoitetaan turvallisesti tekstinä.
    rivi.textContent = `${tehtava.title}: ${tehtava.done ? "valmis" : "kesken"}`;
    // Append liittää uuden rivin ul-elementtiin, jolloin selain näyttää sen.
    lista.append(rivi);
  }
}

// Kutsutaan funktiota, jotta lista piirretään sivun avaamisen yhteydessä.
piirra();
````

### `esimerkit/02-frontend-kokeilut/05-lista/index.html`

````html
<!-- Nykyinen HTML. -->
<!doctype html>
<!-- Asiakirjan kieli on suomi. -->
<html lang="fi">
  <!-- Asetusten alku. -->
  <head>
    <!-- Suomen kirjaimia tukeva merkistö. -->
    <meta charset="utf-8">
    <!-- Leveys seuraa laitteen näkymää. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Selaimen välilehdessä näkyvä nimi. -->
    <title>Taulukosta listaksi</title>
    <!-- Ohjelma haetaan samasta kansiosta ja ajetaan HTML:n jälkeen. -->
    <script src="app.js" defer></script>
  </head>
  <!-- Näkyvä sisältö alkaa. -->
  <body>
    <!-- main on sivun pääsisältö. -->
    <main>
      <!-- h1 nimeää harjoituksen. -->
      <h1>Tehtävät ohjelman muistista</h1>
      <!-- ul on järjestämätön lista; id auttaa ohjelmaa löytämään sen. -->
      <ul id="lista"></ul>
    </main>
  </body>
</html>
````

## 12.4 Frontend selaimen muistissa

### `esimerkit/02-frontend/index.html`

````html
<!-- DOCTYPE valitsee nykyisen HTML:n käsittelytavan. -->
<!doctype html>
<!-- html on sivun juuri; lang kertoo ruudunlukijalle tekstin olevan suomea. -->
<html lang="fi">
  <!-- head sisältää selaimelle tarkoitetut asetukset. -->
  <head>
    <!-- UTF-8 näyttää myös suomen ä- ja ö-kirjaimet. -->
    <meta charset="utf-8">
    <!-- viewport sovittaa sivun laitteen leveyteen ja sallii zoomauksen. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title näkyy selaimen välilehdessä. -->
    <title>Tehtävätaulu – selaimen muistissa toimiva harjoitus</title>
    <!-- rel kertoo CSS-tyylitiedostosta; href on suhteellinen polku saman kansion tiedostoon. -->
    <link rel="stylesheet" href="styles.css">
    <!-- src löytää saman kansion ohjelman; defer odottaa, että HTML on luettu. -->
    <script src="app.js" defer></script>
  </head>
  <!-- body sisältää käyttäjälle näkyvän sivun. -->
  <body>
    <!-- main on sivun pääsisältö. -->
    <main>
      <!-- h1 on koko sivun pääotsikko. -->
      <h1>Oma tehtävälista</h1>
      <!-- p on kappale; strong painottaa tärkeää tietoa myös merkityksen tasolla. -->
      <p><strong>Harjoitus: tiedot ovat vain tämän välilehden muistissa.</strong> Sivun lataaminen uudelleen tyhjentää listan. Tietoja ei lähetetä palvelimelle.</p>
      <!-- noscript neuvoo, jos JavaScript on estetty. -->
      <noscript>Ota JavaScript käyttöön, jotta voit kokeilla tehtävälistaa.</noscript>
      <!-- form kokoaa syötteen; id antaa sille nimen JavaScriptin hakua varten. -->
      <form id="task-form">
        <!-- label antaa kentälle näkyvän nimen; for vastaa inputin id:tä. -->
        <label for="task-title">Uusi tehtävä (pakollinen)</label>
        <!-- input on syötekenttä; id yhdistää labelin; name nimeää arvon; type on teksti; required ja maxlength rajaavat syötteen. -->
        <input id="task-title" name="title" type="text" required maxlength="200">
        <!-- button on painike; submit lähettää lomakkeen myös Enterillä. -->
        <button type="submit">Lisää tehtävä</button>
      </form>
      <!-- id löytyy koodista; role ja aria-live ilmoittavat muuttuvan tekstin; aria-atomic lukee koko viestin. -->
      <p id="status" role="status" aria-live="polite" aria-atomic="true">Lista on tyhjä. Lisää ensimmäinen tehtävä.</p>
      <!-- id löytyy koodista; role="alert" ilmoittaa tekstinä näytettävän virheen heti. -->
      <p id="error" role="alert"></p>
      <!-- h2 on pääotsikon alainen sisältöotsikko. -->
      <h2>Tehtävät</h2>
      <!-- ul on järjestämätön lista; id yhdistää sen ohjelmaan. -->
      <ul id="task-list"></ul>
    </main>
  </body>
</html>
````

### `esimerkit/02-frontend/styles.css`

````css
/* Tähti valitsee jokaisen HTML-elementin. */
* {
  /* Mitattava leveys sisältää myös täytteen ja reunuksen. */
  box-sizing: border-box;
}

/* body-sääntö antaa koko sivun oletustyylit. */
body {
  /* Käytetään laitteen valmiita kirjasimia. */
  font-family: system-ui, sans-serif;
  /* Tekstin koko seuraa käyttäjän selaimeen valitsemaa peruskokoa. */
  font-size: 1rem;
  /* Ilmava riviväli helpottaa lukemista. */
  line-height: 1.6;
  /* Tumma teksti erottuu vaaleasta taustasta. */
  color: #172b3a;
  /* Tausta on vaalea. */
  background: #f4f7fa;
  /* Selaimen oletusmarginaali korvataan omalla täytteellä. */
  margin: 0;
  /* Sisältö ei osu näytön reunoihin. */
  padding: 1rem;
  /* Pitkät sanat saavat katketa kapeassa näkymässä. */
  overflow-wrap: anywhere;
}

/* main on sivun pääsisällön alue. */
main {
  /* Luettavuutta helpottava enimmäisleveys ei pakota sivua pienellä näytöllä leveäksi. */
  max-width: 46rem;
  /* Automaattiset vasen ja oikea marginaali keskittävät sisällön. */
  margin-inline: auto;
}

/* Jokainen label saa näkyvän oman rivin. */
label {
  /* block aloittaa oman rivin. */
  display: block;
  /* Nimi erottuu lihavoinnilla. */
  font-weight: 650;
  /* Nimen yläpuolelle jää tilaa. */
  margin-top: 0.75rem;
}

/* Syötteillä ja painikkeilla on yhteisiä ulkoasuominaisuuksia. */
input,
button {
  /* Peritään sivun luettava kirjasin ja tekstikoko. */
  font: inherit;
  /* Vähintään 44 pikselin korkeus helpottaa osoittamista. */
  min-height: 44px;
  /* Sisältö ei osu reunukseen. */
  padding: 0.5rem 0.75rem;
  /* Selkeä reunus erottaa kentät ja painikkeet taustasta. */
  border: 2px solid #586577;
  /* Alapuolen väli erottaa seuraavan toiminnon. */
  margin-bottom: 0.5rem;
}

/* Tavallinen syötekenttä käyttää käytettävissä olevan leveyden. */
input {
  /* Leveys ei ylitä vanhempaa box-sizing-säännön ansiosta. */
  width: 100%;
  /* Syöttöteksti on tummaa. */
  color: #172b3a;
  /* Kentän pohja on valkoinen. */
  background: #ffffff;
}

/* Painikkeen tumma tausta ja vaalea teksti erottuvat toisistaan. */
button {
  /* Painikkeen tausta on tumma sinivihreä. */
  background: #174e5c;
  /* Painikkeen teksti on valkoista. */
  color: #ffffff;
  /* Osoitin ilmaisee hiirellä käytettävän toiminnon. */
  cursor: pointer;
  /* Pitkä painiketeksti saa mennä usealle riville. */
  white-space: normal;
}

/* Näppäimistökohdistus näkyy selvästi kaikissa kohteissa. */
:focus-visible {
  /* Sininen paksu ääriviiva kertoo, mikä kohde on aktiivinen. */
  outline: 3px solid #005fcc;
  /* Viiva siirtyy hieman irti elementin reunasta. */
  outline-offset: 3px;
}

/* id-valitsin alkaa #-merkillä; tämä koskee vain virhealuetta. */
#error {
  /* Virhe näkyy tummanpunaisena mutta kerrotaan aina myös sanoin. */
  color: #7e1720;
  /* Lihavointi auttaa huomaamaan virhetekstin. */
  font-weight: 650;
}

/* Listan tehtävät erotetaan toisistaan. */
li {
  /* Jokaisen tehtävän yläreunassa on viiva. */
  border-top: 1px solid #718096;
  /* Sisältö ja reunaviiva erotetaan sisätäytteellä. */
  padding-block: 0.75rem;
  /* Tehtävien alle jätetään väliä. */
  margin-bottom: 0.75rem;
}
````

### `esimerkit/02-frontend/app.js`

````javascript
// Tämä ohjelma toimii kokonaan selaimessa eikä tee fetch-pyyntöjä tai tallenna tiedostoon.
// const antaa muuttujalle nimen; document kuvaa selaimen muodostamaa sivua.
const form = document.querySelector("#task-form");
// #task-title etsii elementin, jonka HTML:n id on task-title.
const titleInput = document.querySelector("#task-title");
// Tähän ul-elementtiin lisätään tehtävien li-elementit.
const list = document.querySelector("#task-list");
// Tilaviestille on oma p-elementtinsä.
const status = document.querySelector("#status");
// Virheviestille on HTML:ssä valmiina role="alert"-alue.
const error = document.querySelector("#error");

// let sallii muuttujan uuden arvon; [] on aluksi tyhjä tehtävätaulukko.
let tasks = [];
// Seuraava uusi tehtävä saa tämän numerotunnisteen.
let nextId = 1;

// Funktio kokoaa useita rivejä yhdeksi nimellä kutsuttavaksi toiminnoksi.
function announce(message) {
  // textContent kirjoittaa tekstin sellaisenaan eikä tulkitse käyttäjän HTML-merkkejä.
  status.textContent = message;
  // Edellisen toiminnon virhe poistetaan onnistumisen yhteydessä.
  error.textContent = "";
}

// render rakentaa näkymän tasks-taulukon tämänhetkisistä tiedoista.
function render(focusId = "task-title") {
  // Poistetaan edellinen lista; ilman argumentteja replaceChildren jättää sen tyhjäksi.
  list.replaceChildren();
  // for...of käy taulukon tehtävät läpi yksi kerrallaan.
  for (const task of tasks) {
    // document.createElement luo uuden HTML-elementin muistiin.
    const item = document.createElement("li");
    // p on tehtävän nimen ja tilan sisältävä tekstikappale.
    const description = document.createElement("p");
    // Kysymysmerkki valitsee kahdesta tekstistä: true antaa valmis, false antaa kesken.
    description.textContent = `${task.title} (${task.done ? "valmis" : "kesken"})`;
    // Luodaan oikea painike tehtävän tilan vaihtamiseen.
    const toggle = document.createElement("button");
    // button-tyyppi tekee toiminnon, joka ei lähetä lomaketta.
    toggle.type = "button";
    // Yksilöllinen id auttaa palauttamaan kohdistuksen listan uudelleenrakennuksen jälkeen.
    toggle.id = `toggle-${task.id}`;
    // Painikkeen näkyvä nimi kertoo toiminnon ja kohteen.
    toggle.textContent = task.done ? `Merkitse keskeneräiseksi: ${task.title}` : `Merkitse valmiiksi: ${task.title}`;
    // addEventListener liittää tapahtumaan suoritettavan funktion.
    toggle.addEventListener("click", () => {
      // Huutomerkki vaihtaa totuusarvon: true muuttuu falseksi ja false trueksi.
      task.done = !task.done;
      // Piirretään muuttunut lista ja palautetaan kohdistus samaan toimintoon.
      render(`toggle-${task.id}`);
      // Ilmoitetaan muutos myös sanoina tilaviestissä.
      announce(task.done ? "Tehtävä merkitty valmiiksi." : "Tehtävä merkitty keskeneräiseksi.");
    });
    // Form antaa jokaiselle tehtävälle oman nimenmuokkauslomakkeen.
    const editForm = document.createElement("form");
    // Lomakkeelle annetaan sen tehtävän nimeen perustuva saavutettava nimi.
    editForm.setAttribute("aria-label", `Muokkaa tehtävää ${task.title}`);
    // Label antaa muokkauskentälle näkyvän nimen.
    const editLabel = document.createElement("label");
    // htmlFor on JavaScriptin nimi HTML:n for-attribuutille.
    editLabel.htmlFor = `edit-${task.id}`;
    // Pakollisuutta ei ilmaista pelkällä värillä tai tähdellä.
    editLabel.textContent = "Tehtävän nimi (pakollinen)";
    // Input kerää muokatun nimen.
    const editInput = document.createElement("input");
    // Id vastaa labelin htmlFor-arvoa.
    editInput.id = `edit-${task.id}`;
    // Text on tavallinen tekstikenttä.
    editInput.type = "text";
    // Name nimeää kentän lomakkeen sisällä.
    editInput.name = "title";
    // Nykyinen tehtävän nimi asetetaan muokattavaksi arvoksi.
    editInput.value = task.title;
    // Required saa selaimen tarkistamaan, ettei kenttä ole tyhjä.
    editInput.required = true;
    // Enintään 200 merkkiä riittää tämän harjoituksen tehtävän nimeen.
    editInput.maxLength = 200;
    // Luodaan muokkauslomakkeen painike.
    const save = document.createElement("button");
    // Submit käynnistää form-elementin submit-tapahtuman myös Enterillä.
    save.type = "submit";
    // Painikkeen nimi kertoo toiminnon.
    save.textContent = "Tallenna nimi";
    // Kuunnellaan juuri tämän tehtävän lomakkeen lähetystä.
    editForm.addEventListener("submit", (event) => {
      // Estetään selaimen oletuslähetys, joka lataisi sivun ja tyhjentäisi muistimme.
      event.preventDefault();
      // value lukee kentän tekstin; trim poistaa vahingossa syötetyt reunavälilyönnit.
      const newTitle = editInput.value.trim();
      // Pelkät välilyönnit eivät ole kelvollinen nimi.
      if (newTitle.length === 0) {
        // Virhe kerrotaan tekstinä olemassa olevassa alert-alueessa.
        error.textContent = "Kirjoita tehtävän nimi. Pelkät välilyönnit eivät riitä.";
        // Kohdistetaan kenttä, joka käyttäjän täytyy korjata.
        editInput.focus();
        // Return lopettaa tämän käsittelijän ennen tallennusta.
        return;
      }
      // Päivitetään olemassa olevan tehtäväolion title-ominaisuus.
      task.title = newTitle;
      // Rakennetaan päivitetty lista ja kohdistetaan saman tehtävän uusi kenttä.
      render(`edit-${task.id}`);
      // Kerrotaan, että muutos on tehty tämän välilehden muistissa.
      announce("Tehtävän nimi muutettu selaimen muistissa.");
    });
    // Lisätään lomakkeeseen label, kenttä ja tallennuspainike tässä järjestyksessä.
    editForm.append(editLabel, editInput, save);
    // Luodaan poistopainike.
    const remove = document.createElement("button");
    // Painike ei ole lomakkeen lähetyspainike.
    remove.type = "button";
    // Tehtävän nimi erottaa tämän poistopainikkeen muista.
    remove.textContent = `Poista tehtävä: ${task.title}`;
    // Liitetään poistoon click-tapahtuman käsittelijä.
    remove.addEventListener("click", () => {
      // globalThis viittaa selaimen yleiseen ympäristöön; confirm palauttaa false, jos käyttäjä peruuttaa.
      if (!globalThis.confirm(`Poistetaanko tehtävä ”${task.title}”?`)) return;
      // Filter tekee uuden taulukon, jossa ovat vain muut tunnisteet kuin poistettava.
      tasks = tasks.filter((oldTask) => oldTask.id !== task.id);
      // Poistettua painiketta ei enää ole; oletuskohdistus siirtyy uuden tehtävän kenttään.
      render();
      // Myös tyhjäksi tullut lista saa sanallisen tilan.
      announce(tasks.length === 0 ? "Tehtävä poistettu. Lista on nyt tyhjä." : "Tehtävä poistettu.");
    });
    // Kootaan yhden tehtävän osat li-elementtiin.
    item.append(description, toggle, editForm, remove);
    // Lisätään valmis li näkyvälle sivulle ul-elementin lapseksi.
    list.append(item);
  }
  // Haku löytää saman id:n myös juuri rakennetusta uudesta näkymästä.
  const focused = document.getElementById(focusId);
  // Ehto estää focus-kutsun, jos elementtiä ei löytyisi.
  if (focused) focused.focus();
}

// Lomakkeen submit toimii painikkeella sekä Enter-näppäimellä.
form.addEventListener("submit", (event) => {
  // Oletuslähetyksen estäminen pitää harjoituksen samalla sivulla.
  event.preventDefault();
  // Luetaan käyttäjän teksti ja poistetaan turhat reunavälit.
  const title = titleInput.value.trim();
  // Selain estää tyhjän kentän; tässä tarkistetaan lisäksi pelkät välilyönnit.
  if (title.length === 0) {
    // Kerrotaan täsmällinen korjausohje tekstinä.
    error.textContent = "Kirjoita tehtävän nimi. Pelkät välilyönnit eivät riitä.";
    // Palautetaan näppäimistön kohdistus korjattavaan kenttään.
    titleInput.focus();
    // Lopetetaan käsittelijä lisäämättä tehtävää.
    return;
  }
  // Push lisää olion taulukkoon; olion id, title ja done ovat tehtävän ominaisuuksia.
  tasks.push({ id: nextId, title, done: false });
  // Seuraavaa tehtävää varten kasvatetaan tunnistetta yhdellä.
  nextId = nextId + 1;
  // Reset tyhjentää lomakkeen takaisin HTML:n alkuarvoihin.
  form.reset();
  // Näytetään muuttunut lista ja kohdistetaan kenttä seuraavaa tehtävää varten.
  render();
  // Tilaviesti kertoo sekä onnistumisesta että listan määrästä.
  announce(`Tehtävä lisätty. Tehtäviä yhteensä ${tasks.length}.`);
});
````

## 12.5 SQLite ensimmäistä kertaa

### `esimerkit/03-tietokanta/db_demo.ts`

````typescript
// import tuo kirjastosta nimetyn toiminnon käyttöömme tässä tiedostossa.
// node:sqlite on Denon mukana tuleva SQLite-yhteensopivuusmoduuli: Nodea ei asenneta.
import { DatabaseSync } from "node:sqlite";

// new avaa tietokannan ja luo tiedoston, jos sitä ei vielä ole.
// Polku alkaa pisteellä, joten se on suhteessa terminaalin nykyiseen hakemistoon.
const db = new DatabaseSync("./harjoitus.sqlite");

// try...finally varmistaa, että yhteys suljetaan myös virheen sattuessa.
try {
  // exec suorittaa kiinteän SQL-lauseen ilman käyttäjältä tulevaa sisältöä.
  // PRAGMA on SQLite-asetus; foreign_keys ottaa viiteavaimien valvonnan käyttöön.
  db.exec("PRAGMA foreign_keys = ON;");
  // Monirivinen merkkijono kirjoitetaan takamerkkien eli `-merkkien väliin.
  db.exec(`
    -- CREATE TABLE luo taulun. IF NOT EXISTS säilyttää jo olevan taulun ja sen tiedot.
    CREATE TABLE IF NOT EXISTS notes (
      -- INTEGER PRIMARY KEY antaa jokaiselle riville yksilöllisen numeron.
      id INTEGER PRIMARY KEY,
      -- TEXT on tekstiä, NOT NULL vaatii arvon ja CHECK rajaa sallitun pituuden.
      title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 200),
      -- SQLite käyttää tässä totuusarvoon 0:aa tai 1:tä; DEFAULT 0 on alkuarvo.
      done INTEGER NOT NULL DEFAULT 0 CHECK(done IN (0, 1))
    );
  `);
  // Deno.args sisältää tiedostonimen jälkeiset komentoriviargumentit.
  // ?? antaa oletusarvon, jos pyydettyä alkiota ei ole.
  const command = Deno.args[0] ?? "list";
  // if valitsee lisäyskomennon perusteella suoritettavan lohkon.
  if (command === "add") {
    // slice ottaa argumentit indeksistä 1 alkaen; join yhdistää sanat välilyönnein.
    const title = Deno.args.slice(1).join(" ").trim();
    // Tarkistamme rajat myös ennen SQL-kyselyä, jotta virhe on opiskelijalle selkeä.
    if (title.length < 1 || title.length > 200) {
      // Error on virheolio; throw keskeyttää tämän työn ja siirtää virheen kutsujalle.
      throw new Error("Otsikon pituuden pitää olla 1–200 merkkiä.");
    }
    // ? on paikkamerkki. Teksti annetaan run-metodille erillisenä arvona.
    // Tämän vuoksi tekstin heittomerkki ei voi muuttaa SQL-lauseen rakennetta.
    const result = db.prepare("INSERT INTO notes (title) VALUES (?)").run(title);
    // lastInsertRowid kertoo juuri lisätyn rivin tunnisteen.
    console.log("Lisätty tunnisteella", result.lastInsertRowid);
  } else if (command === "done" || command === "delete") {
    // Number muuttaa argumentin numeroksi; puuttuvasta arvosta tulee NaN.
    const id = Number(Deno.args[1]);
    // Turvallinen kokonaisluku on kokonaisluku JavaScriptin tarkasti esitettävällä alueella.
    if (!Number.isSafeInteger(id) || id < 1) {
      // Selkeä virhe auttaa korjaamaan komentoa arvaamisen sijaan.
      throw new Error("Anna positiivinen kokonaislukutunniste, esimerkiksi done 1.");
    }
    // Ehdollinen lauseke ? : valitsee kahdesta kiinteästä SQL-lauseesta yhden.
    const sql = command === "done"
      // UPDATE muuttaa olemassa olevan rivin; WHERE rajaa muutoksen yhteen tunnisteeseen.
      ? "UPDATE notes SET done = 1 WHERE id = ?"
      // DELETE poistaa rivin; parametrin käyttö rajaa kohteen täsmällisesti.
      : "DELETE FROM notes WHERE id = ?";
    // Myös numeerinen tunniste annetaan paikkamerkkiin erillään SQL-tekstistä.
    const result = db.prepare(sql).run(id);
    // changes kertoo muutettujen rivien määrän, ei koko taulun kokoa.
    console.log("Muutettuja rivejä:", result.changes);
  } else if (command !== "list") {
    // Tuntematon komento ei saa vahingossa tehdä muuta tietokantatyötä.
    throw new Error("Komennot: list, add Otsikko, done TUNNISTE, delete TUNNISTE.");
  }
  // SELECT hakee rivejä; ORDER BY pitää tulostusjärjestyksen samana.
  const rows = db.prepare("SELECT id, title, done FROM notes ORDER BY id").all();
  // console.table näyttää haetut rivit luettavana taulukkona terminaalissa.
  console.table(rows);
} finally {
  // close vapauttaa tietokantayhteyden. Tiedosto säilyy seuraavaa suoritusta varten.
  db.close();
}
````

### `esimerkit/03-tietokanta/.gitignore`

````text
# Tietokanta syntyy db_demo.ts-ohjelman ajossa; harjoitusdataa ei siirretä Gitiin.
harjoitus.sqlite
# Mahdolliset SQLite-tietokannan apuosat kuuluvat samaan paikalliseen dataan.
harjoitus.sqlite-*
````

## 12.6 Valmiin sovelluksen backend

### `esimerkit/04-valmis/01_create_schema.sql`

````sql
-- Migraatio on tietokannan rakenteen numeroitu muutos. Tämä on muutos numero 1.
-- db.ts suorittaa tämän tiedoston vain, jos muutosta 1 ei ole vielä kirjattu.
-- Älä muuta jo käytetyn migraation sisältöä. Tee myöhemmin uusi migraatio.

-- CREATE TABLE luo taulun: yksi rivi vastaa yhtä käyttäjää.
CREATE TABLE users (
  -- INTEGER PRIMARY KEY antaa riville yksilöllisen kokonaislukutunnuksen.
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  -- NOT NULL vaatii arvon; UNIQUE estää saman sähköpostin kahdesti.
  email TEXT NOT NULL UNIQUE CHECK (length(email) BETWEEN 3 AND 254),
  -- Tallennamme salasanasta hitaan PBKDF2-tiivisteen, emme salasanaa.
  password_hash TEXT NOT NULL CHECK (length(password_hash) = 64),
  -- Salt on käyttäjäkohtainen satunnainen suola, joka ei ole salaisuus.
  password_salt TEXT NOT NULL CHECK (length(password_salt) = 32),
  -- Myös tiivistyksen työmäärä tallennetaan mahdollista myöhempää muutosta varten.
  password_iterations INTEGER NOT NULL CHECK (password_iterations >= 600000),
  -- DEFAULT antaa oletuksen; CHECK sallii vain nämä kaksi roolia.
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  -- UTC-aika tallennetaan tekstinä muodossa 2026-10-19T12:34:56.123Z.
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Projektin omistaja on yksi käyttäjä; käyttäjällä voi olla monta projektia.
CREATE TABLE projects (
  -- Projektilla on oma tunnus: se ei ole sama asia kuin omistajan tunnus.
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  -- FOREIGN KEY -viittaus estää viittauksen käyttäjään, jota ei ole.
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  -- Myös tietokanta torjuu tyhjän tai liian pitkän nimen.
  title TEXT NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 120),
  -- DEFAULT laskee ajan, kun uusi projekti lisätään.
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Tehtävä kuuluu yhteen projektiin; projektiin voi kuulua monta tehtävää.
CREATE TABLE tasks (
  -- PRIMARY KEY yksilöi juuri tämän tehtävän.
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  -- CASCADE poistaa tehtävät samalla, kun niiden projekti poistetaan.
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  -- Tehtävän nimi saa olla projektin nimeä pidempi: enintään 200 merkkiä.
  title TEXT NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 200),
  -- SQLitessä käytämme kokonaislukuja 0 = kesken ja 1 = valmis.
  done INTEGER NOT NULL DEFAULT 0 CHECK (done IN (0, 1)),
  -- Tekstimuotoinen UTC-aika helpottaa ajan lähettämistä JSON-vastauksessa.
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Istunto yhdistää satunnaisen kirjautumistunnisteen yhteen käyttäjään.
CREATE TABLE sessions (
  -- Tallennamme tunnisteesta vain SHA-256-tiivisteen. Raaka tunniste on evästeessä.
  token_hash TEXT PRIMARY KEY NOT NULL CHECK (length(token_hash) = 64),
  -- Käyttäjän poistaminen mitätöi samalla hänen istuntonsa.
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  -- Millisekunnit Unix-epookista: sama aikayksikkö kuin JavaScriptin Date.now().
  expires_at INTEGER NOT NULL
);

-- Indeksi nopeuttaa omistajan projektien hakua; se ei itsessään anna käyttöoikeutta.
CREATE INDEX projects_owner_index ON projects(user_id);
-- Indeksi nopeuttaa yhden projektin tehtävien hakua.
CREATE INDEX tasks_project_index ON tasks(project_id);
-- Indeksi nopeuttaa käyttäjään liittyvien istuntojen käsittelyä.
CREATE INDEX sessions_user_index ON sessions(user_id);
-- Indeksi nopeuttaa vanhentuneiden istuntojen siivousta.
CREATE INDEX sessions_expiry_index ON sessions(expires_at);
````

### `esimerkit/04-valmis/db.ts`

````typescript
// import tuo toisessa moduulissa määritellyn nimen tähän tiedostoon.
// node:sqlite on Denon mukana tuleva yhteensopivuusmoduuli, ei npm-asennus.
import { DatabaseSync } from "node:sqlite";

// export sallii muiden tiedostojen käyttää tätä tyyppiä; type ei luo ajettavaa koodia.
export type Role = "user" | "admin"; // Pystyviiva tarkoittaa: jompikumpi näistä arvoista.

// interface kuvaa olion muodon TypeScriptille; se ei tarkista selaimen lähettämää dataa.
export interface User {
  id: number; // number on JavaScriptin lukutyyppi.
  email: string; // string on merkkijono eli teksti.
  role: Role; // Rooli on yllä määritelty user tai admin.
} // Aaltosulku päättää tämän tyypin kentät.

// extends lisää User-tyypin kenttien rinnalle tietokannassa tarvittavat salasanatiedot.
export interface UserRow extends User {
  password_hash: string; // Tiiviste heksadesimaalisena tekstinä.
  password_salt: string; // Satunnainen suola heksadesimaalisena tekstinä.
  password_iterations: number; // PBKDF2-laskennan kierrosten määrä.
}

// Tietokannan sarakkeissa käytämme alaviivaa; JSONissa muunnetaan camelCase-muotoon.
export interface ProjectRow {
  id: number; // Projektin tietokantatunnus.
  user_id: number; // Projektin omistajan tunnus; sitä ei oteta asiakaspyynnöstä.
  title: string; // Projektin nimi.
  created_at: string; // Luontiaika UTC-ajassa.
}

// Tämä tyyppi kuvaa tehtävän yhden tietokantarivin.
export interface TaskRow {
  id: number; // Tehtävän oma tunnus.
  project_id: number; // Viittaus projektiin.
  title: string; // Tehtävän nimi.
  done: number; // SQLite käyttää arvoa 0 tai 1; API palauttaa boolean-arvon.
  created_at: string; // Tehtävän luontiaika.
}

// function määrittelee toiminnon; path-parametri on tietokantatiedoston polku.
// Paluutyypin DatabaseSync merkitys: kutsuja saa avatun tietokantayhteyden.
export function openDatabase(path: string): DatabaseSync {
  // new luo olion. Erityinen polku :memory: luo testille vain muistissa olevan kannan.
  const db = new DatabaseSync(path);
  // try aloittaa lohkon, jonka virheet käsitellään alempana catch-lohkossa.
  try {
    // Viiteavaimet on otettava käyttöön erikseen jokaisessa SQLite-yhteydessä.
    db.exec("PRAGMA foreign_keys = ON;");
    // WAL on kirjoitusloki; tiedostokanta voi luoda myös -wal- ja -shm-tiedostoja.
    db.exec("PRAGMA journal_mode = WAL;");
    // Lyhyt lukitus odottaa enintään 5 sekuntia ennen tietokantavirhettä.
    db.exec("PRAGMA busy_timeout = 5000;");
    // Muutoskirjanpito on erillinen taulu, jonka voi turvallisesti varmistaa joka käynnistyksellä.
    db.exec(`
      -- IF NOT EXISTS jättää jo olemassa olevan taulun rauhaan.
      CREATE TABLE IF NOT EXISTS schema_migrations (
        -- Yksi rivi tarkoittaa yhtä jo suoritettua migraatiota.
        version INTEGER PRIMARY KEY,
        -- Tallennamme myös muutoksen suoritusajan.
        applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
      );
    `); // Kenoviivan sijaan nämä monirivisen tekstin rajat ovat gravismerkkejä `.
    // BEGIN IMMEDIATE varaa kirjoituksen: kaksi käynnistystä ei suorita samaa muutosta yhtä aikaa.
    db.exec("BEGIN IMMEDIATE;");
    // Sisempi try antaa mahdollisuuden perua keskeneräinen rakenteen muutos.
    try {
      // prepare valmistelee SQL-lauseen; get hakee yhden rivin tai undefined-arvon.
      const applied = db.prepare("SELECT version FROM schema_migrations WHERE version = ?").get(1);
      // Huutomerkki tarkoittaa negaatiota: jos riviä ei löydy, muutos on tekemättä.
      if (!applied) {
        // import.meta.url on tämän tiedoston osoite, joten polku ei riipu kutsujan hakemistosta.
        const schema = Deno.readTextFileSync(new URL("./01_create_schema.sql", import.meta.url));
        // Tässä exec suorittaa oman SQL-tiedostomme, ei koskaan käyttäjältä tullutta SQL-tekstiä.
        db.exec(schema);
        // Kysymysmerkki on parametrin paikka; run sitoo arvon 1 erillään SQL-koodista.
        db.prepare("INSERT INTO schema_migrations(version) VALUES (?)").run(1);
      }
      // COMMIT vahvistaa sekä taulut että muutoskirjanpidon yhtenä kokonaisuutena.
      db.exec("COMMIT;");
    } catch (error) { // Virhe siirtää suorituksen tähän; error on saatu virheolio.
      // ROLLBACK peruu keskeneräisen tapahtuman, jotta kantaan ei jää puolikasta rakennetta.
      db.exec("ROLLBACK;");
      // throw välittää virheen kutsujalle eikä väitä käynnistyksen onnistuneen.
      throw error;
    }
    // return päättää funktion ja antaa avatun yhteyden kutsujan käytettäväksi.
    return db;
  } catch (error) {
    // Jos alustus epäonnistuu, yhteyttä ei jätetä avoimeksi.
    db.close();
    // Kutsuja saa alkuperäisen virheen ja voi pysäyttää käynnistyksen.
    throw error;
  }
}
````

### `esimerkit/04-valmis/security.ts`

````typescript
// node:crypto tarjoaa Denon mukana vertailun, joka ei lopeta ensimmäiseen eriävään tavuun.
import { timingSafeEqual } from "node:crypto";

// const on muuttumaton nimi. Alaviiva numeroissa helpottaa lukemista: 600_000 = 600000.
export const PASSWORD_ITERATIONS = 600_000; // PBKDF2-HMAC-SHA-256:n työmäärä.
// Kahdeksan tuntia sekunteina; evästeen Max-Age käyttää sekunteja.
export const SESSION_SECONDS = 8 * 60 * 60;
// Sama evästeen nimi on käytössä sekä luotaessa, luettaessa että poistettaessa.
export const COOKIE_NAME = "tehtavataulu_session";

// Paluuolio sisältää tallennettavat arvot; se ei sisällä alkuperäistä salasanaa.
export interface PasswordDigest {
  hash: string; // 32 tavun laskentatulos 64 heksadesimaalimerkkinä.
  salt: string; // 16 satunnaista tavua 32 heksadesimaalimerkkinä.
  iterations: number; // Hitaan laskennan kierrosten määrä.
}

// Uint8Array on tavujono: kukin alkio on kokonaisluku väliltä 0–255.
function toHex(bytes: Uint8Array): string {
  // Array.from käy tavut läpi; nuoli => määrittelee jokaiselle tavulle tehtävän muunnoksen.
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  // toString(16) kirjoittaa luvun heksamuotoon; padStart lisää tarvittaessa etunollan.
}

// Tässä luemme vain oman tietokantamme tai oman ohjelmamme tuottamaa heksatekstiä.
function fromHex(hex: string) {
  // Kaksi tekstimerkkiä vastaa yhtä tavua; new varaa tulosta varten uuden tavutaulukon.
  const bytes = new Uint8Array(hex.length / 2);
  // for toistaa lohkon; index++ kasvattaa laskuria yhdellä jokaisen kierroksen jälkeen.
  for (let index = 0; index < bytes.length; index++) {
    // slice ottaa kaksi merkkiä ja parseInt(..., 16) tulkitsee ne heksalukuna.
    bytes[index] = Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16);
  }
  // Palautamme oman uuden taulukon: salainen vertailu tarvitsee tekstin sijaan tavuja.
  return bytes;
}

// async-funktio palauttaa Promisen eli myöhemmin valmistuvan tuloksen.
async function derivePassword(
  password: string,
  salt: string,
  iterations: number,
): Promise<Uint8Array> {
  // TextEncoder muuntaa salasanan Unicode-tekstin UTF-8-tavuiksi.
  const passwordBytes = new TextEncoder().encode(password);
  // await odottaa kryptografisen operaation valmistumista; se ei muuta salasanaa tekstiksi lokiin.
  const key = await crypto.subtle.importKey(
    "raw", // Lähtöarvo annetaan tavujonona.
    passwordBytes, // Tämä on salasanan tavuesitys, jota ei tallenneta kantaan.
    "PBKDF2", // Käytämme salasanoille tarkoitettua hidasta avaimenjohdantoa.
    false, // Avainta ei saa viedä ulos tästä CryptoKey-oliosta.
    ["deriveBits"], // Hakasulkeet muodostavat taulukon sallituista toiminnoista.
  );
  // PBKDF2 tekee paljon työtä jokaiselle arvaukselle, mikä hidastaa salasanojen murtamista.
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: fromHex(salt), iterations }, // Aaltosulut luovat asetusolion.
    key, // Käytämme juuri luotua avainta.
    256, // Laskentatuloksen pituus bitteinä: 256 bittiä = 32 tavua.
  );
  // Muunnamme ArrayBuffer-tuloksen tavutaulukoksi myöhempää käsittelyä varten.
  return new Uint8Array(bits);
}

// Rekisteröinti kutsuu tätä funktiota aina uudella satunnaisella suolalla.
export async function hashPassword(password: string): Promise<PasswordDigest> {
  // getRandomValues käyttää kryptografisesti turvallista satunnaisuutta.
  const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
  // Sama salasana eri suolalla antaa eri tallennettavan tiivisteen.
  const hash = toHex(await derivePassword(password, salt, PASSWORD_ITERATIONS));
  // Lyhennys {hash} tarkoittaa samaa kuin {hash: hash}.
  return { hash, salt, iterations: PASSWORD_ITERATIONS };
}

// Promise<boolean> tarkoittaa myöhemmin saatavaa tosi/epätosi-vastausta.
export async function verifyPassword(password: string, stored: PasswordDigest): Promise<boolean> {
  // Laskemme syötetystä salasanasta vertailuarvon käyttäen tallennettua suolaa ja työmäärää.
  const candidate = await derivePassword(password, stored.salt, stored.iterations);
  // Palautamme tallennetun heksatekstin takaisin 32 tavuksi.
  const expected = fromHex(stored.hash);
  // && vaatii molemmat ehdot. Vertailun molempien tavujonojen on oltava samanpituisia.
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

// Tuntematon sähköposti tekee saman hitaan salasanatyön kuin olemassa oleva käyttäjä.
// Tämä vähentää ilmeistä ajoituseroa; se ei lupaa koko HTTP-pyynnön vakioaikaisuutta.
export const DUMMY_PASSWORD: PasswordDigest = {
  hash: "0".repeat(64), // Keinotekoinen vertailuarvo, jota ei tallenneta käyttäjälle.
  salt: "0".repeat(32), // Keinotekoinen, oikeanpituinen suola vain tuntemattoman tilin polulle.
  iterations: PASSWORD_ITERATIONS, // Sama työmäärä kuin oikealla käyttäjällä.
};

// Istuntotunniste on arvaamaton salaisuus; sitä ei muodosteta käyttäjän tunnuksesta.
export function newSessionToken(): string {
  // 32 satunnaista tavua antaa 256 bittiä satunnaisuutta; tulos on 64 heksamerkkiä.
  return toHex(crypto.getRandomValues(new Uint8Array(32)));
}

// Tunniste on valmiiksi vahvasti satunnainen, joten sille riittää nopea SHA-256-tiiviste.
// Salasanalle ei riitä: salasanaa ihminen voi käyttää uudelleen tai sen voi arvata.
export async function hashSessionToken(token: string): Promise<string> {
  // digest laskee tiivisteen; se ei salaa tietoa palautettavasti.
  const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  // Tallennamme tietokantaan vain tämän tiivisteen.
  return toHex(new Uint8Array(hash));
}

// Luemme Cookie-otsakkeesta vain sovelluksen oman evästeen.
export function readSessionToken(request: Request): string | null {
  // ?? käyttää tyhjää tekstiä, jos otsaketta ei ole eli tulos on null.
  const cookies = (request.headers.get("cookie") ?? "").split(";");
  // map siistii osat; filter pitää vain omalla nimellä alkavat evästeet.
  const matches = cookies.map((part) => part.trim()).filter((part) =>
    part.startsWith(`${COOKIE_NAME}=`)
  );
  // Hylkäämme myös saman nimiset päällekkäiset evästeet, jotta tulkinta on yksiselitteinen.
  if (matches.length !== 1) return null;
  // slice poistaa nimen ja yhtäsuuruusmerkin arvon edestä.
  const token = matches[0].slice(COOKIE_NAME.length + 1);
  // Säännöllinen lauseke hyväksyy täsmälleen oman 64-merkkisen heksamuotomme.
  return /^[a-f0-9]{64}$/.test(token) ? token : null; // ? : valitsee toisen kahdesta arvosta.
}

// secure on true HTTPS-osoitteessa; localhostin tavallinen HTTP käyttää false-arvoa.
export function sessionCookie(token: string, secure: boolean): string {
  // HttpOnly estää JavaScriptin lukemasta evästettä; SameSite auttaa torjumaan sivustojen välisiä pyyntöjä.
  const base =
    `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_SECONDS}`;
  // Secure rajaa evästeen lähettämisen HTTPS-yhteyksiin. Domain puuttuu: eväste on isäntäkohtainen.
  return base + (secure ? "; Secure" : "");
}

// Eväste poistetaan samalla nimellä ja polulla, joilla se luotiin.
export function deletedSessionCookie(secure: boolean): string {
  // Max-Age=0 käskee selainta poistamaan evästeen; palvelin poistaa myös tietokannan istunnon.
  return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure ? "; Secure" : ""}`;
}

// Yksi laskuririvi kuvaa yhden IP-osoitteen tai sähköpostin yrityksiä aikajaksolla.
interface AttemptWindow {
  count: number; // Kuinka monta yritystä tähän ikkunaan on laskettu.
  resetAt: number; // Milloin laskuri nollautuu, millisekunteina Unix-epookista.
}

// Funktio palauttaa laskuritoiminnon, joka muistaa oman Map-taulukkonsa kutsujen välillä.
// now-parametri on funktio; testeissä voimme antaa sille hallittavan kellon.
export function createRateLimiter(now: () => number) {
  // Map tallentaa avain–arvo-pareja tämän palvelinprosessin muistiin.
  const windows = new Map<string, AttemptWindow>();
  // Yhden ikkunan kesto on 15 minuuttia millisekunneissa.
  const windowMs = 15 * 60 * 1000;
  // Paluuarvo on nuolifunktio: null sallii yrityksen, luku kertoo odotussekunnit.
  return (key: string, limit: number): number | null => {
    // Kello luetaan kerran, jotta tämän kutsun kaikki vertailut käyttävät samaa aikaa.
    const time = now();
    // Siivoamme vanhentuneet laskurit myös muistista, jotta ne eivät kerry ikuisesti.
    for (const [savedKey, window] of windows) {
      // delete poistaa Map-olion rivin, jos aikaraja on saavutettu.
      if (window.resetAt <= time) windows.delete(savedKey);
    }
    // get hakee olemassa olevan laskurin tai palauttaa undefined-arvon.
    let window = windows.get(key);
    // Uudelle avaimelle tarvitaan uusi aikajakso ja laskuri.
    if (!window) {
      // Kiinteä yläraja estää rajattoman määrän yksilöllisiä laskuriavaimia.
      if (windows.size >= 10_000) return 60;
      // Aloitamme nollasta; hetken päästä myös tämä kutsu lasketaan mukaan.
      window = { count: 0, resetAt: time + windowMs };
      // set tallentaa uuden avaimen ja sen laskurin.
      windows.set(key, window);
    }
    // Jos sallittu määrä on jo käytetty, palautamme jäljellä olevat sekunnit ylöspäin pyöristäen.
    if (window.count >= limit) return Math.ceil((window.resetAt - time) / 1000);
    // Myös onnistuneet yritykset lasketaan; tämän tarkoitus on rajata autentikointityön määrää.
    window.count += 1;
    // null tarkoittaa kutsujalle: tämä yritys saa jatkaa.
    return null;
  };
}
````

### `esimerkit/04-valmis/http.ts`

````typescript
// Record<string, unknown> tarkoittaa oliota, jonka kenttien arvoja ei vielä tunneta.
// unknown pakottaa tarkistamaan arvon ennen käyttöä: selaimen JSON ei ole luotettua.
export type JsonObject = Record<string, unknown>;

// extends Error tekee omasta virheestämme tavallisen JavaScript-virheen alityypin.
export class HttpError extends Error {
  status: number; // Esimerkiksi 400 = virheellinen pyyntö tai 401 = kirjautuminen puuttuu.
  headers: Record<string, string>; // Esimerkiksi Retry-After kertoo odotusajan sekunteina.

  // constructor suoritetaan, kun muu koodi kutsuu new HttpError(...).
  constructor(status: number, message: string, headers: Record<string, string> = {}) {
    // super kutsuu Error-yliluokan alustusta ja tallettaa virheilmoituksen.
    super(message);
    // this tarkoittaa juuri luotavaa virheoliota; tallennamme sille omat kentät.
    this.status = status;
    // Parametrin oletus {} tarkoittaa tyhjää oliota, jos otsakkeita ei anneta.
    this.headers = headers;
  }
}

// Yksi apufunktio varmistaa, että kaikki JSON-vastaukset ilmoittavat sisältötyyppinsä.
export function json(
  data: unknown,
  status = 200,
  extraHeaders: Record<string, string> = {},
): Response {
  // JSON.stringify muuttaa JavaScript-arvon JSON-tekstiksi; Response on HTTP-vastaus.
  return new Response(JSON.stringify(data), {
    status, // Kentän lyhyt muoto käyttää samannimisen parametrin arvoa.
    headers: { "Content-Type": "application/json; charset=utf-8", ...extraHeaders }, // ... kopioi lisäotsakkeet.
  });
}

// Kirjoittava pyyntö voi muuttaa tietoa; myös kirjautuminen ja uloskirjautuminen kuuluvat tähän.
export function isWriteMethod(method: string): boolean {
  // includes palauttaa true, jos metodi löytyy tästä sallittujen kirjoitusmetodien taulukosta.
  return ["POST", "PUT", "PATCH", "DELETE"].includes(method);
}

// CSRF tarkoittaa hyökkäystä, jossa toinen sivusto yrittää tehdä pyynnön käyttäjän evästeellä.
export function checkWriteRequest(request: Request, allowedOrigin: string): void {
  // Origin koostuu protokollasta, isäntänimestä ja portista; selaimen JavaScript ei voi vapaasti asettaa sitä.
  if (request.headers.get("origin") !== allowedOrigin) {
    // Puuttuva Origin hylätään myös. Esimerkiksi curl-harjoituksessa se on lisättävä itse.
    throw new HttpError(403, "Pyynnön alkuperää ei hyväksytty.");
  }
  // Otsakkeessa voi olla myös charset; erotamme varsinaisen mediatyypin ennen puolipistettä.
  const contentType = request.headers.get("content-type")?.split(";")[0].trim().toLowerCase();
  // JSON-vaatimus estää tavallisen vieraan sivuston HTML-lomakkeen käyttämisen API:n kirjoituksiin.
  if (contentType !== "application/json") {
    // 415 kertoo, ettei pyynnön sisältötyyppi ole tuettu.
    throw new HttpError(415, "Käytä Content-Type: application/json -otsaketta.");
  }
}

// Luemme enintään 16 KiB, vaikka asiakas jättäisi Content-Length-otsakkeen pois tai valehtelisi sen.
export async function readJsonObject(request: Request): Promise<JsonObject> {
  // Tämä tavuraja koskee koko JSON-runkoa, ei vain yhtä kenttää.
  const limit = 16 * 1024;
  // Number muuntaa pituusotsakkeen luvuksi; puuttuva otsake tuottaa tässä nollan.
  const declaredLength = Number(request.headers.get("content-length") ?? "0");
  // Selvästi liian pitkän pyynnön voi hylätä jo ennen rungon lukemista.
  if (declaredLength > limit) {
    // ?. kutsuu cancel-metodia vain, jos body on olemassa; peruminen lopettaa lisäluennan.
    await request.body?.cancel();
    // 413 ilmaisee liian suuren pyynnön.
    throw new HttpError(413, "Pyynnön sisältö saa olla enintään 16 KiB.");
  }
  // Myös poistossa lähetetään JSON-olio {}: pyyntö ei jää sisällöltään tulkinnanvaraiseksi.
  if (!request.body) throw new HttpError(400, "Lähetä JSON-olio, esimerkiksi {}.");
  // getReader antaa pääsyn rungon tavupaloihin yksi pala kerrallaan.
  const reader = request.body.getReader();
  // Tämä taulukko pitää vastaanotetut palat, kunnes tiedämme kokonaispituuden.
  const chunks: Uint8Array[] = [];
  // let sallii arvon muuttamisen: koko kasvaa jokaisesta uudesta palasta.
  let total = 0;
  // finally-lohko alempana vapauttaa lukijan myös virheessä.
  try {
    // while toistaa lukemista, kunnes break päättää silmukan.
    while (true) {
      // Destrukturointi {value, done} poimii kaksi kenttää lukutuloksesta.
      const { value, done } = await reader.read();
      // done kertoo, että koko pyyntörunko on luettu.
      if (done) break;
      // byteLength mittaa todellisia tavuja; merkkimäärä voisi olla tätä pienempi.
      total += value.byteLength;
      // Tarkistamme todellisen koon ennen kuin tallennamme tämän palan.
      if (total > limit) {
        // Lopetamme rungon lukemisen heti, kun raja ylittyy.
        await reader.cancel();
        // Heitetty virhe muutetaan app.ts-tiedostossa selkeäksi JSON-vastaukseksi.
        throw new HttpError(413, "Pyynnön sisältö saa olla enintään 16 KiB.");
      }
      // push lisää yhden palan taulukon loppuun.
      chunks.push(value);
    }
  } finally {
    // Lukijan lukko ei saa jäädä varatuksi onnistumisen tai virheen jälkeen.
    reader.releaseLock();
  }
  // Varaamme täsmälleen lukemamme kokoisen yhteisen tavutaulukon.
  const bytes = new Uint8Array(total);
  // offset kertoo, mihin kohtaan seuraava pala kirjoitetaan.
  let offset = 0;
  // for...of käy läpi tallennetut palat niiden alkuperäisessä järjestyksessä.
  for (const chunk of chunks) {
    // set kopioi palan tavut oikeaan kohtaan.
    bytes.set(chunk, offset);
    // Seuraava pala alkaa juuri kirjoitetun palan jälkeen.
    offset += chunk.byteLength;
  }
  // JSON.parse voi heittää virheen; sen tulos on aluksi tarkoituksella unknown.
  let parsed: unknown;
  // Käsittelemme virheellisen UTF-8-tekstin ja virheellisen JSONin samalla ymmärrettävällä virheellä.
  try {
    // fatal=true torjuu rikkinäiset UTF-8-tavut; parse tulkitsee tekstin JSON-arvoksi.
    parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    // 400 kertoo, että pyyntö ei ole kelvollista JSONia.
    throw new HttpError(400, "Pyynnön sisältö ei ole kelvollista JSONia.");
  }
  // typeof null on myös object, joten null pitää sulkea erikseen pois; taulukko ei ole lomakeolio.
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    // || tarkoittaa: ainakin yksi näistä hylkäysehdoista toteutuu.
    throw new HttpError(400, "JSONin ylimmän tason pitää olla olio.");
  }
  // as kertoo TypeScriptille juuri tarkistetun rakenteen; yksittäiset kentät ovat yhä unknown.
  return parsed as JsonObject;
}

// Torjumme ylimääräiset kentät kuten role, user_id ja project_id, ellei reitti nimenomaan salli niitä.
export function allowFields(body: JsonObject, allowed: string[]): void {
  // Object.keys palauttaa olion omien kenttien nimet.
  for (const field of Object.keys(body)) {
    // Syöte ei saa laajentaa reitin toimivaltaa lisäämällä omia kenttiään.
    if (!allowed.includes(field)) {
      throw new HttpError(400, "Pyynnössä on kenttä, jota tämä toiminto ei hyväksy.");
    }
  }
}

// Sähköpostin tarkistus on palvelimella pakollinen, vaikka selainkin tarkistaa lomaketta.
export function requireEmail(value: unknown): string {
  // typeof tekee ajonaikaisen tyyppitarkistuksen; TypeScript-tyyppi yksin ei tee sitä.
  if (typeof value !== "string") throw new HttpError(400, "Anna sähköpostiosoite tekstinä.");
  // trim poistaa reunavälilyönnit ja toLowerCase yhdenmukaistaa tilin nimen.
  const email = value.trim().toLowerCase();
  // Tämä on kurssin muototarkistus; osoitteen omistajuus vaatisi erillisen vahvistusviestin.
  // Myös näkymätön NUL torjutaan, jotta tietokannan tekstipituuden tulkinta ei poikkea tarkistuksesta.
  if (
    email.length > 254 || email.includes("\u0000") ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  ) {
    // Virhe ei kerro, onko osoitteella olemassa tiliä.
    throw new HttpError(400, "Anna sähköpostiosoite muodossa nimi@example.test.");
  }
  // Kutsuja saa yhdenmukaistetun osoitteen, ei alkuperäistä tarkistamatonta arvoa.
  return email;
}

// Salasanassa sallitaan välilyönnit ja pitkät salalauseet, eikä sitä koskaan trimmailla.
export function requirePassword(value: unknown): string {
  // Vain merkkijono kelpaa; esimerkiksi numerosta ei tehdä salasanaa automaattisesti.
  if (typeof value !== "string") throw new HttpError(400, "Anna salasana tekstinä.");
  // Array.from laskee Unicode-koodipisteet; esimerkiksi moni emoji on useampi tällainen piste.
  const length = Array.from(value).length;
  // 15–128 merkkiä on tämän harjoitussovelluksen salasanakäytäntö ilman MFA:ta.
  if (length < 15 || length > 128) {
    throw new HttpError(400, "Salasanassa pitää olla 15–128 merkkiä.");
  }
  // Salasanan sisältöä ei muuteta huomaamatta tarkistuksen yhteydessä.
  return value;
}

// Sama nimitarkistus toimii projekteille ja tehtäville eri enimmäispituuksilla.
export function requireTitle(value: unknown, maxLength: number): string {
  // JSON voi sisältää myös taulukon tai numeron; torjumme ne tässä.
  if (typeof value !== "string") throw new HttpError(400, "Anna nimi tekstinä.");
  // Nimen reunoilla olevat tyhjät merkit eivät kuulu tallennettavaan nimeen.
  const title = value.trim();
  // Unicode-koodipisteiden laskenta vastaa tavallisen SQLite-tekstin length-tarkistuksen tarkoitusta.
  const length = Array.from(title).length;
  // Kieltämällä NUL-merkin vältämme SQLite length -funktion ja JavaScriptin erilaisen NUL-tulkinnan.
  if (length < 1 || length > maxLength || title.includes("\u0000")) {
    // ${...} sijoittaa muuttujan arvon gravismerkkien rajaamaan tekstipohjaan.
    throw new HttpError(400, `Nimessä pitää olla 1–${maxLength} merkkiä eikä NUL-merkkiä.`);
  }
  // Vain tarkistettu teksti jatkaa tietokantakerrokseen.
  return title;
}

// Polun :id-osa saapuu tekstinä; tietokanta tarvitsee positiivisen kokonaisluvun.
export function requireId(value: string): number {
  // Pelkät numeromerkit kelpaavat; esimerkiksi 1abc tai -2 eivät kelpaa.
  if (!/^\d+$/.test(value)) throw new HttpError(404, "Kohdetta ei löytynyt.");
  // Number tulkitsee kokonaisen merkkijonon luvuksi.
  const id = Number(value);
  // SafeInteger estää JavaScriptin tarkkuusrajan ylittävät tunnukset.
  if (!Number.isSafeInteger(id) || id <= 0) throw new HttpError(404, "Kohdetta ei löytynyt.");
  // Palautamme tyypitetyn ja tarkistetun numeron.
  return id;
}

// Asetamme samat suojaavat otsakkeet myös virhevastauksille ja staattisille tiedostoille.
export function secureResponse(response: Response, https: boolean): Response {
  // CSP rajaa sivun oman originin skripteihin, tyyleihin, kuviin ja verkkopyyntöihin.
  response.headers.set(
    "Content-Security-Policy",
    "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
  );
  // Selain ei saa arvata esimerkiksi JSON-tekstin olevan suoritettavaa JavaScriptiä.
  response.headers.set("X-Content-Type-Options", "nosniff");
  // Sivun kehystys estetään myös tätä vanhempaa otsaketta tukevissa selaimissa.
  response.headers.set("X-Frame-Options", "DENY");
  // Linkin seuraaminen ei paljasta lähtösivun osoitetta Referer-otsakkeessa.
  response.headers.set("Referrer-Policy", "no-referrer");
  // Vastausten välimuistiin tallennus kielletään etenkin kirjautuneen käyttäjän datan vuoksi.
  response.headers.set("Cache-Control", "no-store");
  // Tämän sivun vastauksia ei ole tarkoitettu vieraan originin resursseiksi.
  response.headers.set("Cross-Origin-Resource-Policy", "same-origin");
  // Sovellus ei tarvitse kameraa, mikrofonia eikä sijaintitietoa.
  response.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  // HSTS ohjaa HTTPS-käyttöön vain silloin, kun sovelluksen julkinen osoite on HTTPS.
  if (https) response.headers.set("Strict-Transport-Security", "max-age=31536000");
  // Response-olion sisältö pysyy samana; olemme täydentäneet sen otsakkeet.
  return response;
}
````

### `esimerkit/04-valmis/auth.ts`

````typescript
// import type tuo vain tyyppitiedon; tätä tuontia ei tarvita ohjelman ajossa.
import type { DatabaseSync } from "node:sqlite";
// User on julkinen käyttäjätieto; UserRow sisältää myös salasanan vertailutiedot.
import type { User, UserRow } from "./db.ts";
// HTTP-apufunktiot tarkistavat tuntemattoman JSONin ennen sen käyttämistä.
import {
  allowFields,
  HttpError,
  json,
  type JsonObject,
  requireEmail,
  requirePassword,
} from "./http.ts";
// Turvatoiminnot on erotettu omaan tiedostoonsa, jotta niiden tehtävät näkyvät selvästi.
import {
  createRateLimiter,
  deletedSessionCookie,
  DUMMY_PASSWORD,
  hashPassword,
  hashSessionToken,
  newSessionToken,
  readSessionToken,
  SESSION_SECONDS,
  sessionCookie,
  verifyPassword,
} from "./security.ts";

// Tehdasfunktio kokoaa tämän yhden palvelimen kirjautumistoiminnot ja yhteisen yrityslaskurin.
export function createAuth(db: DatabaseSync, secureCookies: boolean, now: () => number) {
  // Sulkeuma muistaa laskurit, vaikka yksi HTTP-pyyntö päättyisi.
  const consumeAttempt = createRateLimiter(now);

  // Sisäinen apufunktio muuttaa ylitetyn rajan käyttäjälle näkyväksi HTTP-virheeksi.
  function checkAttempts(key: string, maximum: number): void {
    // Paluuarvo null tarkoittaa sallittua yritystä; numero on odotussekuntien määrä.
    const retryAfter = consumeAttempt(key, maximum);
    // !== vertaa arvoja ilman automaattista tyyppimuunnosta.
    if (retryAfter !== null) {
      // 429 kertoo liian monista yrityksistä; Retry-After kertoo, milloin voi yrittää uudelleen.
      throw new HttpError(429, "Liian monta yritystä. Odota ja yritä uudelleen.", {
        "Retry-After": String(retryAfter),
      });
    }
  }

  // Tämä tarkistus lukee käyttäjän aina palvelimen istunnosta, ei pyynnön user_id-kentästä.
  async function currentUser(request: Request): Promise<User> {
    // Evästeen arvo on salainen satunnaistunniste, ei käyttäjän rooli tai käyttäjätunnus.
    const token = readSessionToken(request);
    // Puuttuva tai vääränmuotoinen eväste ei riitä kirjautumiseen.
    if (!token) throw new HttpError(401, "Kirjaudu ensin sisään.");
    // Tietokannasta haetaan tunnisteen tiivisteellä; raakaa tunnistetta ei tallenneta.
    const tokenHash = await hashSessionToken(token);
    // Poistamme myös palvelimen puolella vanhentuneet istunnot ennen käyttöoikeustarkistusta.
    db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(now());
    // JOIN yhdistää voimassa olevan istunnon käyttäjään; rooli luetaan tämänhetkisestä käyttäjärivistä.
    const user = db.prepare(`
      -- Palautamme vain julkiseen User-tyyppiin kuuluvat kentät.
      SELECT users.id, users.email, users.role
      FROM sessions
      JOIN users ON users.id = sessions.user_id
      -- Molemmat ehdot vaaditaan: oikea tunniste ja tulevaisuudessa oleva vanhenemisaika.
      WHERE sessions.token_hash = ? AND sessions.expires_at > ?
    `).get(tokenHash, now()) as User | undefined; // as kuvaa oman SQL-kyselymme tuloksen TypeScriptille.
    // Tuntematon, poistettu tai vanhentunut istunto tuottaa saman 401-virheen.
    if (!user) throw new HttpError(401, "Kirjaudu ensin sisään.");
    // Paluuolio ei sisällä salasanatietoja eikä istuntotunnistetta.
    return user;
  }

  // Jokainen onnistunut kirjautuminen ja rekisteröinti saa uuden satunnaistunnisteen.
  async function beginSession(request: Request, user: User, status: number): Promise<Response> {
    // Luomme uuden tunnisteen; emme jatka selaimen mahdollisesti lähettämällä vanhalla arvolla.
    const token = newSessionToken();
    // Laskemme uuden tunnisteen tietokantaan tallennettavan tiivisteen.
    const tokenHash = await hashSessionToken(token);
    // Luemme vanhan evästeen, jotta tämän selaimen aikaisempi istunto voidaan mitätöidä.
    const oldToken = readSessionToken(request);
    // ? : tekee vanhan tunnisteen tiivisteen vain, jos tunniste oli olemassa.
    const oldHash = oldToken ? await hashSessionToken(oldToken) : null;
    // Tässä Date.now-yksikkö on millisekunti; kerromme evästeen sekunnit tuhannella.
    const expiresAt = now() + SESSION_SECONDS * 1000;
    // Istunnon vaihto on yksi tietokantatapahtuma: vanha poistuu ja uusi lisätään yhdessä.
    db.exec("BEGIN IMMEDIATE;");
    // try/catch varmistaa, ettei epäonnistunut vaihto jää puolikkaaksi.
    try {
      // Mahdollinen aiempi eväste ei jää toimivaksi uuden kirjautumisen jälkeen.
      if (oldHash) db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(oldHash);
      // Siivoamme vanhentuneet istunnot myös kirjautumisen yhteydessä.
      db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(now());
      // Parametrit annetaan run-kutsussa; niitä ei liitetä SQL-tekstiin.
      db.prepare("INSERT INTO sessions(token_hash, user_id, expires_at) VALUES (?, ?, ?)").run(
        tokenHash,
        user.id,
        expiresAt,
      );
      // Vahvistamme kaikki tapahtuman muutokset.
      db.exec("COMMIT;");
    } catch (error) {
      // Virheessä palautamme tietokannan ennen tapahtumaa vallinneeseen tilaan.
      db.exec("ROLLBACK;");
      // app.ts muuttaa odottamattoman virheen yleiseksi palvelinvirheeksi.
      throw error;
    }
    // Set-Cookie on HTTP-vastausotsake: selain tallentaa sen automaattisesti omaksi evästeekseen.
    return json({ user }, status, { "Set-Cookie": sessionCookie(token, secureCookies) });
  }

  // Rekisteröinti luo tavallisen käyttäjän ja avaa tälle istunnon.
  async function register(request: Request, body: JsonObject, clientIp: string): Promise<Response> {
    // Asiakas saa lähettää vain sähköpostin ja salasanan; role-kenttä hylätään.
    allowFields(body, ["email", "password"]);
    // Tarkistamme ja yhdenmukaistamme sähköpostiosoitteen.
    const email = requireEmail(body.email);
    // Tarkistamme salasanan pituuden muuttamatta sen sisältöä.
    const password = requirePassword(body.password);
    // Yksi IP saa tässä opetuspalvelimessa tehdä enintään 10 rekisteröintiyritystä 15 minuutissa.
    checkAttempts(`register:ip:${clientIp}`, 10);
    // Salasanan hidas laskenta tehdään ennen tietokantaan tallentamista.
    const digest = await hashPassword(password);
    // Rooli on kovakoodattu user-arvoksi; käyttäjä ei voi valita admin-roolia.
    const result = db.prepare(`
      -- Salasana-arvot ovat erillisiä parametreja, eivät SQL-koodin osia.
      INSERT INTO users(email, password_hash, password_salt, password_iterations, role)
      VALUES (?, ?, ?, ?, 'user')
      -- UNIQUE-rajoite suojaa myös kahta samanaikaista samalla osoitteella tehtyä rekisteröintiä.
      ON CONFLICT(email) DO NOTHING
    `).run(email, digest.hash, digest.salt, digest.iterations);
    // changes kertoo muutettujen rivien määrän; nolla tarkoittaa varattua sähköpostia.
    if (Number(result.changes) === 0) {
      throw new HttpError(409, "Rekisteröinti ei onnistunut näillä tiedoilla.");
    }
    // Muodostamme vain selaimelle sopivan julkisen käyttäjäolion.
    const user: User = { id: Number(result.lastInsertRowid), email, role: "user" };
    // 201 on uuden resurssin luomista tarkoittava HTTP-tila.
    return await beginSession(request, user, 201);
  }

  // Kirjautumisessa tunnistetaan käyttäjä olemassa olevan salasanan avulla.
  async function login(request: Request, body: JsonObject, clientIp: string): Promise<Response> {
    // Reitti ei hyväksy esimerkiksi roolia, istunnon tunnistetta tai käyttäjän numeerista tunnusta.
    allowFields(body, ["email", "password"]);
    // Samaa normalisointia käytetään rekisteröinnissä ja kirjautumisessa.
    const email = requireEmail(body.email);
    // Salasanaan ei tehdä trim- eikä kirjainkoon muutosta.
    const password = requirePassword(body.password);
    // IP tulee Deno.serve-yhteyden tiedoista, ei asiakkaan X-Forwarded-For-otsakkeesta.
    checkAttempts(`login:ip:${clientIp}`, 20);
    // Lisäksi yhden sähköpostin arvailuja rajataan viiteen yritykseen 15 minuutissa.
    checkAttempts(`login:email:${email}`, 5);
    // Kysely etsii tiliä parametrina annetulla sähköpostilla.
    const row = db.prepare(
      "SELECT id, email, role, password_hash, password_salt, password_iterations FROM users WHERE email = ?",
    ).get(email) as UserRow | undefined;
    // Olemassa olevalta tililtä käytetään sen omaa suolaa; tuntemattomalle tehdään sama laskentatyö.
    const stored = row
      ? { hash: row.password_hash, salt: row.password_salt, iterations: row.password_iterations }
      : DUMMY_PASSWORD;
    // Tämä vertailu tapahtuu myös silloin, kun sähköpostiosoitetta ei löydy.
    const matches = await verifyPassword(password, stored);
    // Sama viesti ja tilakoodi peittävät sen, oliko sähköposti vai salasana väärä.
    if (!row || !matches) throw new HttpError(401, "Sähköposti tai salasana on väärä.");
    // Salasanan tiivistettä tai suolaa ei sisällytetä selaimelle palautettavaan olioon.
    const user: User = { id: row.id, email: row.email, role: row.role };
    // Onnistunut kirjautuminen vaihtaa istunnon uuteen tunnisteeseen.
    return await beginSession(request, user, 200);
  }

  // Uloskirjautuminen mitätöi palvelimen istunnon, vaikka eväste olisi kopioitu talteen.
  async function logout(request: Request, body: JsonObject): Promise<Response> {
    // Logoutin JSON-runko on tyhjä olio {}.
    allowFields(body, []);
    // Istunnon puuttuminen ei estä uloskirjautumisen loppuun viemistä.
    const token = readSessionToken(request);
    // Käytämme tietokantahakuun vain tiivistettä.
    if (token) {
      db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(await hashSessionToken(token));
    }
    // 204 tarkoittaa onnistumista ilman vastausrunkoa; null on tällöin pakollinen sisältö.
    return new Response(null, {
      status: 204,
      headers: { "Set-Cookie": deletedSessionCookie(secureCookies) },
    });
  }

  // Tehdas antaa kutsujalle neljä nimettyä toimintoa, joilla on sama tietokanta ja laskuri.
  return { currentUser, register, login, logout };
}
````

### `esimerkit/04-valmis/projects.ts`

````typescript
// Tietokanta- ja rivityypit auttavat tarkistamaan palvelimen omaa koodia ennen ajoa.
import type { DatabaseSync } from "node:sqlite";
// User tulee kirjautumisistunnosta, ProjectRow ja TaskRow omista SQL-kyselyistämme.
import type { ProjectRow, TaskRow, User } from "./db.ts";
// Validointi ja HTTP-vastaukset ovat yhteisiä kaikille reiteille.
import { allowFields, HttpError, json, type JsonObject, requireId, requireTitle } from "./http.ts";

// Muunnamme tietokantarivin tietoisesti julkisen API-sopimuksen mukaiseksi.
function projectJson(row: ProjectRow) {
  // user_id jää palvelimelle; created_at saa JSONissa nimen createdAt.
  return { id: row.id, title: row.title, createdAt: row.created_at };
}

// Tämä muunnos pitää SQLiten kokonaisluvut erillään JavaScriptin totuusarvoista.
function taskJson(row: TaskRow) {
  // === 1 tuottaa boolean-arvon true tai false; emme lähetä käyttöliittymälle merkkijonoa "false".
  return {
    id: row.id,
    projectId: row.project_id,
    title: row.title,
    done: row.done === 1,
    createdAt: row.created_at,
  };
}

// Autorisointi vastaa kysymykseen: saako juuri tämä käyttäjä käyttää juuri tätä projektia?
function ownedProject(db: DatabaseSync, id: number, ownerId: number): ProjectRow {
  // Molemmat ehdot ovat pakollisia; pelkkä projektin id ei ole käyttöoikeus.
  const row = db.prepare(
    "SELECT id, user_id, title, created_at FROM projects WHERE id = ? AND user_id = ?",
  ).get(id, ownerId) as ProjectRow | undefined;
  // Vastaamme samoin puuttuvaan ja toisen omistamaan projektiin, joten vieraan kohteen olemassaolo ei paljastu.
  if (!row) throw new HttpError(404, "Projektia ei löytynyt.");
  // Vain omistajalle kuuluva rivi palautuu jatkokäsittelyyn.
  return row;
}

// Tehtävän omistaja selvitetään sen projektin kautta: tehtävässä ei ole erillistä käyttäjäkenttää.
function ownedTask(db: DatabaseSync, id: number, ownerId: number): TaskRow {
  // JOIN seuraa viiteavainta tasks.project_id -> projects.id ja tarkistaa projektin omistajan.
  const row = db.prepare(`
    -- tasks.-etuliite kertoo, kumman taulun sarake on kyseessä.
    SELECT tasks.id, tasks.project_id, tasks.title, tasks.done, tasks.created_at
    FROM tasks
    JOIN projects ON projects.id = tasks.project_id
    -- Arvot sidotaan get-kutsussa samassa järjestyksessä kuin kysymysmerkit.
    WHERE tasks.id = ? AND projects.user_id = ?
  `).get(id, ownerId) as TaskRow | undefined;
  // Vieraan tehtävän numeron arvaaminen ei anna oikeutta lukea tai muuttaa sitä.
  if (!row) throw new HttpError(404, "Tehtävää ei löytynyt.");
  // Palautamme vain onnistuneen omistajuustarkistuksen läpäisseen rivin.
  return row;
}

// Tämä reititin käsittelee projektit, tehtävät ja rajatun ylläpitonäkymän.
// Response | null tarkoittaa joko valmista vastausta tai tietoa siitä, ettei reitti kuulu tähän tiedostoon.
export function handleProjects(
  db: DatabaseSync,
  method: string,
  path: string,
  user: User,
  body: JsonObject,
): Response | null {
  // Tällä erillisellä reitillä näytetään vain yhteismääriä; sitä ei käytetä muiden projektien lukemiseen.
  if (path === "/api/admin/stats") {
    // Tilastot ovat vain luettavia; tämä reitti ei muuta dataa.
    if (method !== "GET") throw new HttpError(405, "Tämä reitti hyväksyy vain GET-pyynnön.");
    // Pelkkä kirjautuminen ei riitä: palvelin tarkistaa myös tietokannasta luetun roolin.
    if (user.role !== "admin") throw new HttpError(403, "Toiminto vaatii ylläpitäjän roolin.");
    // Sisäkkäiset SELECT-lauseet laskevat kunkin taulun rivimäärän palauttamatta henkilötietoja.
    const totals = db.prepare(
      "SELECT (SELECT COUNT(*) FROM users) AS users, (SELECT COUNT(*) FROM projects) AS projects, (SELECT COUNT(*) FROM tasks) AS tasks",
    ).get();
    // COUNT palauttaa aina rivin; puuttuminen olisi ohjelman tai tietokannan odottamaton virhe.
    if (!totals) throw new Error("Tilastokysely ei palauttanut riviä.");
    // Number varmistaa, että JSON saa tavallisia lukuja eikä esimerkiksi bigint-arvoja.
    return json({
      users: Number(totals.users),
      projects: Number(totals.projects),
      tasks: Number(totals.tasks),
    });
  }

  // Tämä polku tarkoittaa kirjautuneen käyttäjän projektikokoelmaa.
  if (path === "/api/projects") {
    // GET lukee kokoelman eikä muuta palvelimen dataa.
    if (method === "GET") {
      // WHERE rajaa jo tietokantakyselyn vain kirjautuneen käyttäjän projekteihin.
      const rows = db.prepare(
        "SELECT id, user_id, title, created_at FROM projects WHERE user_id = ? ORDER BY id",
      ).all(user.id) as unknown as ProjectRow[];
      // map muuntaa jokaisen rivin API-olioksi. Tyhjästä kannasta palautuu tyhjä projects-taulukko.
      return json({ projects: rows.map(projectJson) });
    }
    // POST luo tähän kokoelmaan yhden uuden projektin.
    if (method === "POST") {
      // Omistajaa ei hyväksytä rungossa; user_id otetaan palvelimen tunnistamasta käyttäjästä.
      allowFields(body, ["title"]);
      // Projektin nimi on pakollinen ja enintään 120 Unicode-koodipistettä pitkä.
      const title = requireTitle(body.title, 120);
      // Parametrisoitu INSERT käsittelee myös heittomerkit tavallisena nimen tekstinä.
      const result = db.prepare("INSERT INTO projects(user_id, title) VALUES (?, ?)").run(
        user.id,
        title,
      );
      // Haemme luodun projektin, jotta vastauksessa on tietokannan tuottama luontiaika.
      const row = ownedProject(db, Number(result.lastInsertRowid), user.id);
      // 201 kertoo, että uusi projekti luotiin onnistuneesti.
      return json({ project: projectJson(row) }, 201);
    }
    // Tunnettu polku mutta väärä metodi on 405, ei onnistunut operaatio.
    throw new HttpError(405, "Projektikokoelma hyväksyy GET- ja POST-pyynnöt.");
  }

  // Sulkuryhmä ([^/]+) poimii yhden polkuosan projektin tunnukseksi.
  const taskCollection = path.match(/^\/api\/projects\/([^/]+)\/tasks$/);
  // match palauttaa null, jos polku ei täsmää; muussa tapauksessa jatkamme täällä.
  if (taskCollection) {
    // [1] on ensimmäisen sulkuryhmän sisältö; [0] olisi koko osunut teksti.
    const projectId = requireId(taskCollection[1]);
    // Omistajuus tarkistetaan myös tehtävälistan lukemisessa ja uuden tehtävän luomisessa.
    ownedProject(db, projectId, user.id);
    // GET lukee yhden projektin tehtävät.
    if (method === "GET") {
      // JOIN ja user_id-ehto pitävät omistajuusrajauksen mukana myös tässä varsinaisessa datakyselyssä.
      const rows = db.prepare(`
        SELECT tasks.id, tasks.project_id, tasks.title, tasks.done, tasks.created_at
        FROM tasks
        JOIN projects ON projects.id = tasks.project_id
        WHERE tasks.project_id = ? AND projects.user_id = ?
        ORDER BY tasks.id
      `).all(projectId, user.id) as unknown as TaskRow[]; // Tyyppivakuutus koskee omaa SQL-tulosta.
      // Käyttöliittymä saa taulukon, jossa done on true tai false.
      return json({ tasks: rows.map(taskJson) });
    }
    // POST lisää tehtävän polussa yksilöityyn projektiin.
    if (method === "POST") {
      // project_id-kenttää ei hyväksytä rungossa; projekti tulee tarkistetusta URL-polusta.
      allowFields(body, ["title"]);
      // Tehtävän nimessä saa olla 1–200 merkkiä.
      const title = requireTitle(body.title, 200);
      // INSERT ... SELECT lisää rivin vain, jos omistettu projekti on edelleen olemassa.
      const result = db.prepare(
        "INSERT INTO tasks(project_id, title) SELECT id, ? FROM projects WHERE id = ? AND user_id = ?",
      ).run(title, projectId, user.id);
      // Jos projekti olisi poistettu toisen yhteyden kautta, uutta tehtävää ei luoda.
      if (Number(result.changes) !== 1) throw new HttpError(404, "Projektia ei löytynyt.");
      // Haemme luodun tehtävän samalla omistajuuden tarkistavalla apufunktiolla.
      const row = ownedTask(db, Number(result.lastInsertRowid), user.id);
      // 201 ja task-kenttä muodostavat sovitun uuden tehtävän vastauksen.
      return json({ task: taskJson(row) }, 201);
    }
    // Muilla metodeilla ei saa tyhjentää tehtäväkokoelmaa tai ohittaa yksittäisen tehtävän reittejä.
    throw new HttpError(405, "Tehtäväkokoelma hyväksyy GET- ja POST-pyynnöt.");
  }

  // Tämä polku yksilöi yhden projektin.
  const projectItem = path.match(/^\/api\/projects\/([^/]+)$/);
  // Totuusarvoksi tulkittu match-tulos kertoo, löytyikö reitti.
  if (projectItem) {
    // Muunnamme URL-osan turvalliseksi kokonaisluvuksi ennen SQL-kyselyä.
    const id = requireId(projectItem[1]);
    // Jokainen tämän reitin toiminto edellyttää projektin omistajuutta.
    const row = ownedProject(db, id, user.id);
    // GET lukee yhden omistetun projektin.
    if (method === "GET") return json({ project: projectJson(row) });
    // PATCH päivittää nimikentän; omistajan vaihtaminen ei kuulu API-sopimukseen.
    if (method === "PATCH") {
      // Näin käyttäjä ei voi syöttää esimerkiksi toista user_id-arvoa.
      allowFields(body, ["title"]);
      // Uusi nimi käy saman tarkistuksen kuin luomisessa.
      const title = requireTitle(body.title, 120);
      // Päivityksen WHERE tarkistaa uudelleen sekä projektin että omistajan.
      db.prepare("UPDATE projects SET title = ? WHERE id = ? AND user_id = ?").run(
        title,
        id,
        user.id,
      );
      // Vastauksessa on juuri tietokannasta luettu päivitetty tila.
      return json({ project: projectJson(ownedProject(db, id, user.id)) });
    }
    // DELETE poistaa projektin ja viiteavaimen CASCADE-säännöllä sen tehtävät.
    if (method === "DELETE") {
      // Poistopyynnön runko on tyhjä olio {}.
      allowFields(body, []);
      // Omistajuus on mukana myös poistavassa SQL-lauseessa.
      db.prepare("DELETE FROM projects WHERE id = ? AND user_id = ?").run(id, user.id);
      // 204-vastauksessa ei ole JSON-runkoa; selain tarkistaa tilakoodin.
      return new Response(null, { status: 204 });
    }
    // Tunnetun projektireitin muut metodit hylätään.
    throw new HttpError(405, "Projekti hyväksyy GET-, PATCH- ja DELETE-pyynnöt.");
  }

  // Tehtävän reitti sisältää tehtävän oman tunnuksen, ei projektin tunnusta.
  const taskItem = path.match(/^\/api\/tasks\/([^/]+)$/);
  // Vain tähän polkumuotoon osuvat pyynnöt käsitellään tässä lohkossa.
  if (taskItem) {
    // Tunnuksen tyypin ja arvoalueen tarkistus tapahtuu ennen omistajuuskyselyä.
    const id = requireId(taskItem[1]);
    // Omistajuus kulkee tehtävästä projektiin ja projektista kirjautuneeseen käyttäjään.
    const row = ownedTask(db, id, user.id);
    // Myös yhden tehtävän luku on suojattu samalla tarkistuksella.
    if (method === "GET") return json({ task: taskJson(row) });
    // PATCH saa muuttaa nimen, valmistumistilan tai molemmat.
    if (method === "PATCH") {
      // Tehtävää ei voi siirtää toisen käyttäjän projektiin piilotetulla project_id-kentällä.
      allowFields(body, ["title", "done"]);
      // Tyhjä PATCH olisi epäselvä: pyydämme vähintään yhden muutettavan kentän.
      if (Object.keys(body).length === 0) {
        throw new HttpError(400, "Anna uusi nimi tai valmistumistila.");
      }
      // Puuttuva title säilyttää vanhan nimen; annettu nimi validoidaan aina.
      const title = body.title === undefined ? row.title : requireTitle(body.title, 200);
      // Teksti "false" ei ole boolean false: hyväksymme vain aidon JSON-totuusarvon.
      if (body.done !== undefined && typeof body.done !== "boolean") {
        throw new HttpError(400, "done-kentän pitää olla true tai false.");
      }
      // SQLitelle muunnetaan true -> 1 ja false -> 0; puuttuva kenttä säilyttää vanhan arvon.
      const done = body.done === undefined ? row.done : body.done ? 1 : 0;
      // Sisäkkäinen SELECT rajaa päivityksen vain käyttäjän omiin projekteihin.
      db.prepare(
        "UPDATE tasks SET title = ?, done = ? WHERE id = ? AND project_id IN (SELECT id FROM projects WHERE user_id = ?)",
      ).run(title, done, id, user.id);
      // Palautamme tallennetun tilan, jotta frontend voi näyttää oikean lopputuloksen.
      return json({ task: taskJson(ownedTask(db, id, user.id)) });
    }
    // DELETE poistaa yhden omistetun tehtävän.
    if (method === "DELETE") {
      // Tälle toiminnolle ei tarvita lisäkenttiä.
      allowFields(body, []);
      // Myös poistossa omistajuus on osa SQL-lauseen ehtoa.
      db.prepare(
        "DELETE FROM tasks WHERE id = ? AND project_id IN (SELECT id FROM projects WHERE user_id = ?)",
      ).run(id, user.id);
      // Onnistunut poisto palauttaa tyhjän 204-vastauksen.
      return new Response(null, { status: 204 });
    }
    // Esimerkiksi PUT ei korvaa tehtävää huomaamatta kokonaan.
    throw new HttpError(405, "Tehtävä hyväksyy GET-, PATCH- ja DELETE-pyynnöt.");
  }

  // null ilmoittaa app.ts-tiedostolle, ettei mikään tämän tiedoston reiteistä täsmännyt.
  return null;
}
````

### `esimerkit/04-valmis/app.ts`

````typescript
// Tietokannan tyyppi ei avaa yhteyttä: yhteys annetaan main.ts-tiedostosta tai testistä.
import type { DatabaseSync } from "node:sqlite";
// Kirjautumistoiminnot sijaitsevat omassa moduulissaan.
import { createAuth } from "./auth.ts";
// Näillä apufunktioilla luemme pyynnön turvallisesti ja muodostamme yhtenäisen vastauksen.
import {
  checkWriteRequest,
  HttpError,
  isWriteMethod,
  json,
  type JsonObject,
  readJsonObject,
  secureResponse,
} from "./http.ts";
// Projektien ja tehtävien omistajuustarkistukset ovat tämän reitittimen vastuulla.
import { handleProjects } from "./projects.ts";

// Valinnat kuvaavat tämän sovellusinstanssin asetuksia.
export interface AppOptions {
  origin: string; // Selaimessa käytetty tarkka alkuperä, esimerkiksi http://localhost:8000.
  now?: () => number; // ? tekee asetuksesta vapaaehtoisen; testi voi antaa oman kellon.
}

// createApp ei avaa verkkoporttia: se tuottaa Request -> Promise<Response> -käsittelijän.
// Siksi samaa oikeaa sovelluskoodia voidaan testata ilman ulkoista verkkopalvelua.
export function createApp(db: DatabaseSync, options: AppOptions) {
  // new URL pilkkoo originin protokollaan, isäntänimeen ja porttiin.
  const configuredUrl = new URL(options.origin);
  // Originissa ei ole polkua tai loppuviivaa. Tarkka muoto välttää epäselvän hyväksyttyjen osoitteiden listan.
  if (
    configuredUrl.origin !== options.origin || !["http:", "https:"].includes(configuredUrl.protocol)
  ) {
    // Tämä on käynnistyksen asetusvirhe, ei käyttäjän HTTP-pyynnön virhe.
    throw new Error(
      "APP_ORIGIN pitää antaa originina, esimerkiksi http://localhost:8000, ilman loppuviivaa.",
    );
  }
  // HTTPS-osoitteessa sessioeväste saa Secure-määrityksen.
  const https = configuredUrl.protocol === "https:";
  // ?? käyttää oikeaa kelloa, ellei testi antanut toista; Date.now on tässä funktio eikä sen tulos.
  const now = options.now ?? Date.now;
  // Kirjautumistoiminnot ja yrityslaskurit luodaan kerran palvelinta kohden.
  const auth = createAuth(db, https, now);
  // Allowlist tarkoittaa nimenomaisesti sallittuja tiedostoja; pyydettyä polkua ei liitetä tiedostopolkuun.
  const staticFiles = new Map<string, { file: string; type: string }>([
    ["/", { file: "index.html", type: "text/html; charset=utf-8" }], // Etusivu.
    ["/index.html", { file: "index.html", type: "text/html; charset=utf-8" }], // Sama etusivu nimellään.
    ["/styles.css", { file: "styles.css", type: "text/css; charset=utf-8" }], // Selaimen tyylit.
    ["/app.js", { file: "app.js", type: "text/javascript; charset=utf-8" }], // Selaimessa ajettava JavaScript.
  ]);

  // Varsinainen reititys tuottaa vastauksen tai heittää selitetyn HTTP-virheen.
  async function dispatch(request: Request, clientIp: string): Promise<Response> {
    // pathname on esimerkiksi /api/projects; URLin kyselyosa ei kuulu tähän reittinimeen.
    const path = new URL(request.url).pathname;
    // method on HTTP-verbi kuten GET, POST, PATCH tai DELETE.
    const method = request.method;
    // Tavallisen lukupyynnön runkona käytämme tyhjää oliota.
    let body: JsonObject = {};
    // Kirjoittavien pyyntöjen suojaus tehdään ennen yhtään API:n tietokantamuutosta.
    if (isWriteMethod(method)) {
      // Tarkka Origin + JSON-sisältötyyppi suojaavat myös login-, register- ja logout-pyynnöt.
      checkWriteRequest(request, options.origin);
      // Rungon koko ja JSON-olion muoto tarkistetaan ennen kenttien käyttöä.
      body = await readJsonObject(request);
    }

    // Rekisteröinti on tarkoituksella käytettävissä ilman aiempaa istuntoa.
    if (path === "/api/auth/register") {
      // Sama URL ei tarjoa käyttäjälistaa GET-pyynnöllä.
      if (method !== "POST") throw new HttpError(405, "Rekisteröinti käyttää POST-pyyntöä.");
      // Palautamme rekisteröinnin vastauksen: julkinen käyttäjä ja istuntoeväste.
      return await auth.register(request, body, clientIp);
    }
    // Login tarkistaa olemassa olevan käyttäjän salasanan.
    if (path === "/api/auth/login") {
      // Salasanaa ei saa lähettää GET-osoitteen kyselyosassa.
      if (method !== "POST") throw new HttpError(405, "Kirjautuminen käyttää POST-pyyntöä.");
      // IP-osoite välitetään palvelimen yhteystiedoista yritysrajoitusta varten.
      return await auth.login(request, body, clientIp);
    }
    // Logoutin pitää myös toimia tilanteessa, jossa istunto on jo vanhentunut.
    if (path === "/api/auth/logout") {
      // Uloskirjautuminen muuttaa istuntotilaa, joten GET ei ole sallittu.
      if (method !== "POST") throw new HttpError(405, "Uloskirjautuminen käyttää POST-pyyntöä.");
      // Palvelimen istunnon poisto ja selaimen evästeen vanhentaminen tehdään yhdessä toiminnossa.
      return await auth.logout(request, body);
    }
    // Me tarkoittaa tässä nykyisen istunnon käyttäjää.
    if (path === "/api/auth/me") {
      // Nykyisen käyttäjän lukeminen on GET-operaatio.
      if (method !== "GET") {
        throw new HttpError(405, "Nykyisen käyttäjän haku käyttää GET-pyyntöä.");
      }
      // currentUser heittää 401-virheen, jos voimassa olevaa kirjautumista ei ole.
      return json({ user: await auth.currentUser(request) });
    }

    // Kaikki loput API-reitit vaativat kirjautumisen ennen datan lukemista tai muuttamista.
    if (path.startsWith("/api/")) {
      // Autentikointi tunnistaa käyttäjän; projects.ts tarkistaa tämän jälkeen oikeuden juuri pyydettyyn kohteeseen.
      const user = await auth.currentUser(request);
      // Reititin saa palvelimen tunnistaman käyttäjän, ei selaimen ehdottamaa käyttäjää.
      const response = handleProjects(db, method, path, user, body);
      // Jos reititin tunnisti pyynnön, palautamme sen vastauksen.
      if (response) return response;
      // Tuntemattomalle API-polulle ei tarjoilla HTML-etusivua vahingossa.
      throw new HttpError(404, "API-reittiä ei löytynyt.");
    }

    // Julkisiin tiedostoihin ei tarvita istuntoa, jotta kirjautumissivun voi avata.
    const asset = staticFiles.get(path);
    // Esimerkiksi /db.ts, /.env ja /data/tehtavataulu.sqlite eivät ole sallittujen listalla.
    if (!asset) throw new HttpError(404, "Sivua ei löytynyt.");
    // Julkiset tiedostot ovat vain luettavia GET-pyynnöillä.
    if (method !== "GET") throw new HttpError(405, "Tiedostot hyväksyvät vain GET-pyynnön.");
    // Tiedostonimi tulee yllä olevasta omasta Mapista, ei käyttäjän URLista.
    const contents = await Deno.readFile(new URL(`./public/${asset.file}`, import.meta.url));
    // Response lähettää tiedoston tavut oikealla sisältötyypillä.
    return new Response(contents, { headers: { "Content-Type": asset.type } });
  }

  // Palautettava nuolifunktio on se toiminto, jonka Deno.serve kutsuu jokaiselle pyynnölle.
  return async (request: Request, clientIp = "local-test"): Promise<Response> => {
    // Yksi try/catch keskittää virheiden käsittelyn ja pitää vastausten muodon yhtenäisenä.
    try {
      // Kaikki onnistuneetkin vastaukset saavat suojaavat HTTP-otsakkeet.
      return secureResponse(await dispatch(request, clientIp), https);
    } catch (error) {
      // instanceof erottaa omat käyttäjälle tarkoitetut virheemme odottamattomista ohjelmavirheistä.
      if (error instanceof HttpError) {
        // Virhesopimus on aina JSON {error: string}; mukana voi olla esimerkiksi Retry-After.
        return secureResponse(json({ error: error.message }, error.status, error.headers), https);
      }
      // Emme tulosta salasanoja, istuntotunnisteita tai koko pyyntörunkoa lokiin.
      console.error("Pyynnön käsittelyssä tapahtui odottamaton palvelinvirhe.");
      // Asiakas ei saa tietokantavirheen yksityiskohtia tai palvelimen tiedostopolkuja.
      return secureResponse(
        json({ error: "Palvelin ei pystynyt käsittelemään pyyntöä." }, 500),
        https,
      );
    }
  };
}
````

### `esimerkit/04-valmis/main.ts`

````typescript
// createApp kokoaa HTTP-käsittelijän; sen import ei vielä käynnistä palvelinta.
import { createApp } from "./app.ts";
// openDatabase avaa SQLite-kannan ja suorittaa puuttuvan ensimmäisen migraation.
import { openDatabase } from "./db.ts";

// Ympäristömuuttuja on käynnistyksen asetus. ?? antaa oletuksen, jos arvo puuttuu.
const hostname = Deno.env.get("APP_HOST") ?? "127.0.0.1";
// Oletuksena kuunnellaan vain oman tietokoneen IPv4-osoitetta; Dockerissa tarvitaan 0.0.0.0.
const port = Number(Deno.env.get("APP_PORT") ?? "8000");
// Selain käyttää tätä täsmällistä osoitetta. Esimerkiksi localhost ja 127.0.0.1 ovat eri origineja.
const origin = Deno.env.get("APP_ORIGIN") ?? "http://localhost:8000";
// Väärää porttiasetusta ei hyväksytä hiljaisesti.
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("APP_PORT pitää olla kokonaisluku 1–65535.");
}
// Pilkomme julkisen osoitteen voidaksemme rajata HTTP-käytön paikalliseen harjoitteluun.
const publicUrl = new URL(origin);
// HTTP ilman salausta sallitaan vain paikalliselle palvelulle; etäkäyttö tarvitsee HTTPS:n.
if (
  publicUrl.protocol === "http:" &&
  !["localhost", "127.0.0.1", "[::1]"].includes(publicUrl.hostname)
) {
  // HTTPS voidaan toteuttaa esimerkiksi oikein asetetussa käänteisvälityspalvelimessa.
  throw new Error("Käytä etäpalvelun APP_ORIGIN-asetuksessa HTTPS-osoitetta.");
}
// recursive sallii jo olemassa olevan hakemiston: aiempaa opiskelijan dataa ei poisteta.
await Deno.mkdir("./data", { recursive: true });
// Tietokanta ja sen mahdolliset WAL-aputiedostot pysyvät data-hakemistossa.
const db = openDatabase("./data/tehtavataulu.sqlite");
// Annamme saman tietokannan ja sallitun originin kaikille pyynnöille.
const app = createApp(db, { origin });
// Deno.serve avaa verkkokuuntelun. Parametrin infosta luetaan todellinen yhdistäneen asiakkaan osoite.
const server = Deno.serve(
  { hostname, port },
  (request, info) => app(request, info.remoteAddr.hostname),
);
// Tämä loki auttaa avaamaan juuri Origin-tarkistuksen hyväksymän osoitteen.
console.log(`Avaa selain osoitteeseen ${origin}. Lopeta painamalla Ctrl+C.`);
// Tämä lippu estää kahden samanaikaisen sammutuspyynnön käynnistämisen.
let closing = false;
// Signaalikäsittelijä kutsutaan esimerkiksi Ctrl+C-painalluksesta.
function shutdown(): void {
  // Uusi sammutus aloitetaan vain, jos edellinen ei ole jo käynnissä.
  if (!closing) {
    // Tallennamme tilan ennen asynkronista sammutusta.
    closing = true;
    // void kertoo, että emme odota Promisea tässä synkronisessa signaalikäsittelijässä.
    void server.shutdown();
  }
}
// SIGINT on keskeytyssignaali, jonka Ctrl+C tavallisesti lähettää.
Deno.addSignalListener("SIGINT", shutdown);
// Windows ei tue samaa SIGTERM-signaalia; Dockerin Linux-ympäristössä se sammuttaa kontin siististi.
if (Deno.build.os !== "windows") Deno.addSignalListener("SIGTERM", shutdown);
// Odotamme, että palvelin on oikeasti päättänyt pyyntöjen käsittelyn.
try {
  // Top-level await on Denossa sallittu: päämoduuli voi odottaa Promisea.
  await server.finished;
} finally {
  // Poistamme rekisteröidyn signaalikäsittelijän ennen poistumista.
  Deno.removeSignalListener("SIGINT", shutdown);
  // Poistamme myös Linuxissa tai macOS:ssä lisätyn SIGTERM-käsittelijän.
  if (Deno.build.os !== "windows") Deno.removeSignalListener("SIGTERM", shutdown);
  // Yhteys suljetaan vasta palvelimen pysähdyttyä.
  db.close();
}
````

### `esimerkit/04-valmis/deno.jsonc`

````jsonc
// JSONC on JSON-muotoinen asetustiedosto, jossa //-kommentit ovat sallittuja.
{
  // tasks antaa komennoille lyhyet nimet: esimerkiksi deno task start.
  "tasks": {
    // start: run suorittaa ohjelman; --no-prompt estää odottamattomat lupakyselyt.
    // --allow-read sallii vain datan, julkiset tiedostot ja oman migraation lukemisen.
    // --allow-write sallii vain data-hakemistoon kirjoittamisen, myös SQLite-aputiedostot.
    // --allow-net rajaa kuuntelun paikalliseen osoitteeseen tai Dockerin 0.0.0.0-osoitteeseen portissa 8000.
    // --allow-env sallii vain kolme nimettyä asetusta. Porttia muutettaessa muuta myös verkkolupaa.
    "start": "deno run --no-prompt --allow-read=./data,./public,./01_create_schema.sql --allow-write=./data --allow-net=127.0.0.1:8000,0.0.0.0:8000 --allow-env=APP_HOST,APP_PORT,APP_ORIGIN main.ts",
    // dev käyttää samoja rajattuja lupia; --watch käynnistää ohjelman uudelleen lähdetiedoston muuttuessa.
    "dev": "deno run --watch=./public --no-prompt --allow-read=./data,./public,./01_create_schema.sql --allow-write=./data --allow-net=127.0.0.1:8000,0.0.0.0:8000 --allow-env=APP_HOST,APP_PORT,APP_ORIGIN main.ts",
    // check tarkistaa TypeScript-tyypit suorittamatta HTTP-palvelinta tai muokkaamatta tietokantaa.
    "check": "deno check main.ts integration_test.ts seed/admin.ts",
    // test käyttää omaa muistissa tai väliaikaisessa alihakemistossa olevaa kantaa, ei opiskelijan sovelluskantaa.
    // Testit kutsuvat oikeaa Request -> Response -käsittelijää, joten ne eivät tarvitse verkkolupaa.
    "test": "deno test --no-prompt --allow-read=./data,./public,./01_create_schema.sql --allow-write=./data integration_test.ts",
    // admin ylentää jo rekisteröidyn käyttäjän; lisää sähköpostiosoite task-komennon loppuun.
    "admin": "deno run --no-prompt --allow-read=./data,./01_create_schema.sql --allow-write=./data seed/admin.ts",
    // fmt yhdenmukaistaa sisennykset ja rivinvaihdot, jotta koodia on helpompi lukea yhdessä.
    "fmt": "deno fmt",
    // lint etsii yleisiä koodivirheitä; se ei korvaa tietoturva- tai käyttöoikeustestejä.
    "lint": "deno lint"
  },
  // compilerOptions muuttaa TypeScriptin ennen ajoa tekemiä tarkistuksia.
  "compilerOptions": {
    // strict vaatii täsmällistä tyypitystä ja esimerkiksi puuttuvien arvojen huomioimista.
    "strict": true
  },
  // fmt-asetukset ohjaavat deno fmt -komennon tulostyyliä.
  "fmt": {
    // Kohtuullinen rivipituus auttaa näyttämään koodia luennolla ja rinnakkain editorissa.
    "lineWidth": 100
  },
  // excludes rajaa generoidut tietokantatiedostot pois kehitystyökalujen tiedostojen läpikäynnistä.
  "exclude": ["data"]
}
````

### `esimerkit/04-valmis/.gitignore`

````text
# data sisältää paikalliset käyttäjät ja istunnot, joten sitä ei tallenneta Gitiin.
data/
# Älä lisää oikeita asetussalaisuuksia; .env.example on vain julkinen mallipohja.
.env
.env.*
!.env.example
# Myös muualle vahingossa luotu tietokanta ja sen apuosat jätetään pois.
*.sqlite
*.sqlite-*
*.db
*.db-*
````

## 12.7 Valmiin sovelluksen frontend

### `esimerkit/04-valmis/public/index.html`

````html
<!-- DOCTYPE kertoo selaimelle, että tiedosto käyttää nykyistä HTML-kieltä. -->
<!doctype html>
<!-- html ympäröi koko sivun; lang="fi" kertoo tekstin olevan suomea. -->
<html lang="fi">
  <!-- head sisältää sivun asetukset, joita ei näytetä varsinaisena sisältönä. -->
  <head>
    <!-- charset="utf-8" saa esimerkiksi ä- ja ö-kirjaimet näkymään oikein. -->
    <meta charset="utf-8">
    <!-- viewport sovittaa sivun laitteen leveyteen; zoomausta ei estetä. -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title näkyy selaimen välilehdessä ja auttaa tunnistamaan sivun. -->
    <title>Tehtävätaulu – omat projektit</title>
    <!-- rel kertoo tiedoston olevan tyyliohje; href on CSS-tiedoston osoite. -->
    <link rel="stylesheet" href="/styles.css">
    <!-- src osoittaa JavaScriptiin; defer odottaa HTML:n jäsentämisen valmistumista. -->
    <script src="/app.js" defer></script>
  </head>
  <!-- body sisältää käyttäjälle näkyvän sivun. -->
  <body>
    <!-- a on linkki; href siirtää pääsisältöön; class yhdistää CSS:n ohituslinkkityyliin. -->
    <a class="skip-link" href="#main-content">Siirry pääsisältöön</a>
    <!-- header on sivun aloitusosa; class rajaa sisällön luettavaan leveyteen. -->
    <header class="page-header">
      <!-- h1 on sivun ainoa ylimmän tason otsikko. -->
      <h1>Tehtävätaulu</h1>
      <!-- p muodostaa tekstikappaleen. -->
      <p>Pidä omat projektit ja niihin kuuluvat tehtävät järjestyksessä.</p>
    </header>
    <!-- main on pääsisältö; id on ohituslinkin kohde; tabindex="-1" sallii kohdistuksen koodista. -->
    <main id="main-content" tabindex="-1">
      <!-- noscript näytetään, jos JavaScriptin suoritus on estetty selaimessa. -->
      <noscript>Tämä harjoitussovellus tarvitsee JavaScriptin. Ota se käyttöön selaimen asetuksissa.</noscript>
      <!-- id löytää viestikentän koodista; role ja aria-live ilmoittavat muutokset rauhallisesti; aria-atomic lukee koko viestin. -->
      <p id="status" class="message" role="status" aria-live="polite" aria-atomic="true">Tarkistetaan kirjautumista…</p>
      <!-- role="alert" ilmoittaa virheestä heti; tyhjä elementti säilyy sivulla viestien vastaanottamista varten. -->
      <p id="error" class="error-message" role="alert" aria-atomic="true"></p>
      <!-- section ryhmittelee tunnistautumisen; id auttaa koodia; aria-labelledby nimeää osion otsikon perusteella; hidden piilottaa sen aluksi. -->
      <section id="auth-section" aria-labelledby="auth-title" hidden>
        <!-- id sitoo tämän h2-alaotsikon edellisen osion saavutettavaan nimeen. -->
        <h2 id="auth-title">Kirjaudu tai luo tunnus</h2>
        <!-- class liittää tähän apukappaleeseen hillityn mutta luettavan tekstityylin. -->
        <p class="hint">Kaikki alla olevat kentät ovat pakollisia. Harjoittelussa käytä keksittyä sähköpostiosoitetta ja salasanaa, jota et käytä muualla.</p>
        <!-- div ryhmittelee kaksi lomaketta asettelua varten; class käyttää joustavaa ruudukkoa. -->
        <div class="two-columns">
          <!-- form kerää kirjautumiskentät; id yhdistää lomakkeen JavaScriptiin; aria-labelledby antaa sille nimen. -->
          <form id="login-form" class="card" aria-labelledby="login-title">
            <!-- h3 on h2-otsikon alainen lomakkeen otsikko; id nimeää lomakkeen. -->
            <h3 id="login-title">Kirjaudu sisään</h3>
            <!-- label nimeää kentän; for vastaa täsmälleen inputin id:tä. -->
            <label for="login-email">Sähköpostiosoite</label>
            <!-- type tarkistaa sähköpostin muodon; id yhdistää labelin; name nimeää tiedon; autocomplete auttaa täyttämistä; required tekee kentästä pakollisen; maxlength rajaa pituuden. -->
            <input id="login-email" name="email" type="email" autocomplete="username" required maxlength="254">
            <!-- for yhdistää salasanan näkyvän nimen oikeaan kenttään. -->
            <label for="login-password">Salasana</label>
            <!-- password peittää kirjoituksen; current-password kertoo tallennetusta salasanasta; required tekee kentästä pakollisen; JavaScript ja palvelin tarkistavat pituuden muuttamatta salasanaa. -->
            <input id="login-password" name="password" type="password" autocomplete="current-password" required>
            <!-- submit lähettää lomakkeen myös Enter-näppäimellä. -->
            <button type="submit">Kirjaudu sisään</button>
          </form>
          <!-- Toinen form on rekisteröinnille; id löytää sen koodista ja aria-labelledby nimeää sen. -->
          <form id="register-form" class="card" aria-labelledby="register-title">
            <!-- h3 kertoo tämän lomakkeen tarkoituksen; id yhdistää sen lomakkeeseen. -->
            <h3 id="register-title">Luo tunnus</h3>
            <!-- labelin for yhdistyy rekisteröinnin sähköpostikenttään. -->
            <label for="register-email">Sähköpostiosoite</label>
            <!-- email on selaimen sähköpostikenttä; name nimeää arvon; autocomplete auttaa tunnuksen syöttämistä; required ja maxlength rajaavat kenttää. -->
            <input id="register-email" name="email" type="email" autocomplete="username" required maxlength="254">
            <!-- labelin for yhdistyy uuden salasanan kenttään. -->
            <label for="register-password">Uusi salasana</label>
            <!-- aria-describedby yhdistää kenttään ohjeen; muut attribuutit nimeävät pakollisen uuden salasanan; pituus tarkistetaan JavaScriptissä ja palvelimella samoina Unicode-koodipisteinä. -->
            <input id="register-password" name="password" type="password" autocomplete="new-password" required aria-describedby="password-hint">
            <!-- id yhdistää ohjeen kenttään; class antaa yhteisen ohjetyylin. -->
            <p id="password-hint" class="hint">15–128 merkkiä. Voit käyttää pitkää, helposti muistettavaa lausetta. Erikoismerkki ei ole pakollinen.</p>
            <!-- submit käynnistää juuri rekisteröintilomakkeen käsittelyn. -->
            <button type="submit">Luo tunnus ja kirjaudu</button>
          </form>
        </div>
      </section>
      <!-- section sisältää kirjautuneen näkymän; hidden poistaa sen aluksi myös näppäimistöjärjestyksestä. -->
      <section id="workspace" aria-labelledby="workspace-title" hidden>
        <!-- h2 nimeää kirjautuneen työtilan; id on aria-labelledby-viittauksen kohde. -->
        <h2 id="workspace-title">Oma työtila</h2>
        <!-- div ryhmittelee käyttäjätiedon ja uloskirjautumisen samalle joustavalle riville. -->
        <div class="account-row">
          <!-- JavaScript kirjoittaa kirjautuneen osoitteen tähän p-elementtiin id:n avulla. -->
          <p id="account-email"></p>
          <!-- button on toiminto; type="button" estää tahattoman lomakelähetyksen; id yhdistää käsittelijään. -->
          <button id="logout-button" type="button" class="secondary">Kirjaudu ulos</button>
        </div>
        <!-- div muodostaa leveällä näytöllä kaksi saraketta; kapealla sisältö pysyy yhdessä sarakkeessa. -->
        <div class="two-columns">
          <!-- section nimeää projektialueen h3-otsikosta; class tekee näkyvän kortin. -->
          <section class="card" aria-labelledby="projects-title">
            <!-- h3 kertoo projektialueen tarkoituksen; id nimeää osion. -->
            <h3 id="projects-title">Omat projektit</h3>
            <!-- form kerää uuden projektin; id yhdistää luontitoimintoon. -->
            <form id="project-create-form">
              <!-- for nimeää uuden projektin kentän; pakollisuus kerrotaan tekstinä. -->
              <label for="new-project-title">Uuden projektin nimi (pakollinen)</label>
              <!-- text on tavallinen tekstikenttä; name nimeää arvon; required tekee kentästä pakollisen; Unicode-pituus tarkistetaan JavaScriptissä ja palvelimella. -->
              <input id="new-project-title" name="title" type="text" required>
              <!-- submit käynnistää projektin tallentamisen. -->
              <button type="submit">Luo projekti</button>
            </form>
            <!-- id löytää tyhjän listan ohjeen; class antaa ohjetekstin ulkoasun. -->
            <p id="project-empty" class="hint">Sinulla ei vielä ole projekteja. Luo ensimmäinen projekti yllä.</p>
            <!-- ul on järjestämätön lista; id löytää sen koodista; class poistaa luettelomerkit; role säilyttää listan tunnistuksen myös ilman merkkejä. -->
            <ul id="project-list" class="project-list" role="list"></ul>
          </section>
          <!-- section sisältää valitun projektin; hidden piilottaa osion ennen valintaa; aria-labelledby käyttää muuntuvaa otsikkoa. -->
          <section id="project-detail" class="card" aria-labelledby="project-title" hidden>
            <!-- id löytää muuntuvaotsikon; tabindex="-1" sallii koodin kohdistaa otsikon projektin valinnan jälkeen. -->
            <h3 id="project-title" tabindex="-1">Valitse projekti</h3>
            <!-- form muokkaa valitun projektin nimeä; id erottaa sen luontilomakkeesta. -->
            <form id="project-rename-form">
              <!-- label kertoo muokattavan arvon ja sen pakollisuuden. -->
              <label for="project-name">Projektin nimi (pakollinen)</label>
              <!-- id yhdistää labelin; name nimeää arvon; text on tekstikenttä; required tekee siitä pakollisen; Unicode-pituus tarkistetaan JavaScriptissä ja palvelimella. -->
              <input id="project-name" name="title" type="text" required>
              <!-- submit tallentaa nimenmuutoksen. -->
              <button type="submit" class="secondary">Tallenna projektin nimi</button>
            </form>
            <!-- details antaa selaimen oman avattavan lisäosan projektin poistamiselle. -->
            <details>
              <!-- summary on näppäimistöllä avattava lisäosan otsikko. -->
              <summary>Projektin poistaminen</summary>
              <!-- p kertoo poistamisen seurauksen ennen toimintoa. -->
              <p>Projektin poistaminen poistaa myös kaikki sen tehtävät. Sovellus pyytää vielä vahvistuksen.</p>
              <!-- id yhdistää poistokäsittelijään; button ei lähetä lomaketta; danger erottaa ulkoasun tekstin lisäksi. -->
              <button id="project-delete-button" type="button" class="danger">Poista projekti ja sen tehtävät</button>
            </details>
            <!-- h4 on tämän projektin alainen tehtäväotsikko. -->
            <h4>Tehtävät</h4>
            <!-- form kerää uuden tehtävän; id yhdistää lomakkeen käsittelijään. -->
            <form id="task-create-form">
              <!-- for yhdistyy uuden tehtävän tekstikenttään. -->
              <label for="new-task-title">Uusi tehtävä (pakollinen)</label>
              <!-- id yhdistää labelin; name nimeää arvon; text määrittää kenttätyypin; required tekee kentästä pakollisen; Unicode-pituus tarkistetaan JavaScriptissä ja palvelimella. -->
              <input id="new-task-title" name="title" type="text" required>
              <!-- submit tallentaa uuden tehtävän valittuun projektiin. -->
              <button type="submit">Lisää tehtävä</button>
            </form>
            <!-- id löytää kappaleen, jossa kerrotaan lukumäärä tai tyhjän/lataavan tilan ohje. -->
            <p id="task-summary" class="hint">Projektilla ei vielä ole tehtäviä.</p>
            <!-- ul kertoo tehtävien olevan lista; id löytää sen koodista; class muotoilee listan; role säilyttää listan tunnistuksen myös ilman luettelomerkkejä. -->
            <ul id="task-list" class="task-list" role="list"></ul>
          </section>
        </div>
        <!-- section näkyy vain ylläpitäjälle; hidden ei ole käyttöoikeussuoja, jonka palvelin tekee erikseen. -->
        <section id="admin-section" class="card" aria-labelledby="admin-title" hidden>
          <!-- h3 nimeää ylläpito-osion; id yhdistää siihen aria-labelledby-viittauksen. -->
          <h3 id="admin-title">Ylläpidon lukumäärät</h3>
          <!-- id yhdistää tilastohakuun; type="button" tekee erillisen toiminnon. -->
          <button id="stats-button" type="button" class="secondary">Hae lukumäärät</button>
          <!-- id on tilastotekstin kohde; p näyttää tiedon tavallisena luettavana tekstinä. -->
          <p id="stats-output">Lukumääriä ei ole vielä haettu.</p>
        </section>
      </section>
    </main>
    <!-- footer on sivun loppuosa; class rajaa leveyden samaan tapaan kuin header. -->
    <footer class="page-footer">
      <!-- p kertoo sovelluksen tarkoituksen lyhyesti. -->
      <p>Tehtävätaulu · web-ohjelmoinnin harjoitussovellus</p>
    </footer>
  </body>
</html>
````

### `esimerkit/04-valmis/public/styles.css`

````css
/* Tähti valitsee kaikki elementit. ::before ja ::after ovat CSS:n tuottamia lisäosia. */
*,
*::before,
*::after {
  /* Leveys sisältää täytteet ja reunukset, joten kentät eivät kasva vanhempaansa leveämmiksi. */
  box-sizing: border-box;
}

/* html on koko sivun juurielementti. */
html {
  /* 100 % kunnioittaa selaimen tai käyttäjän valitsemaa tekstin peruskokoa. */
  font-size: 100%;
  /* Tällä sivulla kentille pyydetään vaaleaa käyttöjärjestelmäteemaa. */
  color-scheme: light;
}

/* body määrittää koko näkyvän sivun oletustyylit. */
body {
  /* Poistetaan selaimen oletusmarginaali. */
  margin: 0;
  /* Käytetään laitteen omia kirjasimia ilman ulkoista latausta. */
  font-family: system-ui, sans-serif;
  /* Rivien väliin jätetään tilaa lukemisen helpottamiseksi. */
  line-height: 1.6;
  /* Tumma teksti erottuu vaaleasta taustasta. */
  color: #172b3a;
  /* Vaalea sivutausta erottaa valkoiset sisältökortit. */
  background: #f4f7fa;
  /* Pitkä sana saa katketa, jotta sivu ei levene puhelimessa. */
  overflow-wrap: anywhere;
}

/* Pilkku antaa saman säännön kolmelle sisältöalueelle. */
.page-header,
main,
.page-footer {
  /* Sisältö vie enintään 72 peruskirjasimen levyistä rem-yksikköä mutta jättää reunoille tilaa. */
  width: min(72rem, calc(100% - 2rem));
  /* Automaattiset sivumarginaalit keskittävät alueen. */
  margin-inline: auto;
}

/* Sivun aloitus saa oman pystysuuntaisen täytteensä. */
.page-header {
  /* block tarkoittaa tavanomaisessa suomenkielisessä sivussa ylä- ja alareunaa. */
  padding-block: 2rem 0.5rem;
}

/* Pääotsikko erottuu selkeästi. */
h1 {
  /* clamp säätää kokoa näkymän mukaan mutta pitää minimi- ja maksimikoon. */
  font-size: clamp(2rem, 5vw, 3rem);
  /* Otsikon riviväli on leipätekstiä tiiviimpi. */
  line-height: 1.15;
}

/* Kaikilla otsikkotasoilla on yhteinen ylä- ja alaväli. */
h1,
h2,
h3,
h4 {
  /* Yläpuolelle ei tule oletusmarginaalia; alle jää 0,75 rem. */
  margin-block: 0 0.75rem;
}

/* Alueet erotetaan pystysuunnassa toisistaan. */
section {
  /* margin-block lisää tilaa alueen ylä- ja alapuolelle. */
  margin-block: 1rem;
}

/* Tämä luokka antaa samat korttityylit lomakkeelle ja osiolle. */
.card {
  /* Pienin leveys nolla sallii kortin kaventumisen ruudukossa. */
  min-width: 0;
  /* Sisäreunus jättää tekstille hengitystilaa. */
  padding: 1.25rem;
  /* Selkeä tummahko reunus erottaa kortin taustasta. */
  border: 1px solid #718096;
  /* Hieman pyöristetty reuna on vain ulkoasuvalinta. */
  border-radius: 0.5rem;
  /* Kortin tausta on valkoinen. */
  background: #ffffff;
}

/* Kahden alueen asettelu alkaa yhdestä sarakkeesta pienillä näytöillä. */
.two-columns {
  /* grid käynnistää CSS-ruudukon. */
  display: grid;
  /* Yksi joustava sarake saa tarvittaessa kaventua nollaan. */
  grid-template-columns: minmax(0, 1fr);
  /* gap on sarakkeiden ja rivien välinen tyhjä tila. */
  gap: 1.25rem;
  /* Kunkin kortin yläreuna alkaa samasta kohdasta; kortteja ei venytetä yhtä korkeiksi. */
  align-items: start;
}

/* Vasta riittävän leveässä näkymässä näytetään kaksi saraketta. */
@media (min-width: 52rem) {
  /* Tämä sääntö korvaa vain ruudukon sarakemäärän. */
  .two-columns {
    /* Kaksi yhtä suurta saraketta; fr on osuus vapaasta tilasta. */
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

/* Tunnuksen ja uloskirjautumisen rivi saa tarvittaessa taittua. */
.account-row,
.task-actions {
  /* flex asettelee lapset peräkkäin riville. */
  display: flex;
  /* wrap sallii siirtymisen seuraavalle riville pienessä tilassa. */
  flex-wrap: wrap;
  /* Kohdistetaan lapset pystysuunnassa keskelle. */
  align-items: center;
  /* Jätetään lasten väliin tasainen etäisyys. */
  gap: 0.75rem;
}

/* Lomakkeen kentän nimi näytetään omalla rivillään. */
label {
  /* block käyttää rivin koko leveyden. */
  display: block;
  /* Lihavointi erottaa nimen ohjetekstistä. */
  font-weight: 650;
  /* Annetaan ylä- ja alapuolelle eri kokoiset välit. */
  margin-block: 0.75rem 0.25rem;
}

/* Tavallinen syöte ja painike perivät luettavan kirjasinkoon. */
input,
button {
  /* inherit kopioi ympäröivän sisällön kirjasintyylin. */
  font: inherit;
  /* Vähintään 44 CSS-pikselin korkeus helpottaa osoittamista. */
  min-height: 44px;
  /* Sisätäyte pitää tekstin irti reunoista. */
  padding: 0.55rem 0.8rem;
  /* Näkyvä reunus auttaa erottamaan kentän. */
  border: 2px solid #586577;
  /* Kenttien ja painikkeiden kulmat ovat hieman pyöristetyt. */
  border-radius: 0.35rem;
}

/* Tekstisyötteet täyttävät oman vanhempansa leveyden. */
input {
  /* width huomioi myös reunuksen box-sizing-säännön vuoksi. */
  width: 100%;
  /* Kenttä saa kaventua pienellä näytöllä. */
  min-width: 0;
  /* Teksti on tummaa. */
  color: #172b3a;
  /* Syöttöalueen tausta on valkoinen. */
  background: #ffffff;
}

/* Peruspainike erottuu valkoisella tekstillä tummasta pohjasta. */
button {
  /* Painikkeen teksti on valkoista. */
  color: #ffffff;
  /* Tumma sinivihreä on riittävän selkeä valkoisen tekstin tausta. */
  background: #174e5c;
  /* Reunus käyttää samaa tummaa väriä. */
  border-color: #174e5c;
  /* Painiketta ei pakoteta pysymään yhdellä rivillä. */
  white-space: normal;
  /* Osoitin kertoo hiirikäyttäjälle painettavasta kohteesta. */
  cursor: pointer;
}

/* Lomakkeen suorana lapsena oleva painike saa väliä edeltävään kenttään. */
form > button {
  /* Vain yläreunan marginaalia muutetaan. */
  margin-top: 0.75rem;
}

/* Toissijainen painike näyttää eri toiminnolta mutta säilyttää näkyvän reunuksen. */
button.secondary {
  /* Tumma teksti pysyy luettavana valkoisella. */
  color: #172b3a;
  /* Valkoinen tausta erottaa toissijaisen toiminnon. */
  background: #ffffff;
}

/* Poistopainike erotetaan värin lisäksi aina myös Poista-tekstillä. */
button.danger {
  /* Tumma punainen antaa valkoiselle tekstille vahvan kontrastin. */
  background: #8f1d21;
  /* Reunus vastaa taustaa. */
  border-color: #8f1d21;
}

/* disabled tarkoittaa, ettei toiminto ole juuri nyt käytettävissä. */
button:disabled,
input:disabled {
  /* Harmaa pohja kertoo odottamisesta ilman voimakasta himmennystä. */
  background: #e0e7ed;
  /* Teksti säilyy tummana ja luettavana. */
  color: #334155;
  /* Reunus näkyy myös odotustilassa. */
  border-color: #64748b;
  /* Osoitin näyttää, ettei painaminen juuri nyt onnistu. */
  cursor: wait;
}

/* focus-visible näyttää selaimen tunnistaman näppäimistökohdistuksen kaikissa kohteissa. */
:focus-visible {
  /* Kolmen pikselin tumma sininen ääriviiva erottuu sivun taustasta. */
  outline: 3px solid #005fcc;
  /* Ääriviiva siirretään irti kohteen reunasta. */
  outline-offset: 3px;
}

/* Tila- ja virheviestit saavat yhteisen tilan ympärilleen. */
.message,
.error-message {
  /* Pysty- ja vaakasuuntainen täyte parantaa luettavuutta. */
  padding: 0.75rem 1rem;
  /* Näkyvä vasen reunus erottaa viestin sisällöstä. */
  border-left: 4px solid #174e5c;
  /* Viestin pohja on vaalea sininen. */
  background: #e5eff7;
}

/* Virheellä on myös oma tekstiväri; teksti kertoo aina virheen syyn. */
.error-message {
  /* Tumma punainen teksti sopii vaaleaan virhepohjaan. */
  color: #7e1720;
  /* Reunus käyttää tekstin sävyä. */
  border-color: #7e1720;
  /* Hyvin vaalea punainen erottaa viestityypin. */
  background: #fff2f3;
}

/* Tyhjä virhealue säilyy DOMissa mutta ei tarvitse näkyvää laatikkoa. */
.error-message:empty {
  /* Poistetaan tyhjän viestin marginaalit. */
  margin: 0;
  /* Poistetaan tyhjän viestin täytteet. */
  padding: 0;
  /* Poistetaan tyhjän viestin reunus. */
  border: 0;
}

/* Ohjeet ovat yhtä suuria kuin muu teksti, mutta väriltään hieman hillitympiä. */
.hint {
  /* Tämä tummanharmaa säilyttää hyvän kontrastin valkoiseen. */
  color: #425568;
}

/* Sovelluksen listat saavat korttimaisen ulkoasun. */
.project-list,
.task-list {
  /* Poistetaan vain visuaaliset luettelomerkit; HTML:n role="list" säilyttää listamerkityksen. */
  list-style: none;
  /* Listalla ei ole vasenta sisennystä. */
  padding: 0;
  /* Jätetään listan yläpuolelle tilaa. */
  margin-block: 1rem 0;
}

/* Projektipainike täyttää listarivinsä. */
.project-list button {
  /* Painike ulottuu listan leveydelle. */
  width: 100%;
  /* Nimi alkaa suomen lukusuunnan alusta. */
  text-align: start;
  /* Projektien väliin jää pieni rako. */
  margin-bottom: 0.5rem;
}

/* aria-current kertoo myös avustavalle teknologialle valitun projektin. */
.project-list button[aria-current="true"] {
  /* Valitun projektin nimen alleviivaus on värin lisäksi näkyvä merkki. */
  text-decoration: underline;
  /* Paksumpi teksti korostaa valintaa. */
  font-weight: 750;
}

/* Jokainen tehtävä on listan li-elementti. */
.task-item {
  /* Yläreuna erottaa tehtävät toisistaan. */
  border-top: 1px solid #718096;
  /* Pystysuuntainen täyte tekee tehtävistä erillisiä alueita. */
  padding-block: 1rem;
}

/* Tehtävän valintaruutu ja sen nimi pysyvät samassa joustavassa ryhmässä. */
.task-toggle {
  /* flex asettaa valintaruudun nimen viereen. */
  display: flex;
  /* Kohdistetaan valintaruutu tekstin ensimmäiselle alueelle. */
  align-items: start;
  /* Ruudun ja nimen väliin jätetään tilaa. */
  gap: 0.75rem;
}

/* Vain checkbox-tyyppiset syötteet saavat tämän koon. */
input[type="checkbox"] {
  /* Valintaruutu ei täytä koko rivin leveyttä. */
  width: 1.5rem;
  /* Ruudun korkeus vastaa sen leveyttä. */
  height: 1.5rem;
  /* Ohitetaan muiden syötteiden 44 pikselin vähimmäiskorkeus; suuri label laajentaa painettavaa aluetta. */
  min-height: 1.5rem;
  /* Ruutu ei kutistu pitkän tekstin vieressä. */
  flex-shrink: 0;
  /* Valitun ruudun väri sopii painikkeisiin. */
  accent-color: #174e5c;
}

/* Valintaruudun näkyvä label tarjoaa koko nimialueen painettavaksi. */
.task-toggle label {
  /* Label ottaa riviltä jäljelle jäävän tilan. */
  flex: 1;
  /* Vähimmäiskorkeus pitää painettavan alueen suurena. */
  min-height: 44px;
  /* Poistetaan tekstikenttälabelien marginaali. */
  margin: 0;
}

/* detailsin yhteenveto on selaimen oma avattava painike. */
summary {
  /* Osoitin kertoo lisäosan olevan avattava. */
  cursor: pointer;
  /* Riittävä korkeus helpottaa valintaa. */
  min-height: 44px;
  /* Täyte erottaa tekstin ympäröivästä sisällöstä. */
  padding-block: 0.6rem;
  /* Alleviivaus auttaa tunnistamaan toiminnon. */
  text-decoration: underline;
}

/* Ohituslinkki odottaa sivun alussa näkymän ulkopuolella. */
.skip-link {
  /* Absoluuttinen sijoitus estää piilotettua linkkiä varaamasta tilaa. */
  position: absolute;
  /* Linkki jää vasemman reunan ulkopuolelle, kunnes se saa kohdistuksen. */
  left: -10000px;
  /* Yläreunassa on pieni turvaväli näkyvää tilaa varten. */
  top: 0.5rem;
  /* Vaalea tausta erottaa näkyviin tulevan linkin. */
  background: #ffffff;
  /* Tumma linkkiväri erottuu valkoisesta. */
  color: #174e5c;
  /* Näkyvä linkki saa painettavaa aluetta. */
  padding: 0.75rem;
  /* Linkki näkyy muiden elementtien päällä kohdistettaessa. */
  z-index: 10;
}

/* Myös ohjelmallinen focus tuo ohituslinkin näkyviin. */
.skip-link:focus {
  /* Linkki siirtyy vasempaan reunaan näkyviin. */
  left: 1rem;
}

/* hidden-attribuutti piilottaa sisällön riippumatta muista asettelusäännöistä. */
[hidden] {
  /* important varmistaa, ettei myöhempi display-sääntö vahingossa näytä piilotettua aluetta. */
  display: none !important;
}

/* Sivun loppuun jätetään tilaa myös pienellä näytöllä. */
.page-footer {
  /* Pystysuuntainen täyte erottaa lopputekstin pääsisällöstä. */
  padding-block: 2rem;
}
````

### `esimerkit/04-valmis/public/app.js`

````javascript
// Tämä tiedosto on selaimen JavaScriptiä. Backendin TypeScript suoritetaan erikseen Denossa.
// Tiukka tila auttaa huomaamaan esimerkiksi vahingossa luodut nimeämättömät muuttujat.
"use strict";

// state on olio: yhteen nimettyyn kokonaisuuteen kerätään käyttöliittymän tämänhetkiset tiedot.
const state = {
  // null tarkoittaa, ettei kirjautunutta käyttäjää ole vielä tiedossa.
  user: null,
  // Tyhjä taulukko [] pitää myöhemmin sisällään palvelimen palauttamat projektit.
  projects: [],
  // Tähän taulukkoon ladataan vain valitun projektin tehtävät.
  tasks: [],
  // Valitun projektin kokonaislukutunniste tallennetaan tähän; aluksi valintaa ei ole.
  selectedProjectId: null,
  // busy kertoo, odotetaanko verkkopyynnön valmistumista.
  busy: false,
};

// ui-olion ominaisuuksiin tallennetaan viittaukset HTML-elementteihin.
const ui = {
  // querySelector etsii CSS-valitsimella; # tarkoittaa HTML:n id-attribuuttia.
  status: document.querySelector("#status"),
  // Virheviesti näytetään tekstinä tässä jo HTML:ssä olevassa alert-alueessa.
  error: document.querySelector("#error"),
  // Tämä alue sisältää kirjautumisen ja rekisteröinnin.
  auth: document.querySelector("#auth-section"),
  // Kirjautumislomakkeeseen liitetään myöhemmin submit-kuuntelija.
  login: document.querySelector("#login-form"),
  // Rekisteröintilomakkeella on oma kuuntelijansa.
  register: document.querySelector("#register-form"),
  // Työtila näytetään vasta onnistuneen tunnistautumisen jälkeen.
  workspace: document.querySelector("#workspace"),
  // Tähän tulostetaan kirjautuneen käyttäjän sähköpostiosoite.
  account: document.querySelector("#account-email"),
  // Uloskirjautumispainike päättää palvelimen istunnon.
  logout: document.querySelector("#logout-button"),
  // Projektin luontilomake pitää sisällään uuden nimen.
  projectCreate: document.querySelector("#project-create-form"),
  // Projektirivit lisätään tähän ul-listaan.
  projectList: document.querySelector("#project-list"),
  // Tyhjän projektilistan ohje voidaan näyttää ja piilottaa.
  projectEmpty: document.querySelector("#project-empty"),
  // Valitun projektin sisältö on omassa osiossaan.
  detail: document.querySelector("#project-detail"),
  // Otsikko päivittyy valitun projektin nimen mukaan.
  projectTitle: document.querySelector("#project-title"),
  // Tämä lomake muuttaa olemassa olevan projektin nimeä.
  projectRename: document.querySelector("#project-rename-form"),
  // Tämä painike poistaa valitun projektin kaikkine tehtävineen.
  projectDelete: document.querySelector("#project-delete-button"),
  // Tehtävän luontilomake kuuluu aina valittuun projektiin.
  taskCreate: document.querySelector("#task-create-form"),
  // Tehtävärivit lisätään tähän ul-listaan.
  taskList: document.querySelector("#task-list"),
  // Tässä kerrotaan tehtävien määrä tai tyhjän listan ohje.
  taskSummary: document.querySelector("#task-summary"),
  // Ylläpidon alue piilotetaan tavalliselta käyttäjältä käytettävyyden vuoksi.
  admin: document.querySelector("#admin-section"),
  // Tämä painike pyytää palvelimelta käyttöoikeuksilla suojatun koosteen.
  statsButton: document.querySelector("#stats-button"),
  // Kooste näytetään tekstinä tässä kappaleessa.
  statsOutput: document.querySelector("#stats-output"),
};

// Funktio on nimetty toimintokokonaisuus; message-parametri saa kutsujan antaman tekstin.
function announce(message) {
  // textContent käsittelee sisällön tekstinä, joten käyttäjän syöte ei muutu HTML-koodiksi.
  ui.status.textContent = message;
  // Uusi tilaviestintä poistaa edellisen toiminnon virheen.
  ui.error.textContent = "";
}

// Näytetään käyttäjälle ymmärrettävä virhe ilman palvelimen sisäisten tietojen lisäämistä.
function showError(error) {
  // Verkkovirhe ja vääränmuotoinen vastaus erotetaan API:n tarkoituksellisesta virhetekstistä.
  let message = error instanceof Error ? error.message : "Tuntematon virhe. Yritä uudelleen.";
  // TypeError syntyy fetchissä esimerkiksi verkkoyhteyden puuttuessa.
  if (error instanceof TypeError) {
    // Teknisen virhetekstin sijaan kerrotaan mitä käyttäjä voi tarkistaa.
    message = "Palvelimeen ei saatu yhteyttä. Tarkista, että Deno-palvelin on käynnissä, ja yritä uudelleen.";
  }
  // JSON-jäsennyksen virhe kertoo, ettei palvelin palauttanut sovittua tietomuotoa.
  if (error instanceof SyntaxError) {
    // Tämän harjoituksen käyttäjä voi yrittää latausta uudelleen.
    message = "Palvelimen vastausta ei voitu lukea. Lataa sivu uudelleen.";
  }
  // Aikarajan ylitys saa oman selkokielisen viestinsä.
  if (error instanceof Error && (error.name === "AbortError" || error.name === "TimeoutError")) {
    // Pyyntö saattoi jo ehtiä palvelimelle; ensin tarkistetaan tämänhetkinen tieto.
    message = "Palvelin vastasi liian hitaasti. Lataa sivu uudelleen ja tarkista tiedot ennen uutta tallennusta.";
  }
  // Tila-alue ei jää virhetilanteessa näyttämään odottamista.
  ui.status.textContent = "Toiminto ei valmistunut normaalisti.";
  // Virhe ilmoitetaan näkyvänä tekstinä sekä HTML:n role="alert"-alueella.
  ui.error.textContent = `Virhe: ${message}`;
}

// Odotustila ehkäisee saman lomakkeen tahattomat kaksoislähetykset.
function setBusy(busy) {
  // Tallennetaan true- tai false-arvo yhteiseen tilaan.
  state.busy = busy;
  // querySelectorAll palauttaa kaikki painikkeet ja kentät; forEach käy ne yksitellen läpi.
  document.querySelectorAll("button, input").forEach((control) => {
    // disabled estää toiminnon odotuksen ajaksi; false palauttaa käytön.
    control.disabled = busy;
  });
  // ARIA-attribuutti odottaa tekstiä, joten String muuttaa totuusarvon tekstiksi.
  ui.workspace.setAttribute("aria-busy", String(busy));
  // Myös tunnistautumisalue kertoo avustavalle teknologialle odottamisesta.
  ui.auth.setAttribute("aria-busy", String(busy));
}

// Kohdistetaan olemassa oleva elementti; tätä kutsutaan vasta kun disabled on poistettu.
function focusId(id) {
  // Etsitään elementti sen yksilöivällä id-arvolla.
  const element = document.getElementById(id);
  // Ehto estää puuttuvan elementin käytön.
  if (element) {
    // focus siirtää näppäimistön kohdistuksen tähän kohteeseen.
    element.focus();
  }
}

// async-funktio voi odottaa verkkopyyntöä; oletusmenetelmä on tietoa lukeva GET.
async function api(path, method = "GET", body = undefined) {
  // Headers kokoaa pyynnön otsakkeet; Accept pyytää JSON-muotoista vastausta.
  const headers = new Headers({ Accept: "application/json" });
  // Vain tietoja muuttavat pyynnöt tarvitsevat tässä JSON-rungon.
  if (method !== "GET") {
    // Palvelin edellyttää kirjoituksilta tätä tyyppiä myös CSRF-suojauksensa osana.
    headers.set("Content-Type", "application/json");
  }
  // AbortController osaa keskeyttää tämän yhden verkkopyynnön.
  const controller = new AbortController();
  // setTimeout kutsuu keskeytystä 15 sekunnin päästä, jos vastausta ei ehdi tulla.
  const timeout = setTimeout(() => controller.abort(), 15000);
  // finally-osio vapauttaa ajastimen riippumatta siitä, onnistuuko pyyntö.
  try {
    // fetch lähettää pyynnön; await odottaa vastausta estämättä koko selaimen käyttöä.
    const response = await fetch(path, {
      // method on esimerkiksi GET, POST, PATCH tai DELETE.
      method,
      // Lähetetään samalle alkuperälle kuuluva istuntoeväste automaattisesti.
      credentials: "same-origin",
      // Käyttäjäkohtaisia API-vastauksia ei haeta selaimen HTTP-välimuistista.
      cache: "no-store",
      // Liitetään yllä koottu otsakeolio pyyntöön.
      headers,
      // GETillä ei ole runkoa; muulloin JSON.stringify muuttaa olion siirrettäväksi tekstiksi.
      body: method === "GET" ? undefined : JSON.stringify(body ?? {}),
      // Liitetään pyynnön keskeytysmahdollisuus tähän fetchiin.
      signal: controller.signal,
    });
    // 204 tarkoittaa onnistumista ilman runkoa; muut vastaukset luetaan JSONina.
    const payload = response.status === 204 ? null : await response.json();
    // fetch ei itsessään pidä HTTP 400/401/403/404/500 -vastauksia verkkovirheinä.
    if (!response.ok) {
      // Palvelimen turvallinen error-teksti otetaan mukaan, jos se on olemassa.
      const error = new Error(payload?.error ?? `Pyyntö epäonnistui (HTTP ${response.status}).`);
      // Tallennetaan status virheen ominaisuudeksi, jotta 401 voidaan käsitellä erikseen.
      error.status = response.status;
      // throw siirtää käsittelyn lähimpään catch-lohkoon.
      throw error;
    }
    // return antaa palvelimen tiedot funktiota odottavalle kutsujalle.
    return payload;
  } finally {
    // Ajastin poistetaan myös virheessä, ettei se jää turhaan odottamaan.
    clearTimeout(timeout);
  }
}

// Tämä apufunktio hoitaa kaikille käyttöliittymätoiminnoille yhteisen odotus- ja virhetilan.
async function runAction(loadingMessage, action) {
  // Jo käynnissä olevan toiminnon aikana ei aloiteta toista.
  if (state.busy) return false;
  // Tallennetaan kohdistettu elementti ennen kuin disabled voisi siirtää kohdistuksen pois siitä.
  const focusedBefore = document.activeElement;
  // Estetään painikkeet ja kentät odotuksen ajaksi.
  setBusy(true);
  // Kerrotaan näkyvästi, mitä juuri nyt odotetaan.
  announce(loadingMessage);
  // try tarkoittaa, että seuraavan toiminnon virheet käsitellään catchissa.
  try {
    // action on kutsujan antama funktio; await odottaa myös sen sisäiset verkkopyynnöt.
    await action();
    // true kertoo tapahtumankäsittelijälle onnistumisesta.
    return true;
  } catch (error) {
    // 401 kirjautuneena tarkoittaa esimerkiksi vanhentunutta tai toisessa välilehdessä poistettua istuntoa.
    if (error.status === 401 && state.user !== null) {
      // Poistetaan vanhat käyttäjätiedot näkymästä ja näytetään kirjautuminen.
      showGuest();
      // Kerrotaan uudelleenkirjautumisen tarve.
      error.message = "Kirjautuminen on vanhentunut. Kirjaudu uudelleen.";
    }
    // Virhe tulee sivulle, jotta pelkkää kehittäjäkonsolia ei tarvitse osata lukea.
    showError(error);
    // false kertoo käsittelijälle, ettei sen pidä näyttää onnistumista.
    return false;
  } finally {
    // Lomakkeet vapautetaan sekä onnistumisen että virheen jälkeen.
    setBusy(false);
    // Palautetaan kohdistus, jos alkuperäinen elementti on yhä näkyvän näkymän DOMissa.
    if (focusedBefore instanceof HTMLElement && focusedBefore.isConnected && !focusedBefore.closest("[hidden]")) {
      // Varsinainen käsittelijä voi tämän jälkeen kohdistaa uuteen onnistumisen kohteeseen.
      focusedBefore.focus();
    } else if (state.user === null) {
      // Vanhentunut istunto saattoi piilottaa vanhan kohteen; tällöin tarjotaan kirjautumiskenttä.
      focusId("login-email");
    }
  }
}

// Luetaan lomakkeelta nimikenttä ja tarkistetaan tavallinen kirjoitusvirhe jo selaimessa.
function readTitle(form, maximum) {
  // elements.namedItem löytää lomakkeen name="title"-kentän myös disabled-tilassa; value lukee sen tekstin ja trim poistaa reunavälit.
  const title = form.elements.namedItem("title").value.trim();
  // Array.from laskee Unicode-koodipisteet kuten backend; tavallinen .length laskisi UTF-16-yksiköt ja esimerkiksi 😀 kahdesti.
  const length = Array.from(title).length;
  // Tyhjäksi jäänyt tai liian pitkä nimi pysäyttää toiminnon.
  if (length === 0 || length > maximum) {
    // Palvelin tarkistaa saman asian uudelleen, koska selaimen tarkistuksen voi ohittaa.
    throw new Error(`Nimen pitää sisältää 1–${maximum} merkkiä. Pelkät välilyönnit eivät riitä.`);
  }
  // Palautetaan siistitty nimi kutsujalle.
  return title;
}

// Kirjautumaton näkymä tyhjentää myös edellisen käyttäjän selaimeen ladatut tiedot.
function showGuest() {
  // Tunnistautuneen käyttäjän tietoa ei enää säilytetä.
  state.user = null;
  // Projektit poistetaan muistista; tietokantaan ei tehdä tässä muutoksia.
  state.projects = [];
  // Myös ladatut tehtävät poistetaan muistista.
  state.tasks = [];
  // Valinta puretaan.
  state.selectedProjectId = null;
  // Tunnistautumislomakkeet näytetään.
  ui.auth.hidden = false;
  // Kirjautuneen työtila piilotetaan.
  ui.workspace.hidden = true;
  // Ylläpitonäkymä piilotetaan varmuuden vuoksi erikseen.
  ui.admin.hidden = true;
  // Näkyvästä otsikkorivistä poistetaan edellisen käyttäjän osoite.
  ui.account.textContent = "";
  // Tyhjennetään molempien lomakkeiden syötetyt arvot, myös salasanat.
  ui.login.reset();
  // Rekisteröintilomakkeen salasanakin tyhjennetään.
  ui.register.reset();
  // Tilastot eivät jää seuraavan kirjautujan selaintilaan.
  ui.statsOutput.textContent = "Lukumääriä ei ole vielä haettu.";
  // Piirretään tyhjentyneet projektit ja poistetaan tehtävien näkyvä sisältö.
  renderProjects();
  // Valinnan puute piilottaa projektin yksityiskohdat ja tyhjentää tehtävälistan.
  renderProjectDetail();
}

// Näytetään palvelimen vahvistaman käyttäjän työtila.
function showWorkspace(user) {
  // Käyttäjän id, email ja role tulivat palvelimen vastauksesta.
  state.user = user;
  // Tunnistautumislomakkeita ei tarvita kirjautuneessa näkymässä.
  ui.auth.hidden = true;
  // Oman työtilan sisältö voidaan nyt näyttää.
  ui.workspace.hidden = false;
  // Näytetään osoite tekstinä; mahdollinen HTML-merkistö ei suorita koodia.
  ui.account.textContent = `Kirjautunut: ${user.email}`;
  // Roolitieto ohjaa vain näkymää; palvelin tarkistaa ylläpito-oikeuden jokaisella pyynnöllä.
  ui.admin.hidden = user.role !== "admin";
  // Salasanaa ei jätetä kirjautumislomakkeeseen onnistumisen jälkeen.
  ui.login.reset();
  // Myös rekisteröintilomakkeen salasana tyhjennetään.
  ui.register.reset();
}

// Ladataan projektit vasta tunnistautumisen jälkeen.
async function loadProjects() {
  // GET hakee tiedot muuttamatta niitä.
  const result = await api("/api/projects");
  // Palvelimen projects-ominaisuus sisältää käyttäjän omat projektit.
  state.projects = result.projects;
  // Täytetään lista ladatuilla tiedoilla.
  renderProjects();
}

// Piirtäminen tarkoittaa tässä HTML-elementtien päivittämistä state-olion tiedoista.
function renderProjects() {
  // replaceChildren ilman argumentteja poistaa vanhat listarivit turvallisesti.
  ui.projectList.replaceChildren();
  // Tyhjän listan ohje näkyy vain, kun projektitaulukon pituus on nolla.
  ui.projectEmpty.hidden = state.projects.length !== 0;
  // for...of toistaa lohkon jokaiselle taulukon projektille.
  for (const project of state.projects) {
    // Luodaan listan yksi li-elementti muistiin.
    const item = document.createElement("li");
    // Luodaan oikea painike, jolla on selaimen valmiit näppäimistöominaisuudet.
    const button = document.createElement("button");
    // Painike ei lähetä lomaketta.
    button.type = "button";
    // Yksilöllinen id mahdollistaa kohdistuksen palauttamisen uudelleenpiirron jälkeen.
    button.id = `project-button-${project.id}`;
    // secondary käyttää CSS:n vaaleaa painiketyyliä.
    button.className = "secondary";
    // Verrataan numerotunnisteita; === ei muuta arvojen tietotyyppejä.
    const selected = project.id === state.selectedProjectId;
    // Valinta kerrotaan avustavalle teknologialle tekstiarvona.
    button.setAttribute("aria-current", String(selected));
    // Myös näkyvä teksti kertoo valitun projektin; käyttäjän nimi tulostetaan turvallisesti.
    button.textContent = selected ? `${project.title} (valittu)` : `Avaa projekti: ${project.title}`;
    // Uusikin painike noudattaa parhaillaan voimassa olevaa odotustilaa.
    button.disabled = state.busy;
    // Nuolifunktio käynnistää projektin avaamisen vasta click-tapahtuman tullessa.
    button.addEventListener("click", () => selectProject(project.id));
    // Lisätään painike li-elementin lapseksi.
    item.append(button);
    // Lisätään valmis li sivulla olevaan ul-listaan.
    ui.projectList.append(item);
  }
}

// Avaa projekti hakemalla sen tehtävät palvelimelta.
async function selectProject(projectId) {
  // runAction kertoo odottamisesta ja ottaa kiinni mahdollisen virheen.
  const success = await runAction("Ladataan projektin tehtäviä…", async () => {
    // Numerotunniste liitetään API:n polkuun; palvelin tarkistaa omistajuuden.
    const result = await api(`/api/projects/${projectId}/tasks`);
    // Valinta muutetaan vasta onnistuneen haun jälkeen.
    state.selectedProjectId = projectId;
    // Aiemman projektin tehtävät korvataan uudella listalla.
    state.tasks = result.tasks;
    // Päivitetään projektipainikkeiden valintamerkinnät.
    renderProjects();
    // Täytetään projektin nimi ja tehtävät.
    renderProjectDetail();
    // Onnistuminen kerrotaan myös ruudunlukijan tilaviestinä.
    announce("Projekti avattu. Voit lisätä, muokata ja poistaa sen tehtäviä.");
  });
  // Onnistumisen jälkeen kohdistus siirtyy uuteen sisältöön, virheessä takaisin avauspainikkeeseen.
  focusId(success ? "project-title" : `project-button-${projectId}`);
}

// Päivitetään valitun projektin kortti.
function renderProjectDetail() {
  // find palauttaa ensimmäisen ehdon täyttävän projektin tai undefined-arvon.
  const project = state.projects.find((item) => item.id === state.selectedProjectId);
  // Jos projektia ei ole valittu, korttia ei näytetä.
  if (!project) {
    // hidden poistaa kortin myös näppäimistön kohdistusjärjestyksestä.
    ui.detail.hidden = true;
    // Vanhoja tehtäviä ei jätetä piilotettuun DOMiin.
    ui.taskList.replaceChildren();
    // Vanhasta projektista ei säilytetä nimeä kentässä.
    document.querySelector("#project-name").value = "";
    // Myös piilotettu otsikko palautetaan lähtötilaan.
    ui.projectTitle.textContent = "Valitse projekti";
    // return päättää tämän funktion suorittamisen tähän.
    return;
  }
  // Valitun projektin kortti tuodaan näkyviin.
  ui.detail.hidden = false;
  // Nimi asetetaan otsikkoon tekstinä.
  ui.projectTitle.textContent = project.title;
  // value asettaa syötekentän nykyisen arvon; se ei tulkitse HTML-koodia.
  document.querySelector("#project-name").value = project.title;
  // Piirretään juuri tälle projektille ladatut tehtävät.
  renderTasks();
}

// Piirretään tehtävälista; openTaskId kertoo mahdollisen muokkausosan, jonka haluamme pitää auki.
function renderTasks(openTaskId = null) {
  // Poistetaan vanhat rivit ennen uuden listan rakentamista.
  ui.taskList.replaceChildren();
  // filter tekee uuden taulukon vain valmiista tehtävistä; length kertoo niiden määrän.
  const completed = state.tasks.filter((task) => task.done).length;
  // Tyhjä tila saa oman toimintaan ohjaavan tekstinsä.
  ui.taskSummary.textContent = state.tasks.length === 0
    // Kolmioperaattorin ?-haara käytetään, kun tehtäviä ei ole.
    ? "Projektilla ei vielä ole tehtäviä. Lisää ensimmäinen tehtävä yllä."
    // :-haara kertoo olemassa olevien ja valmiiden tehtävien määrät.
    : `Tehtäviä yhteensä ${state.tasks.length}. Valmiita ${completed}.`;
  // Jokainen tehtävä muutetaan omaksi saavutettavaksi listarivikseen.
  for (const task of state.tasks) {
    // Luodaan yksi tehtävän li-elementti.
    const item = document.createElement("li");
    // className yhdistää tehtävärivin CSS:n tyyliin.
    item.className = "task-item";
    // div ryhmittelee valintaruudun ja sen näkyvän nimen.
    const toggleRow = document.createElement("div");
    // Tämä luokka asettelee valintaruudun nimen viereen.
    toggleRow.className = "task-toggle";
    // Luodaan selaimen oma input-elementti.
    const checkbox = document.createElement("input");
    // checkbox-tyyppi toimii hiirellä sekä välilyöntinäppäimellä.
    checkbox.type = "checkbox";
    // Jokaiselle tehtävälle muodostetaan yksilöllinen valintaruudun tunniste.
    checkbox.id = `task-done-${task.id}`;
    // checked kuvaa totuusarvona, onko valintaruutu valittu.
    checkbox.checked = task.done;
    // Vastaluotu valintaruutu noudattaa odotustilaa.
    checkbox.disabled = state.busy;
    // label on ruudun näkyvä ja ohjelmallisesti yhdistetty nimi.
    const label = document.createElement("label");
    // htmlFor vastaa HTML:n for-attribuuttia ja yhdistyy checkboxin id:hen.
    label.htmlFor = checkbox.id;
    // Tilan nimi kerrotaan sanoin; sisältö käsitellään tavallisena tekstinä.
    label.textContent = `${task.title} (${task.done ? "valmis" : "kesken"})`;
    // Muutoskuuntelija suoritetaan, kun käyttäjä vaihtaa valintaruudun tilaa.
    checkbox.addEventListener("change", async () => {
      // Otetaan käyttäjän pyytämä uusi tila talteen ennen verkkopyyntöä.
      const requestedDone = checkbox.checked;
      // PATCH muuttaa vain sovittua done-ominaisuutta.
      const success = await runAction("Tallennetaan tehtävän tilaa…", async () => {
        // Lähetetään palvelimelle uusi totuusarvo JSON-oliona.
        const result = await api(`/api/tasks/${task.id}`, "PATCH", { done: requestedDone });
        // map käy tehtävät läpi ja korvaa vain muuttuneen tehtävän palvelimen vastauksella.
        state.tasks = state.tasks.map((oldTask) => oldTask.id === task.id ? result.task : oldTask);
        // Piirretään vahvistettu tila palvelimen tiedoista.
        renderTasks();
        // Ilmoitetaan uusi tila nimeltä.
        announce(result.task.done ? "Tehtävä merkitty valmiiksi." : "Tehtävä merkitty keskeneräiseksi.");
      });
      // Virheessä palautetaan alkuperäinen ruutu palvelimen viimeksi vahvistamaan tilaan.
      if (!success) checkbox.checked = task.done;
      // Uudelleenpiirto loi uuden elementin, joten kohdistus etsitään vakaalla id:llä.
      focusId(`task-done-${task.id}`);
    });
    // Valintaruutu ja nimi lisätään samaan ryhmään.
    toggleRow.append(checkbox, label);
    // details tekee muokkauksesta selaimen omilla toiminnoilla avattavan osion.
    const details = document.createElement("details");
    // Aiemmin muokattu tehtävä pidetään tarvittaessa avoinna.
    details.open = task.id === openTaskId;
    // summary on avattavan osion näppäimistöllä toimiva otsikko.
    const summary = document.createElement("summary");
    // Tehtävän nimi erottaa tämän toiminnon muiden tehtävien toiminnoista.
    summary.textContent = `Muokkaa tai poista: ${task.title}`;
    // form mahdollistaa muokatun nimen lähettämisen myös Enterillä.
    const form = document.createElement("form");
    // Lomakkeelle annetaan sitä kuvaava saavutettava nimi.
    form.setAttribute("aria-label", `Muokkaa tehtävää ${task.title}`);
    // Kentän nimi on oma label-elementtinsä.
    const nameLabel = document.createElement("label");
    // Label yhdistetään kohta luotavaan nimikenttään.
    nameLabel.htmlFor = `task-name-${task.id}`;
    // Pakollisuus ilmaistaan sanallisesti.
    nameLabel.textContent = "Tehtävän uusi nimi (pakollinen)";
    // input kerää tehtävän uuden nimen.
    const input = document.createElement("input");
    // text on tavallinen yhden rivin tekstikenttä.
    input.type = "text";
    // Yksilöllinen id yhdistää kentän labeliin ja kohdistukseen.
    input.id = `task-name-${task.id}`;
    // name on avain, jolla FormData hakee kentän arvon.
    input.name = "title";
    // Selain tarkistaa, että kenttä on täytetty.
    input.required = true;
    // Pituus tarkistetaan readTitle-funktiossa koodipisteinä; HTML:n maxLength käyttäisi erilaista UTF-16-laskentaa.
    // Nykyinen nimi näytetään muokattavana arvona.
    input.value = task.title;
    // Myös tämä kenttä noudattaa yhteistä odotustilaa.
    input.disabled = state.busy;
    // Luodaan tallennuspainike.
    const save = document.createElement("button");
    // submit käynnistää tätä lomaketta kuuntelevan käsittelijän.
    save.type = "submit";
    // Toissijainen tyyli erottaa muokkauksen uuden tehtävän luomisesta.
    save.className = "secondary";
    // Näkyvä teksti kertoo suoraan toiminnon.
    save.textContent = "Tallenna tehtävän nimi";
    // Uusi painike pysyy odotuksessa estettynä.
    save.disabled = state.busy;
    // Lomakkeen submit-tapahtuma kokoaa tallentamisen yhteen paikkaan.
    form.addEventListener("submit", async (event) => {
      // Estetään selaimen oletustoiminto, joka lataisi sivun uudelleen.
      event.preventDefault();
      // Hoidetaan odotus ja virhe yhteisellä apufunktiolla.
      const success = await runAction("Tallennetaan tehtävän nimeä…", async () => {
        // readTitle tarkistaa nimen; palvelimelle lähetetään vain title-ominaisuus.
        const result = await api(`/api/tasks/${task.id}`, "PATCH", { title: readTitle(form, 200) });
        // Korvataan muokattu tehtävä palvelimen vahvistamalla tiedolla.
        state.tasks = state.tasks.map((oldTask) => oldTask.id === task.id ? result.task : oldTask);
        // Pidetään tämän tehtävän muokkausosa auki uudelleenpiirrossa.
        renderTasks(task.id);
        // Ilmoitetaan tallennuksen onnistumisesta.
        announce("Tehtävän nimi tallennettu.");
      });
      // Onnistumisen jälkeen kohdistetaan uusi samanniminen kenttä.
      if (success) focusId(`task-name-${task.id}`);
    });
    // Lomakkeen elementit lisätään siinä järjestyksessä kuin niitä luetaan ja käytetään.
    form.append(nameLabel, input, save);
    // Luodaan tehtävän poistopainike.
    const remove = document.createElement("button");
    // button estää tahattoman lomakelähetyksen.
    remove.type = "button";
    // danger valitsee poistamisen punaisen ulkoasun.
    remove.className = "danger";
    // Nimi erottaa poistotoiminnot myös ruudunlukijan painikelistassa.
    remove.textContent = `Poista tehtävä: ${task.title}`;
    // Poistoa ei voi aloittaa kesken toisen pyynnön.
    remove.disabled = state.busy;
    // Poistaminen käynnistyy painikkeen click-tapahtumasta.
    remove.addEventListener("click", async () => {
      // globalThis viittaa selaimen yleiseen ympäristöön; confirm avaa sen oman poistovahvistuksen.
      if (!globalThis.confirm(`Poistetaanko tehtävä ”${task.title}”? Tätä ei voi perua.`)) return;
      // Varsinainen DELETE tehdään vasta myönteisen vahvistuksen jälkeen.
      const success = await runAction("Poistetaan tehtävää…", async () => {
        // api lisää DELETEen Content-Type-otsakkeen ja tyhjän JSON-rungon.
        await api(`/api/tasks/${task.id}`, "DELETE");
        // filter säilyttää kaikki muut kuin juuri poistetun tehtävän.
        state.tasks = state.tasks.filter((oldTask) => oldTask.id !== task.id);
        // Päivitetään lista sekä tyhjä tila tai lukumäärä.
        renderTasks();
        // Poiston onnistuminen kerrotaan tekstinä.
        announce("Tehtävä poistettu.");
      });
      // Poistettu painike ei enää ole sivulla; siirretään kohdistus uuden tehtävän kenttään.
      if (success) focusId("new-task-title");
    });
    // Div ryhmittelee poistopainikkeen omaan toimintoriviinsä.
    const actions = document.createElement("div");
    // task-actions antaa riville joustavan asettelun.
    actions.className = "task-actions";
    // Liitetään poistopainike toimintoriviin.
    actions.append(remove);
    // Avattavaan osioon lisätään ensin otsikko, sitten lomake ja poistotoiminto.
    details.append(summary, form, actions);
    // Tehtävärivi koostuu valintaruudusta ja muokkausosasta.
    item.append(toggleRow, details);
    // Lisätään valmis tehtävä sivun listaan.
    ui.taskList.append(item);
  }
}

// Yhteinen kirjautumis- ja rekisteröintitoiminto vähentää saman koodin toistamista.
async function authenticate(event, path) {
  // Estetään HTML-lomakkeen tavallinen sivunvaihto.
  event.preventDefault();
  // currentTarget on se lomake, johon kuuntelija on liitetty; se talletetaan ennen awaitia.
  const form = event.currentTarget;
  // FormData kerää kenttien arvot niiden name-attribuuttien perusteella.
  const data = new FormData(form);
  // Odotuksen aikana koko näkymä estää kaksoislähetykset.
  const success = await runAction("Tarkistetaan tunnusta…", async () => {
    // Luetaan salasana aiemmin kerätystä FormDatasta; välilyöntejä ei poisteta.
    const password = String(data.get("password") ?? "");
    // Käytetään täsmälleen backendin Unicode-koodipisteisiin perustuvaa pituuslaskentaa.
    const passwordLength = Array.from(password).length;
    // Alle 15 tai yli 128 koodipisteen salasana saa näkyvän virheen ennen verkkopyyntöä.
    if (passwordLength < 15 || passwordLength > 128) {
      // runAction näyttää tämän viestin sivun virhealueella ja vapauttaa lomakkeen uudelleen.
      throw new Error("Salasanassa pitää olla 15–128 merkkiä.");
    }
    // Palvelimelle lähetetään vain sähköposti ja salasana, ei käyttäjän pyytämää roolia.
    const result = await api(path, "POST", {
      // Sähköpostin reunoilta voi poistaa vahingossa syötetyt välilyönnit.
      email: String(data.get("email") ?? "").trim(),
      // Lähetetään alkuperäinen salasana muuttamatta sen sisältöä.
      password,
    });
    // Selain säilyttää HttpOnly-istuntoevästeen; JavaScript ei lue sitä eikä tallenna salasanaa.
    showWorkspace(result.user);
    // Nyt tunnistautuneen käyttäjän omat projektit voidaan hakea.
    await loadProjects();
    // Kerrotaan onnistuneesta kirjautumisesta.
    announce("Kirjautuminen onnistui. Luo projekti tai avaa oma projektisi.");
  });
  // Seuraava luonteva kohde on projektin luontikenttä.
  if (success) focusId("new-project-title");
}

// Kirjautumislomakkeen submit käyttää login-osoitetta.
ui.login.addEventListener("submit", (event) => authenticate(event, "/api/auth/login"));
// Rekisteröintilomakkeen submit käyttää register-osoitetta.
ui.register.addEventListener("submit", (event) => authenticate(event, "/api/auth/register"));

// Uloskirjautuminen on palvelimella tehtävä istunnon poisto.
ui.logout.addEventListener("click", async () => {
  // Näytetään odotus ja odotetaan vastausta.
  const success = await runAction("Kirjaudutaan ulos…", async () => {
    // Pelkkä käyttöliittymän piilottaminen ei riittäisi; palvelimen istunto poistetaan.
    await api("/api/auth/logout", "POST", {});
    // Palvelimen vahvistuksen jälkeen poistetaan paikalliset käyttäjätiedot.
    showGuest();
    // Kerrotaan kirjautumattomasta tilasta.
    announce("Olet kirjautunut ulos.");
  });
  // Kirjautumislomakkeen ensimmäinen kenttä on nyt mielekäs kohdistuskohde.
  if (success) focusId("login-email");
});

// Projektin luonti käsitellään lomakkeella, joten Enter toimii kuten painikkeen painaminen.
ui.projectCreate.addEventListener("submit", async (event) => {
  // Estetään sivun uudelleenlataus.
  event.preventDefault();
  // Aloitetaan palvelimelle tallentava toiminto.
  const success = await runAction("Luodaan projektia…", async () => {
    // readTitle lukee kentän myös disabled-tilassa ja tarkistaa 1–120 koodipistettä; palvelin tarkistaa saman sekä omistajan.
    const result = await api("/api/projects", "POST", { title: readTitle(ui.projectCreate, 120) });
    // push lisää palvelimen palauttaman projektin taulukon loppuun.
    state.projects.push(result.project);
    // Juuri luotu projekti valitaan suoraan.
    state.selectedProjectId = result.project.id;
    // Uudella projektilla ei ole vielä tehtäviä.
    state.tasks = [];
    // Tyhjennetään luontikenttä seuraavaa projektia varten.
    ui.projectCreate.reset();
    // Päivitetään projektien lista.
    renderProjects();
    // Näytetään uuden projektin tyhjä tehtäväalue.
    renderProjectDetail();
    // Kerrotaan onnistumisesta ja seuraavasta mahdollisesta toiminnosta.
    announce("Projekti luotu. Lisää sille ensimmäinen tehtävä.");
  });
  // Kohdistus siirtyy uuden projektin tehtäväkenttään.
  if (success) focusId("new-task-title");
});

// Olemassa olevan projektin nimenmuutos.
ui.projectRename.addEventListener("submit", async (event) => {
  // Estetään lomakkeen oletuslähetys.
  event.preventDefault();
  // Lähetetään muutos palvelimelle.
  const success = await runAction("Tallennetaan projektin nimeä…", async () => {
    // PATCH muokkaa olemassa olevaa projektia; readTitle tarkistaa nimen samalla 120 koodipisteen rajalla kuin backend.
    const result = await api(`/api/projects/${state.selectedProjectId}`, "PATCH", { title: readTitle(ui.projectRename, 120) });
    // Korvataan vain muokattu projekti; muut säilyvät ennallaan.
    state.projects = state.projects.map((oldProject) => oldProject.id === result.project.id ? result.project : oldProject);
    // Listassa näytetään palvelimen vahvistama uusi nimi.
    renderProjects();
    // Myös otsikko ja muokkauskenttä päivitetään.
    renderProjectDetail();
    // Ilmoitetaan onnistumisesta.
    announce("Projektin nimi tallennettu.");
  });
  // Kohdistetaan nimen kenttä uudelleen.
  if (success) focusId("project-name");
});

// Projektin poistaminen poistaa backendissä myös projektiin kuuluvat tehtävät.
ui.projectDelete.addEventListener("click", async () => {
  // Etsitään valittu projekti vahvistusviestin nimeä varten.
  const project = state.projects.find((item) => item.id === state.selectedProjectId);
  // Ilman valittua projektia toiminnolla ei ole kohdetta.
  if (!project) return;
  // globalThis.confirm avaa selaimen vahvistuksen ennen pyyntöä; Peruuta lopettaa funktion heti.
  if (!globalThis.confirm(`Poistetaanko projekti ”${project.title}” ja kaikki sen tehtävät? Tätä ei voi perua.`)) return;
  // Käynnistetään verkkotoiminto.
  const success = await runAction("Poistetaan projektia ja sen tehtäviä…", async () => {
    // DELETE poistaa juuri tämän omistetun projektin.
    await api(`/api/projects/${project.id}`, "DELETE");
    // Poistetaan vahvistetusti poistunut projekti paikallisesta listasta.
    state.projects = state.projects.filter((item) => item.id !== project.id);
    // Poistettu projekti ei voi enää olla valittu.
    state.selectedProjectId = null;
    // Sen tehtävät poistetaan käyttöliittymän muistista.
    state.tasks = [];
    // Päivitetään jäljellä olevat projektit ja tarvittaessa tyhjä tila.
    renderProjects();
    // Piilotetaan poistuneen projektin kortti.
    renderProjectDetail();
    // Kerrotaan poistamisen laajuus myös onnistumisviestissä.
    announce("Projekti ja sen tehtävät poistettu.");
  });
  // Poistunut painike korvataan kohdistuksessa projektin luontikentällä.
  if (success) focusId("new-project-title");
});

// Uusi tehtävä lisätään juuri valittuun projektiin.
ui.taskCreate.addEventListener("submit", async (event) => {
  // Estetään sivun tavallinen uudelleenlataus.
  event.preventDefault();
  // Odotetaan palvelimen vahvistusta ennen listan muuttamista.
  const success = await runAction("Tallennetaan uutta tehtävää…", async () => {
    // readTitle tarkistaa 1–200 koodipistettä; palvelin tarkistaa saman sekä tämän projektin omistajuuden.
    const result = await api(`/api/projects/${state.selectedProjectId}/tasks`, "POST", { title: readTitle(ui.taskCreate, 200) });
    // Lisätään palvelimen luoma id ja muut tiedot tehtävätaulukkoon.
    state.tasks.push(result.task);
    // Tyhjennetään tehtäväkenttä seuraavaa tehtävää varten.
    ui.taskCreate.reset();
    // Piirretään lista, joka sisältää myös uuden tehtävän.
    renderTasks();
    // Ilmoitetaan onnistumisesta näkyvästi.
    announce("Tehtävä lisätty.");
  });
  // Tehtäviä voi lisätä peräkkäin näppäimistöllä ilman ylimääräistä siirtymistä.
  if (success) focusId("new-task-title");
});

// Ylläpidon koosteen lukeminen on suojattu myös palvelimella.
ui.statsButton.addEventListener("click", async () => {
  // Toiminto käsitellään samoilla lataus- ja virhetiloilla kuin muut pyynnöt.
  await runAction("Haetaan ylläpidon lukumääriä…", async () => {
    // GET ei muuta mitään; tavallinen käyttäjä saisi tästä palvelimelta 403-vastauksen.
    const stats = await api("/api/admin/stats");
    // Tiedot näytetään ymmärrettävänä tekstinä, ei pelkkinä irrallisina numeroina.
    ui.statsOutput.textContent = `Käyttäjiä ${stats.users}, projekteja ${stats.projects}, tehtäviä ${stats.tasks}.`;
    // Onnistumisviesti kertoo haun valmistuneen.
    announce("Ylläpidon lukumäärät haettu.");
  });
  // Palautetaan näppäimistön kohdistus toiminnon painikkeeseen.
  focusId("stats-button");
});

// Sivun käynnistys tarkistaa, onko selaimella jo voimassa oleva istuntoeväste.
async function initialize() {
  // Alun lataustila käyttää samaa apufunktiota kuin käyttäjän käynnistämät toiminnot.
  await runAction("Tarkistetaan kirjautumista…", async () => {
    // 401 on aloituksessa tavallinen kirjautumattoman käyttäjän tila.
    try {
      // JavaScript ei lue evästettä; selain liittää sen pyyntöön automaattisesti.
      const result = await api("/api/auth/me");
      // Palvelimen vahvistama käyttäjä näytetään työtilassa.
      showWorkspace(result.user);
      // Ladataan tämän käyttäjän projektit.
      await loadProjects();
      // Kerrotaan onnistuneesta valmistumisesta.
      announce("Oma työtila ladattu. Valitse projekti tai luo uusi.");
    } catch (error) {
      // Myös verkkovirheessä näytetään kirjautumisnäkymä, jotta käyttäjä voi yrittää uudelleen.
      showGuest();
      // 401 käsitellään tavallisena aloitustilana eikä punaisena virheenä.
      if (error.status === 401) {
        // Kerrotaan seuraavat vaihtoehdot selvästi.
        announce("Kirjaudu sisään tai luo uusi tunnus.");
      } else {
        // Muut virheet siirretään runActionin yhteiseen virhekäsittelyyn.
        throw error;
      }
    }
  });
}

// Käynnistetään alustus vasta kun defer-skriptin HTML-elementit ovat käytettävissä.
initialize();
````

## 12.8 Turvatoimintojen kokeet, testit ja ylläpitäjä

### `esimerkit/04-valmis/security_demo.ts`

````typescript
// Tuomme vain omat nimetyt turvatoimintomme; import ei käynnistä HTTP-palvelinta.
import { hashPassword, hashSessionToken, newSessionToken, verifyPassword } from "./security.ts";

// Tämä on julkinen kokeiluteksti, ei oikean tilin salasana. Älä käytä sitä oikeassa palvelussa.
const kokeilusana = "Harjoitellaan vain omalla koneella!";
// Ensimmäinen laskenta tuottaa satunnaisen suolan ja hitaan PBKDF2-tiivisteen.
const ensimmainen = await hashPassword(kokeilusana);
// Toinen laskenta saa saman salasanan mutta arpoo uuden suolan.
const toinen = await hashPassword(kokeilusana);
// !== tarkoittaa erisuuruusvertailua. Tulostamme vain kokeen tuloksen, emme salasanaa.
console.log("Sama salasana, eri suola:", ensimmainen.salt !== toinen.salt);
// Eri suola muuttaa myös tallennettavan tiivisteen, vaikka salasana on sama.
console.log("Sama salasana, eri tiiviste:", ensimmainen.hash !== toinen.hash);
// Tarkistus käyttää ensimmäisen tuloksen suolaa ja kierrosmäärää.
console.log("Oikea salasana hyväksytään:", await verifyPassword(kokeilusana, ensimmainen));
// Väärällä salasanalla vertailu palauttaa false-arvon.
console.log(
  "Väärä salasana hyväksytään:",
  await verifyPassword("Tämä on eri pitkä kokeilusana!", ensimmainen),
);
// Istuntotunniste arvotaan eri menetelmällä kuin ihmisen valitsema salasana.
const tunniste = newSessionToken();
// Tietokantaan tallennettava istuntotiiviste lasketaan tunnisteesta.
const tiiviste = await hashSessionToken(tunniste);
// Näytämme vain vertailun. Itse istuntotunniste on salaisuus, jota ei tarvita lokiin.
console.log("Istunnon tallenne eroaa raakatunnisteesta:", tiiviste !== tunniste);
````

### `esimerkit/04-valmis/oikeuskoe_test.ts`

````typescript
// assert.equal vertaa kahta arvoa ja epäonnistuu, jos ne eivät ole samat.
import assert from "node:assert/strict";
// Käytämme samaa HTTP-käsittelijää kuin Deno.serve käyttää valmiissa sovelluksessa.
import { createApp } from "./app.ts";
// openDatabase luo testille oman kannan, kun polkuna annetaan :memory:.
import { openDatabase } from "./db.ts";

// Deno.test nimeää kokeen; async sallii hitaiden toimintojen await-odotuksen.
Deno.test("Pieni oikeuskoe: B ei lisää tehtävää A:n projektiin", async () => {
  // Muistikanta ei kirjoita opiskelijan data/tehtavataulu.sqlite-tiedostoon.
  const db = openDatabase(":memory:");
  // Origin on sama täsmällinen alkuperä kuin selaimen käyttöpolussa.
  const origin = "http://localhost:8000";
  // Luomme pyyntökäsittelijän avaamatta oikeaa verkkoporttia.
  const app = createApp(db, { origin });
  // Paikallinen apufunktio kokoaa jokaisen kirjoituspyynnön samalla sovitulla tavalla.
  function pyynto(polku: string, data: unknown, cookie = ""): Request {
    // Request on oikea HTTP-pyynnön olio, jonka palvelin osaa käsitellä.
    return new Request(origin + polku, {
      // Tässä pienessä kokeessa kaikki kirjoitukset ovat POST-pyyntöjä.
      method: "POST",
      // Selain asettaisi Originin itse; testiohjelma antaa sen tarkoituksella käsin.
      headers: { "Origin": origin, "Content-Type": "application/json", "Cookie": cookie },
      // JSON.stringify muuttaa annetun olion JSON-tekstiksi.
      body: JSON.stringify(data),
    });
  }
  // try/finally vapauttaa tietokannan myös silloin, kun jokin vertailu epäonnistuu.
  try {
    // Tämä julkinen testiteksti ei ole oikean käyttäjän salasana.
    const password = "Vain taman paikallisen testin salasana!";
    // Vaihe 1: valmistele A tavallisen rekisteröintirajapinnan kautta.
    const a = await app(pyynto("/api/auth/register", { email: "a@example.test", password }));
    // Varmistamme, että valmistelu todella onnistui, ennen kuin tulkitsemme evästettä.
    assert.equal(a.status, 201);
    // Set-Cookie sisältää nimen, arvon ja määreet. Seuraavaan pyyntöön riittää nimi=arvo.
    const aCookie = a.headers.get("set-cookie")?.split(";")[0];
    // Tämä tarkistus varmistaa evästeen olemassaolon ja kaventaa myös TypeScript-tyypin.
    assert.ok(aCookie);
    // Valmistele B erillisenä käyttäjänä, jolla on oma istunto.
    const b = await app(pyynto("/api/auth/register", { email: "b@example.test", password }));
    // Rekisteröinnin pitää onnistua myös toiselle käyttäjälle.
    assert.equal(b.status, 201);
    // Luemme B:n oman istunnon evästeen mutta emme tulosta salaista arvoa.
    const bCookie = b.headers.get("set-cookie")?.split(";")[0];
    // Ilman erillistä B:n evästettä emme testaisi eri käyttäjän oikeutta.
    assert.ok(bCookie);
    // A luo projektin omalla istunnollaan. Omistajaa ei anneta JSONissa.
    const luotu = await app(pyynto("/api/projects", { title: "A:n projekti" }, aCookie));
    // Uuden projektin onnistumiskoodi on 201.
    assert.equal(luotu.status, 201);
    // Luemme oman sovelluksemme vastaussopimuksen mukaisen tunnisteen.
    const data = await luotu.json() as { project: { id: number } };
    // Tekstipohja ${...} sijoittaa oikean tunnisteen polkuun, joten numeroa ei arvata.
    const polku = `/api/projects/${data.project.id}/tasks`;
    // Vaihe 2: yritä lisätä B:n evästeellä tehtävä A:n projektiin.
    const estetty = await app(pyynto(polku, { title: "B:n luvaton lisäys" }, bCookie));
    // Vaihe 3: varmista estävä vastaus. Tämä malli käyttää vieraille kohteille 404:ää.
    assert.equal(estetty.status, 404);
    // Varmista myös seuraukset lukemalla A:n tehtävät uudella A:n omalla pyynnöllä.
    const tarkistus = await app(new Request(origin + polku, { headers: { Cookie: aCookie } }));
    // Omistajan luku toimii edelleen.
    assert.equal(tarkistus.status, 200);
    // Tuloksen on oltava yhä tyhjä: luvaton kirjoitus ei saanut muuttaa tietokantaa.
    const lista = await tarkistus.json() as { tasks: unknown[] };
    // Nolla todistaa, ettei B:n lisäämää tehtävää syntynyt taustalla virhevastauksesta huolimatta.
    assert.equal(lista.tasks.length, 0);
  } finally {
    // Sulkeminen hävittää vain tämän erillisen muistikannan.
    db.close();
  }
});
````

### `esimerkit/04-valmis/csrfkoe_test.ts`

````typescript
// assert vertaa testin todellista tulosta etukäteen päätettyyn tulokseen.
import assert from "node:assert/strict";
// Sama pyyntökäsittelijä toimii testissä ja oikeassa verkkopalvelimessa.
import { createApp } from "./app.ts";
// Muistikanta erottaa kokeen opiskelijan omasta sovellusdatasta.
import { openDatabase } from "./db.ts";

// Tällä kertaa testataan kirjautuneen käyttäjän oman kohteen CSRF-suojausta.
Deno.test("CSRF-koe: väärä ja puuttuva Origin eivät muuta omaa tehtävää", async () => {
  // Jokainen testi saa omat taulunsa vain tämän yhteyden ajaksi.
  const db = openDatabase(":memory:");
  // Backend hyväksyy muutospyynnöille vain tämän täsmällisen alkuperän.
  const origin = "http://localhost:8000";
  // Tuotamme oikean sovelluskäsittelijän omalla tietokannalla.
  const app = createApp(db, { origin });
  // Apufunktio muodostaa aluksi sallitut POST-pyynnöt testidatan luomista varten.
  function post(path: string, data: unknown, cookie = ""): Request {
    // Request-olioon laitetaan sama muoto, jota toimiva frontend käyttää.
    return new Request(origin + path, {
      // POST on tässä luomiseen käytetty HTTP-metodi.
      method: "POST",
      // Cookie tunnistaa käyttäjän; Origin ja sisältötyyppi liittyvät eri tarkistuksiin.
      headers: { "Origin": origin, "Content-Type": "application/json", "Cookie": cookie },
      // Olio muutetaan verkon JSON-tekstiesitykseksi.
      body: JSON.stringify(data),
    });
  }
  // finally vapauttaa kannan myös odottamattomassa testivirheessä.
  try {
    // Luomme oman testikäyttäjän oikean rekisteröintitoiminnon kautta.
    const registered = await app(post("/api/auth/register", {
      // Tämä keksitty osoite kuuluu vain eristettyyn paikalliseen testiin.
      email: "csrf@example.test",
      // Julkinen testisalalause ei ole oikean tilin salasana.
      password: "Vain eristetyn CSRF-kokeen salalause!",
    }));
    // Valmistelun pitää onnistua ennen varsinaista turvallisuuskoetta.
    assert.equal(registered.status, 201);
    // Säilytämme kelvollisen istuntoevästeen testin sisällä tulostamatta sitä.
    const cookie = registered.headers.get("set-cookie")?.split(";")[0];
    // Tämä varmistaa, ettei testissä vahingossa käytetä kirjautumatonta pyyntöä.
    assert.ok(cookie);
    // Testikäyttäjä luo itselleen projektin oikealla alkuperällä.
    const projectResponse = await app(post("/api/projects", { title: "Oma projekti" }, cookie));
    // Vaadimme onnistuneen luomisen.
    assert.equal(projectResponse.status, 201);
    // Poimimme oikean projektitunnisteen sovelluksen vastauksesta.
    const project = await projectResponse.json() as { project: { id: number } };
    // Lisäämme projektiin tehtävän, jonka pitäisi säilyä estetyissä kokeissa ennallaan.
    const taskResponse = await app(
      post(`/api/projects/${project.project.id}/tasks`, { title: "Säilyvä nimi" }, cookie),
    );
    // Tehtävänkin luonnin on onnistuttava.
    assert.equal(taskResponse.status, 201);
    // Luemme tehtävän tunnisteen vastaussopimuksen mukaisesta oliosta.
    const task = await taskResponse.json() as { task: { id: number } };
    // Tätä täsmälleen samaa omaa tehtävää sekä muutetaan että tarkistetaan.
    const taskUrl = origin + `/api/tasks/${task.task.id}`;
    // Kokeile sekä väärää alkuperää että puuttuvaa otsaketta.
    for (const invalidOrigin of ["https://vieras.example", null]) {
      // Tunnistautuminen ja JSON-muoto ovat kunnossa; muutamme vain alkuperää.
      const headers = new Headers({ "Content-Type": "application/json", "Cookie": cookie });
      // null-tapauksessa Origin jätetään tarkoituksella kokonaan pois.
      if (invalidOrigin !== null) headers.set("Origin", invalidOrigin);
      // PATCH yrittää muuttaa nykyisen tehtävän nimeä ja tilaa samalla pyynnöllä.
      const blocked = await app(
        new Request(taskUrl, {
          // Metodi ja runko ovat muuten kelvollisia, joten epäonnistumisen syy voidaan rajata Originiin.
          method: "PATCH",
          // Käytämme juuri rakennettuja otsakkeita, joissa oikea istunto on yhä mukana.
          headers,
          // Nämä muutokset eivät saa päätyä tietokantaan.
          body: JSON.stringify({ title: "Luvaton muutos", done: true }),
        }),
      );
      // Virhe kertoo, että muutospyyntö pysäytettiin.
      assert.equal(blocked.status, 403);
      // Luemme tiedon uudelleen oikealla istunnolla; GET ei muuta sovelluksen tehtävätietoa.
      const readBack = await app(new Request(taskUrl, { headers: { Cookie: cookie } }));
      // Oma kelvollinen istunto toimii yhä, joten koe ei onnistunut vahingossa logoutin vuoksi.
      assert.equal(readBack.status, 200);
      // Tulkitsemme tehtävän nimen ja valmiustilan sovelluksen JSON-vastauksesta.
      const unchanged = await readBack.json() as { task: { title: string; done: boolean } };
      // Estävä koodi ei riitä: myös alkuperäisen nimen on säilyttävä.
      assert.equal(unchanged.task.title, "Säilyvä nimi");
      // Samalla tarkistetaan, ettei valmis-tila muuttunut taustalla.
      assert.equal(unchanged.task.done, false);
    }
  } finally {
    // Hävitetään vain tätä koetta varten avattu muistikanta.
    db.close();
  }
});
````

### `esimerkit/04-valmis/integration_test.ts`

````typescript
// assert tarjoaa tarkistuksia, jotka keskeyttävät testin, jos todellinen tulos on väärä.
import assert from "node:assert/strict";
// Käytämme testissä samaa sovelluskäsittelijää kuin oikeassa verkkopalvelimessa.
import { createApp } from "./app.ts";
// Jokainen testi saa oman SQLite-kantansa; opiskelijan sovelluskantaa ei avata.
import { openDatabase, type User } from "./db.ts";
// Sama vakio auttaa kokeilemaan juuri sovelluksen istunnon vanhenemisrajaa.
import { hashSessionToken, PASSWORD_ITERATIONS, SESSION_SECONDS } from "./security.ts";

// Testipyyntöjen origin on täsmälleen sama kuin harjoituksen selaimessa käytetty osoite.
const ORIGIN = "http://localhost:8000";
// Tämä on julkinen testisalalause, jota ei pidä käyttää oikean tilin salasanana.
const PASSWORD = "Vain testin pitka salalause 123!";

// Fixture tarkoittaa testin tarvitsemien olioiden valmisteltua kokonaisuutta.
function fixture() {
  // :memory: pitää tämän testin taulut RAM-muistissa vain yhteyden eliniän ajan.
  const db = openDatabase(":memory:");
  // Testikello on erillinen muuttuja, jotta vanhenemista voidaan testata odottamatta kahdeksaa tuntia.
  let time = Date.UTC(2026, 0, 1);
  // Nuolifunktio lukee nykyisen time-arvon joka kutsulla.
  const app = createApp(db, { origin: ORIGIN, now: () => time });
  // request kutsuu HTTP-käsittelijää oikealla Request-oliolla avaamatta verkkoyhteyttä.
  const request = (path: string, options: RequestInit = {}, ip = "127.0.0.1") =>
    app(new Request(ORIGIN + path, options), ip);
  // Palautettava advance-funktio siirtää vain tämän testin kelloa.
  return {
    db,
    request,
    advance: (milliseconds: number) => {
      time += milliseconds;
    },
  };
}

// ReturnType poimii fixture-funktion palauttaman olion tyypin, jotta sitä ei kirjoiteta kahdesti.
type Fixture = ReturnType<typeof fixture>;

// Tämä apufunktio jäljittelee frontendin kirjoittavaa fetch-pyyntöä.
function write(method: string, body: unknown, cookie = ""): RequestInit {
  // Otsakkeet sisältävät testissä käsin Originin; oikea selain asettaa sen itse.
  return {
    method,
    headers: { Origin: ORIGIN, "Content-Type": "application/json", Cookie: cookie },
    body: JSON.stringify(body),
  };
}

// Rekisteröimme käyttäjän oikean API:n kautta, jolloin myös salasanan käsittely ja sessio testautuvat.
async function register(test: Fixture, email: string) {
  // Testin POST-pyyntö sisältää vain API:n sallimat kentät.
  const response = await test.request(
    "/api/auth/register",
    write("POST", { email, password: PASSWORD }),
  );
  // Rekisteröinti on onnistunut vasta, kun tilakoodi on 201.
  assert.equal(response.status, 201);
  // Käyttäjä luetaan JSON-vastauksesta; tämän jälkeen yksittäisiä kenttiä tarkistetaan testissä.
  const data = await response.json() as { user: User };
  // Luemme selaimeen tarkoitetun Set-Cookie-otsakkeen testiasiakkaan muistiksi.
  const setCookie = response.headers.get("set-cookie");
  // assert.ok varmistaa, ettei arvo puutu; TypeScriptkin oppii sen olevan nyt olemassa.
  assert.ok(setCookie);
  // Seuraavaan pyyntöön lähetetään vain nimi=arvo, ei HttpOnly- tai Max-Age-määrityksiä.
  const cookie = setCookie.split(";")[0];
  // Palautamme sekä käyttäjän että evästeen jatkopolkua varten.
  return { user: data.user, cookie, setCookie };
}

// Deno.test rekisteröi testin; async sallii API-pyyntöjen odottamisen sen sisällä.
Deno.test("Rekisteröinti tallentaa suolatun PBKDF2-tiivisteen ja vain istuntotunnisteen tiivisteen", async () => {
  // Jokainen testi luo oman eristetyn tietokannan.
  const test = fixture();
  // finally sulkee yhteyden, vaikka jokin tarkistus epäonnistuisi.
  try {
    // Iso alkukirjain havainnollistaa sähköpostin yhdenmukaistamista.
    const alice = await register(test, "Alice@example.test");
    // Toinen käyttäjä käyttää samaa julkista testisalalausetta.
    const bob = await register(test, "bob@example.test");
    // API kertoo aina palvelimen määrittämän tavallisen roolin.
    assert.equal(alice.user.role, "user");
    // Sähköpostin kirjainkoko on yhdenmukaistettu.
    assert.equal(alice.user.email, "alice@example.test");
    // Julkisen käyttäjän kenttiin ei kuulu salasana tai sen tiiviste.
    assert.deepEqual(Object.keys(alice.user).sort(), ["email", "id", "role"]);
    // Evästeen suojaominaisuudet ovat mukana paikallisessakin kehityksessä.
    assert.match(alice.setCookie, /HttpOnly; SameSite=Strict; Max-Age=28800/);
    // HTTP-localhost ei käytä Secure-määritystä; HTTPS-versio testataan erikseen.
    assert.equal(alice.setCookie.includes("; Secure"), false);
    // Tietokanta luetaan tässä vain testin sisällä, ei julkisesta API:sta.
    const rows = test.db.prepare(
      "SELECT password_hash, password_salt, password_iterations FROM users ORDER BY id",
    ).all();
    // Sama salasana tuottaa eri suolan jokaiselle käyttäjälle.
    assert.notEqual(rows[0].password_salt, rows[1].password_salt);
    // Eri suola tuottaa myös eri tiivisteen samasta salasanasta.
    assert.notEqual(rows[0].password_hash, rows[1].password_hash);
    // Salasana ei saa olla suoraan tallennettu vertailukenttään.
    assert.notEqual(rows[0].password_hash, PASSWORD);
    // Hitaan laskennan työmäärä on sovittu 600000 kierrosta.
    assert.equal(rows[0].password_iterations, PASSWORD_ITERATIONS);
    // Poimimme vain evästeen salaisen arvon nimi=arvo-parista.
    const rawToken = alice.cookie.split("=")[1];
    // Istuntorivi haetaan käyttäjän tunnuksella vain tätä testiä varten.
    const session = test.db.prepare("SELECT token_hash FROM sessions WHERE user_id = ?").get(
      alice.user.id,
    );
    // Tietokannassa ei ole selaimelle annettua raakaa tunnistetta.
    assert.notEqual(session?.token_hash, rawToken);
    // Tallennettu arvo on täsmälleen raakatunnisteen SHA-256-tiiviste.
    assert.equal(session?.token_hash, await hashSessionToken(rawToken));
    // Kahden käyttäjän evästeet ovat erilliset.
    assert.notEqual(alice.cookie, bob.cookie);
  } finally {
    // Muistitietokannan sisältö katoaa, kun tämän testin yhteys suljetaan.
    test.db.close();
  }
});

// Tämä testi todentaa kirjautumisen, tunnisteen vaihdon ja uloskirjautumisen palvelimen puolella.
Deno.test("Login vaihtaa istunnon; logout mitätöi myös kopioidun vanhan evästeen", async () => {
  // Uusi fixture varmistaa, etteivät aiemman testin käyttäjät vaikuta tähän.
  const test = fixture();
  // Yhteys siivotaan onnistumisen ja epäonnistumisen jälkeen.
  try {
    // Suojatun datan lukeminen ilman kirjautumista on kielletty.
    assert.equal((await test.request("/api/projects")).status, 401);
    // Myös ylläpitotilastot vaativat ensin autentikoinnin.
    assert.equal((await test.request("/api/admin/stats")).status, 401);
    // Kirjaudumme aluksi rekisteröimällä uuden käyttäjän.
    const alice = await register(test, "alice@example.test");
    // Nykyisen käyttäjän haku hyväksyy voimassa olevan evästeen.
    assert.equal(
      (await test.request("/api/auth/me", { headers: { Cookie: alice.cookie } })).status,
      200,
    );
    // Onnistunut login saa myös vanhan evästeen, jotta sen korvaaminen tulee testatuksi.
    const login = await test.request(
      "/api/auth/login",
      write("POST", { email: alice.user.email, password: PASSWORD }, alice.cookie),
    );
    // Oikeilla tunnuksilla kirjautuminen onnistuu.
    assert.equal(login.status, 200);
    // Uuden vastauksen evästeestä poimitaan nimi=arvo-osa.
    const newCookie = login.headers.get("set-cookie")!.split(";")[0]; // ! on tyyppivakuutus testin onnistumisoletuksesta.
    // Vanhaa tunnistetta ei käytetä uudelleen.
    assert.notEqual(newCookie, alice.cookie);
    // Kopio aiemmasta evästeestä ei enää tunnista käyttäjää.
    assert.equal(
      (await test.request("/api/auth/me", { headers: { Cookie: alice.cookie } })).status,
      401,
    );
    // Uusi eväste toimii.
    assert.equal(
      (await test.request("/api/auth/me", { headers: { Cookie: newCookie } })).status,
      200,
    );
    // Uloskirjautuminen lähetetään kirjoittavana, Origin-tarkistettuna JSON-pyyntönä.
    const logout = await test.request("/api/auth/logout", write("POST", {}, newCookie));
    // 204 ilmaisee onnistumisen ilman vastausrunkoa.
    assert.equal(logout.status, 204);
    // Selain ohjataan poistamaan eväste.
    assert.match(logout.headers.get("set-cookie") ?? "", /Max-Age=0/);
    // Myöskään käsin talletettu kopio viimeisestä evästeestä ei enää toimi.
    assert.equal(
      (await test.request("/api/auth/me", { headers: { Cookie: newCookie } })).status,
      401,
    );
    // Palvelimen istuntotaulu on tyhjä: kyse ei ollut vain käyttöliittymän piilottamisesta.
    assert.equal(test.db.prepare("SELECT COUNT(*) AS total FROM sessions").get()?.total, 0);
  } finally {
    // Yhteys suljetaan riippumatta assert-tarkistusten tuloksista.
    test.db.close();
  }
});

// Hallittava testikello korvaa oikean kahdeksan tunnin odottamisen.
Deno.test("Istunto vanhenee palvelimella tasan kahdeksan tunnin kohdalla", async () => {
  // Muistissa olevat käyttäjä- ja istuntorivit kuuluvat vain tähän testiin.
  const test = fixture();
  // try/finally pitää resurssien siivouksen varmana.
  try {
    // Luodaan tunnistettu käyttäjä.
    const alice = await register(test, "alice@example.test");
    // Siirrytään yhden millisekunnin päähän vanhenemisesta.
    test.advance(SESSION_SECONDS * 1000 - 1);
    // Juuri ennen rajaa istunto on voimassa.
    assert.equal(
      (await test.request("/api/auth/me", { headers: { Cookie: alice.cookie } })).status,
      200,
    );
    // Saavutetaan tarkka vanhenemishetki.
    test.advance(1);
    // Palvelin hylkää evästeen, vaikka testiasiakas lähettää sen edelleen.
    assert.equal(
      (await test.request("/api/auth/me", { headers: { Cookie: alice.cookie } })).status,
      401,
    );
    // Myös tietokannan vanhentunut rivi poistetaan.
    assert.equal(test.db.prepare("SELECT COUNT(*) AS total FROM sessions").get()?.total, 0);
  } finally {
    // Sulkeminen hävittää tämän testin muistitietokannan.
    test.db.close();
  }
});

// Nämä ovat varsinaiset horisontaalisen käyttöoikeuden kielteiset testit kahdella käyttäjällä.
Deno.test("B ei lue, luo, muuta eikä poista A:n projektin tai tehtävän tietoja", async () => {
  // Testi käyttää oikeita tietokantaviittauksia ja oikeita istuntoja.
  const test = fixture();
  // Lopussa yhteys suljetaan myös mahdollisen tietoturvavirheen paljastuessa.
  try {
    // A ja B ovat kaksi erillistä rekisteröityä tavallista käyttäjää.
    const alice = await register(test, "alice@example.test");
    // Toinen rekisteröinti saa uuden käyttäjätunnuksen ja uuden evästeen.
    const bob = await register(test, "bob@example.test");
    // A luo projektinsa API:n kautta; user_id ei esiinny pyynnössä.
    const createdProject = await test.request(
      "/api/projects",
      write("POST", { title: "A:n projekti" }, alice.cookie),
    );
    // Projektin luomisen pitää onnistua.
    assert.equal(createdProject.status, 201);
    // Otamme talteen uuden projektin tunnuksen seuraavia pyyntöjä varten.
    const { project } = await createdProject.json();
    // A lisää tehtävän omaan projektiinsa.
    const createdTask = await test.request(
      `/api/projects/${project.id}/tasks`,
      write("POST", { title: "A:n tehtävä" }, alice.cookie),
    );
    // Tehtävän luominen palauttaa uuden resurssin.
    assert.equal(createdTask.status, 201);
    // Otamme talteen myös tehtävän tunnuksen.
    const { task } = await createdTask.json();
    // B:n oma projektikokoelma ei sisällä A:n projektia.
    const bList = await test.request("/api/projects", { headers: { Cookie: bob.cookie } });
    // Tyhjä lista ei vuoda edes vieraan projektin nimeä.
    assert.deepEqual(await bList.json(), { projects: [] });
    // Kukin rivi on yksi eri tapa yrittää päästä A:n tietoihin B:n tunnuksilla.
    const attacks: Array<[string, string, unknown]> = [
      ["GET", `/api/projects/${project.id}`, undefined], // Suora projektin luku.
      ["PATCH", `/api/projects/${project.id}`, { title: "B:n muutos" }], // Projektin nimen muutos.
      ["DELETE", `/api/projects/${project.id}`, {}], // Koko projektin poistaminen.
      ["GET", `/api/projects/${project.id}/tasks`, undefined], // Vieraan projektin tehtävälista.
      ["POST", `/api/projects/${project.id}/tasks`, { title: "B:n lisäys" }], // Tehtävän lisääminen vieraaseen projektiin.
      ["GET", `/api/tasks/${task.id}`, undefined], // Yhden vieraan tehtävän luku.
      ["PATCH", `/api/tasks/${task.id}`, { done: true }], // Vieraan tehtävän tilan muutos.
      ["DELETE", `/api/tasks/${task.id}`, {}], // Vieraan tehtävän poistaminen.
    ];
    // Destrukturointi antaa jokaisen testirivin kolme osaa omiksi muuttujikseen.
    for (const [method, path, body] of attacks) {
      // Lukupyyntö tarvitsee vain evästeen; kirjoitus käyttää samaa suojattua JSON-muotoa kuin frontend.
      const options = method === "GET"
        ? { headers: { Cookie: bob.cookie } }
        : write(method, body, bob.cookie);
      // Vieraalle resurssille palautuu 404 riippumatta siitä, onko toiminto luku vai muutos.
      assert.equal((await test.request(path, options)).status, 404, `${method} ${path}`);
    }
    // A pystyy yhä lukemaan tehtävänsä epäonnistuneiden hyökkäysten jälkeen.
    const unchanged = await test.request(`/api/tasks/${task.id}`, {
      headers: { Cookie: alice.cookie },
    });
    // Pelkkä virhetilakoodi ei riitä todisteeksi: tarkistamme myös, ettei data muuttunut.
    assert.deepEqual((await unchanged.json()).task, task);
    // A:n projektissakin on edelleen alkuperäinen nimi.
    const intactProject = await test.request(`/api/projects/${project.id}`, {
      headers: { Cookie: alice.cookie },
    });
    // Tallennettu projekti vastaa ennen hyökkäyksiä luotua projektia.
    assert.deepEqual((await intactProject.json()).project, project);
    // Omistajan sallittu päivitys toimii samasta suojatusta reitistä.
    const changed = await test.request(
      `/api/tasks/${task.id}`,
      write("PATCH", { title: "A:n päivitetty tehtävä", done: true }, alice.cookie),
    );
    // Päivitys onnistuu oikealla käyttäjällä.
    assert.equal(changed.status, 200);
    // Vastauksessa on oikea boolean-arvo.
    assert.equal((await changed.json()).task.done, true);
    // Omistaja saa poistaa oman tehtävänsä.
    assert.equal(
      (await test.request(`/api/tasks/${task.id}`, write("DELETE", {}, alice.cookie))).status,
      204,
    );
    // Poistettu tehtävä ei enää löydy omistajaltakaan.
    assert.equal(
      (await test.request(`/api/tasks/${task.id}`, { headers: { Cookie: alice.cookie } })).status,
      404,
    );
    // Luomme vielä tehtävän, jotta projektin kaskadipoisto voidaan todentaa.
    assert.equal(
      (await test.request(
        `/api/projects/${project.id}/tasks`,
        write("POST", { title: "Poistuu projektin mukana" }, alice.cookie),
      )).status,
      201,
    );
    // Projektin omistajan poistopyyntö onnistuu.
    assert.equal(
      (await test.request(`/api/projects/${project.id}`, write("DELETE", {}, alice.cookie))).status,
      204,
    );
    // Viiteavaimen CASCADE-sääntö poisti myös projektiin kuuluneen tehtävän.
    assert.equal(test.db.prepare("SELECT COUNT(*) AS total FROM tasks").get()?.total, 0);
  } finally {
    // Sulkemme vain tämän testin kannan.
    test.db.close();
  }
});

// Roolin väärentäminen ja toisen omistajan syöttäminen pitää hylätä palvelimella.
Deno.test("Asiakas ei valitse roolia tai omistajaa; admin näkee vain erikseen sallitut yhteismäärät", async () => {
  // Testin tietokanta on aluksi tyhjä.
  const test = fixture();
  // Suljemme tietokannan myös silloin, jos jokin oikeustarkistus on rikki.
  try {
    // Hyökkääjä yrittää lisätä rekisteröintirunkoon admin-roolin.
    const forged = await test.request(
      "/api/auth/register",
      write("POST", { email: "evil@example.test", password: PASSWORD, role: "admin" }),
    );
    // Ylimääräinen kenttä johtaa 400-virheeseen ennen käyttäjän luomista.
    assert.equal(forged.status, 400);
    // Tarkistamme myös sivuvaikutuksen puuttumisen.
    assert.equal(test.db.prepare("SELECT COUNT(*) AS total FROM users").get()?.total, 0);
    // Luomme oikean tavallisen käyttäjän.
    const alice = await register(test, "alice@example.test");
    // Luomme toisen käyttäjän, jonka omistajuutta ei saa jäljitellä.
    const bob = await register(test, "bob@example.test");
    // Tavallinen käyttäjä ei saa ylläpitotilastoja.
    assert.equal(
      (await test.request("/api/admin/stats", { headers: { Cookie: alice.cookie } })).status,
      403,
    );
    // A yrittää tehdä projektin B:n omistukseen lähettämällä ylimääräisen user_id-kentän.
    const forgedOwner = await test.request(
      "/api/projects",
      write("POST", { title: "Väärä omistaja", user_id: bob.user.id }, alice.cookie),
    );
    // Palvelin hylkää koko pyynnön.
    assert.equal(forgedOwner.status, 400);
    // Epäonnistunut pyyntö ei luonut projektia kenellekään.
    assert.equal(test.db.prepare("SELECT COUNT(*) AS total FROM projects").get()?.total, 0);
    // B luo itselleen yhden aidon projektin.
    const bProjectResponse = await test.request(
      "/api/projects",
      write("POST", { title: "B:n yksityinen projekti" }, bob.cookie),
    );
    // Tunnusta käytetään myöhemmin ylläpitäjän oikeuksien rajauksen testiin.
    const { project } = await bProjectResponse.json();
    // Testi jäljittelee paikallista admin-komentoa: rooli muuttuu luotetussa tietokantakäytössä.
    test.db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(alice.user.id);
    // Istunnon käyttäjän rooli luetaan palvelimella uudelleen jokaisessa pyynnössä.
    const stats = await test.request("/api/admin/stats", { headers: { Cookie: alice.cookie } });
    // Ylläpitäjä pääsee nimenomaisesti tähän yhteismääräreittiin.
    assert.equal(stats.status, 200);
    // Vastauksessa on vain laskurit: ei salasanoja, sähköposteja tai muiden projektien nimiä.
    assert.deepEqual(await stats.json(), { users: 2, projects: 1, tasks: 0 });
    // Admin-rooli ei ohita omistajuussääntöä tavallisilla projektireiteillä.
    assert.equal(
      (await test.request(`/api/projects/${project.id}`, { headers: { Cookie: alice.cookie } }))
        .status,
      404,
    );
    // Adminin oma projektikokoelma pysyy omana kokoelmana.
    assert.deepEqual(
      await (await test.request("/api/projects", { headers: { Cookie: alice.cookie } })).json(),
      { projects: [] },
    );
  } finally {
    // Siivoamme testin resurssin.
    test.db.close();
  }
});

// CSRF-, kokoraja- ja tyyppitarkistukset kokeillaan suoraan HTTP-pyynnöillä.
Deno.test("Origin, sisältötyyppi, rungon koko ja kenttien tyypit tarkistetaan palvelimella", async () => {
  // Tämä testi ei luota frontendin lomakkeiden rajoituksiin.
  const test = fixture();
  // finally sulkee kannan jokaisella lopputuloksella.
  try {
    // Muodostamme muuten kelvollisen rekisteröintipyynnön.
    const valid = write("POST", { email: "alice@example.test", password: PASSWORD });
    // Vieraan sivuston alkuperä ei kelpaa, vaikka sisältö olisi oikeaa JSONia.
    const foreign = {
      ...valid,
      headers: { Origin: "https://vieras.example", "Content-Type": "application/json" },
    };
    // Hylkäys tapahtuu ennen tilin luomista.
    assert.equal((await test.request("/api/auth/register", foreign)).status, 403);
    // Myös puuttuva Origin on tarkoituksella hylättävä.
    assert.equal(
      (await test.request("/api/auth/register", {
        ...valid,
        headers: { "Content-Type": "application/json" },
      })).status,
      403,
    );
    // localhost ja 127.0.0.1 eivät ole sama origin, vaikka ne voivat osoittaa samalle koneelle.
    assert.equal(
      (await test.request("/api/auth/register", {
        ...valid,
        headers: { Origin: "http://127.0.0.1:8000", "Content-Type": "application/json" },
      })).status,
      403,
    );
    // Oikeakaan origin ei salli tekstilomaketta JSON-API:n kirjoitukseen.
    assert.equal(
      (await test.request("/api/auth/register", {
        ...valid,
        headers: { Origin: ORIGIN, "Content-Type": "text/plain" },
      })).status,
      415,
    );
    // Rikkinäinen JSON tuottaa 400-virheen.
    assert.equal((await test.request("/api/auth/register", { ...valid, body: "{" })).status, 400);
    // Myös kelvollinen JSON voi olla väärää rakennetta: tässä taulukko olion sijaan.
    assert.equal((await test.request("/api/auth/register", write("POST", []))).status, 400);
    // null ei ole lomakedataa kuvaava olio.
    assert.equal((await test.request("/api/auth/register", write("POST", null))).status, 400);
    // Rungon todellinen koko tarkistetaan myös ilman Content-Length-otsaketta.
    assert.equal(
      (await test.request(
        "/api/auth/register",
        write("POST", { email: "a".repeat(17_000), password: PASSWORD }),
      )).status,
      413,
    );
    // Sähköpostin näkymätön NUL-merkki torjutaan jo validoinnissa, ei vasta tietokantavirheenä.
    assert.equal(
      (await test.request(
        "/api/auth/register",
        write("POST", { email: "a\u0000@example.test", password: PASSWORD }),
      )).status,
      400,
    );
    // Hylätyt pyynnöt eivät jättäneet käyttäjärivejä tietokantaan.
    assert.equal(test.db.prepare("SELECT COUNT(*) AS total FROM users").get()?.total, 0);
    // Seuraavaksi käytämme oikeaa kirjautumista datan validoinnin testeissä.
    const alice = await register(test, "alice@example.test");
    // Pelkistä välilyönneistä koostuva projektin nimi on virhe.
    assert.equal(
      (await test.request("/api/projects", write("POST", { title: "   " }, alice.cookie))).status,
      400,
    );
    // Projektin enimmäispituus on 120 merkkiä.
    assert.equal(
      (await test.request("/api/projects", write("POST", { title: "a".repeat(121) }, alice.cookie)))
        .status,
      400,
    );
    // Luomme kelvollisen projektin tehtävätyyppien tarkistusta varten.
    const projectResponse = await test.request(
      "/api/projects",
      write("POST", { title: "Kelvollinen" }, alice.cookie),
    );
    // JSONista poimitaan projektin tunnus.
    const { project } = await projectResponse.json();
    // Tehtävän 200-merkkinen nimi on vielä sallittu.
    const taskResponse = await test.request(
      `/api/projects/${project.id}/tasks`,
      write("POST", { title: "a".repeat(200) }, alice.cookie),
    );
    // Projektin ja tehtävän pituusrajat ovat tarkoituksella erilaiset.
    assert.equal(taskResponse.status, 201);
    // Tallennetaan luodun tehtävän tunnus.
    const { task } = await taskResponse.json();
    // JSON-teksti "false" ei saa vahingossa tulkintua totuudeksi.
    assert.equal(
      (await test.request(`/api/tasks/${task.id}`, write("PATCH", { done: "false" }, alice.cookie)))
        .status,
      400,
    );
    // Tehtävän siirtäminen project_id-kentällä ei kuulu tähän API:in.
    assert.equal(
      (await test.request(
        `/api/tasks/${task.id}`,
        write("PATCH", { project_id: 999 }, alice.cookie),
      )).status,
      400,
    );
    // Kumpikaan hylätty päivitys ei muuttanut tehtävän tilaa.
    assert.equal(test.db.prepare("SELECT done FROM tasks WHERE id = ?").get(task.id)?.done, 0);
  } finally {
    // Suljemme tämän testin erillisen tietokannan.
    test.db.close();
  }
});

// Testi havainnollistaa SQL-parametrien tarkoitusta myös erikoismerkkejä sisältävällä datalla.
Deno.test("Heittomerkit ja HTML-teksti tallentuvat datana ilman SQL-koodin suorittamista", async () => {
  // Uusi tietokanta estää aiempien testien sivuvaikutukset.
  const test = fixture();
  // Lopuksi yhteys suljetaan.
  try {
    // Luomme tavallisen käyttäjän, jolla on oikeus omaan projektiinsa.
    const alice = await register(test, "alice@example.test");
    // Nimi näyttää SQL-lauseelta, mutta sitä pitää käsitellä tavallisena tekstinä.
    const title = "O'Brian'); DROP TABLE users; --";
    // Lähetämme tekstin tavallisessa nimikentässä.
    const response = await test.request("/api/projects", write("POST", { title }, alice.cookie));
    // Projekti saa syntyä, koska välimerkit ovat sallittua nimeä.
    assert.equal(response.status, 201);
    // Tallennettu arvo on sama teksti; sitä ei ole tulkittu SQL-komennoksi.
    assert.equal((await response.json()).project.title, title);
    // users-taulu on edelleen olemassa ja sisältää käyttäjänsä.
    assert.equal(test.db.prepare("SELECT COUNT(*) AS total FROM users").get()?.total, 1);
    // HTML:ltä näyttävä nimiteksti saa myös säilyä datana.
    const html = "<img src=x onerror=alert('xss')>";
    // Turvallinen frontend näyttää arvon textContentilla, ei innerHTML:llä.
    const htmlResponse = await test.request(
      "/api/projects",
      write("POST", { title: html }, alice.cookie),
    );
    // API kertoo sisällön olevan JSONia, jotta selain ei tulkitse sitä HTML-sivuksi.
    assert.match(htmlResponse.headers.get("content-type") ?? "", /^application\/json/);
    // JSONissa teksti on ennallaan; selaimessa suorittamattomuus varmistetaan myös frontend-harjoituksessa.
    assert.equal((await htmlResponse.json()).project.title, html);
  } finally {
    // Suljemme kannan, vaikka injektiotesti paljastaisi virheen.
    test.db.close();
  }
});

// Suojausotsakkeiden ja sallitun tiedostolistan vaikutukset kokeillaan todellisilla poluilla.
Deno.test("Staattinen allowlist ei paljasta lähdekoodia tai tietokantaa ja CSP on käytössä", async () => {
  // Muistitietokanta riittää, koska tiedostoreitit eivät tarvitse käyttäjädataa.
  const test = fixture();
  // Sulkeminen on tämänkin testin vastuulla.
  try {
    // Jokainen näistä tiedostoista on kielletty, vaikka nimi arvataan oikein.
    for (
      const path of [
        "/db.ts",
        "/deno.jsonc",
        "/01_create_schema.sql",
        "/data/tehtavataulu.sqlite",
        "/.env",
        "/%2e%2e/db.ts",
      ]
    ) {
      // Suoraan kirjoitettu tiedostopolku ei muuta palvelimen allowlistiä.
      assert.equal((await test.request(path)).status, 404, path);
    }
    // Oikea etusivu on julkisesti saatavilla.
    const index = await test.request("/");
    // Käynnistyspaketissa pitää olla myös frontend-tiedostot.
    assert.equal(index.status, 200);
    // Skriptejä saa ladata vain samasta originista.
    assert.match(index.headers.get("content-security-policy") ?? "", /script-src 'self'/);
    // CSP ei salli inline-JavaScriptiä.
    assert.equal(
      (index.headers.get("content-security-policy") ?? "").includes("unsafe-inline"),
      false,
    );
    // Sisältötyypin arvaaminen on estetty.
    assert.equal(index.headers.get("x-content-type-options"), "nosniff");
    // Kirjautuneen sovelluksen vastauksia ei tallenneta välimuistiin.
    assert.equal(index.headers.get("cache-control"), "no-store");
    // POST ei voi kirjoittaa julkista CSS-tiedostoa.
    assert.equal((await test.request("/styles.css", write("POST", {}))).status, 405);
    // Myös virhevastaukset saavat samat suojausotsakkeet.
    const denied = await test.request("/api/auth/me");
    // Ulkopuolinen sivusto ei saa kehystää edes kirjautumisvirhettä.
    assert.equal(denied.headers.get("x-frame-options"), "DENY");
  } finally {
    // Suljemme testin kannan.
    test.db.close();
  }
});

// Geneerinen virhe ja yritysraja ovat eri suojauksia; testaamme molemmat.
Deno.test("Väärä ja tuntematon tili saavat saman virheen, ja kirjautumisyrityksiä rajoitetaan", async () => {
  // Uusi sovellus saa uuden, aluksi tyhjän prosessikohtaisen laskurin.
  const test = fixture();
  // Lopuksi yhteys vapautetaan.
  try {
    // Luomme yhden oikean tilin väärän salasanan kokeilua varten.
    const alice = await register(test, "alice@example.test");
    // Tämä salasana täyttää pituussäännön mutta ei vastaa tilin salasanaa.
    const wrongPassword = "Väärä mutta tarpeeksi pitkä salalause";
    // Tunnettu sähköposti ja väärä salasana eivät saa kirjata sisään.
    const known = await test.request(
      "/api/auth/login",
      write("POST", { email: alice.user.email, password: wrongPassword }),
    );
    // Tuntematon tili saa saman laskentapolun ja julkisen virheen.
    const unknown = await test.request(
      "/api/auth/login",
      write("POST", { email: "unknown@example.test", password: wrongPassword }),
    );
    // Molemmat tulkitaan epäonnistuneiksi kirjautumisiksi.
    assert.equal(known.status, 401);
    // Tilakoodi ei paljasta tilin olemassaoloa.
    assert.equal(unknown.status, 401);
    // Myös virheteksti on sama.
    assert.deepEqual(await known.json(), await unknown.json());
    // Yksi A:n epäonnistuminen on jo tehty; neljä lisää täyttää viiden yrityksen rajan.
    for (let count = 0; count < 4; count++) {
      // Kukin sallittujen yritysten sisäinen väärä kirjautuminen saa normaalin 401-virheen.
      assert.equal(
        (await test.request(
          "/api/auth/login",
          write("POST", { email: alice.user.email, password: wrongPassword }),
        )).status,
        401,
      );
    }
    // Kuudes yritys hylätään jo ennen hidasta salasanatyötä, vaikka salasana olisi nyt oikein.
    const limited = await test.request(
      "/api/auth/login",
      write("POST", { email: alice.user.email, password: PASSWORD }),
    );
    // 429 ilmaisee ylittyneen yritysrajan.
    assert.equal(limited.status, 429);
    // Odotusaika ilmoitetaan standardiotsakkeessa sekunteina.
    assert.equal(limited.headers.get("retry-after"), "900");
    // Testikello siirretään seuraavan aikaikkunan alkuun.
    test.advance(15 * 60 * 1000);
    // Rajoitus ei lukitse tiliä loputtomasti: oikea kirjautuminen toimii aikarajan jälkeen.
    assert.equal(
      (await test.request(
        "/api/auth/login",
        write("POST", { email: alice.user.email, password: PASSWORD }),
      )).status,
      200,
    );
  } finally {
    // Suljemme vain tämän testin tietokannan.
    test.db.close();
  }
});

// Tässä kokeillaan aidon tiedoston säilyvyyttä ja tietokannan omia eheyssääntöjä.
Deno.test("SQLite säilyttää datan uudelleenavauksessa, migraatio ei toistu ja viiteavaimet toimivat", () => {
  // Testien väliaikaiset tiedostot rajataan data-hakemiston erilliseen alihakemistoon.
  Deno.mkdirSync("./data", { recursive: true });
  // makeTempDirSync luo yksilöllisen kansion, joten opiskelijan varsinainen kanta ei ole vaarassa.
  const directory = Deno.makeTempDirSync({ dir: "./data", prefix: "test-" });
  // Tämän polun omistaa vain tämä testi.
  const path = `${directory}/test.sqlite`;
  // Ensimmäinen avaus luo tietokannan ja suorittaa migraation 1.
  let db = openDatabase(path);
  // Suljemme viimeisen yhteyden ja poistamme vain oman väliaikaisen kansion.
  try {
    // Tämä suoraan lisätty rivi on vain rakennetestiä varten; API-testit käyttävät oikeaa salasanan laskentaa.
    const inserted = db.prepare(
      "INSERT INTO users(email, password_hash, password_salt, password_iterations) VALUES (?, ?, ?, ?)",
    ).run("persist@example.test", "a".repeat(64), "b".repeat(32), PASSWORD_ITERATIONS);
    // Käytämme tietokannan juuri antamaa tunnusta omistajaviittaukseen.
    const ownerId = Number(inserted.lastInsertRowid);
    // Projektin lisääminen olemassa olevalle omistajalle onnistuu.
    db.prepare("INSERT INTO projects(user_id, title) VALUES (?, ?)").run(
      ownerId,
      "Säilyvä projekti",
    );
    // Viiteavain estää projektin luomisen käyttäjälle, jota ei ole.
    assert.throws(() =>
      db.prepare("INSERT INTO projects(user_id, title) VALUES (?, ?)").run(999999, "Orpo projekti")
    );
    // Tietokanta tarkistaa nimen pituuden myös API:n ulkopuolisessa kirjoituksessa.
    assert.throws(() =>
      db.prepare("INSERT INTO projects(user_id, title) VALUES (?, ?)").run(ownerId, "")
    );
    // Suljemme ensimmäisen yhteyden simuloidaksemme palvelimen pysäyttämistä.
    db.close();
    // Uusi yhteys samaan tiedostoon simuloisi seuraavaa käynnistystä.
    db = openDatabase(path);
    // Aiemmin tallennettu projekti on edelleen olemassa.
    assert.equal(db.prepare("SELECT title FROM projects").get()?.title, "Säilyvä projekti");
    // Migraatiokirjanpidossa on yhä vain yksi suoritettu muutos.
    assert.equal(db.prepare("SELECT COUNT(*) AS total FROM schema_migrations").get()?.total, 1);
    // Myös uudessa yhteydessä viiteavainten tarkistus on käytössä.
    assert.throws(() =>
      db.prepare("INSERT INTO tasks(project_id, title) VALUES (?, ?)").run(999999, "Orpo tehtävä")
    );
  } finally {
    // Suljemme SQLite-tiedoston ennen hakemiston poistamista.
    db.close();
    // recursive poistaa vain yllä tämän testin luoman väliaikaisen hakemiston sisältöineen.
    Deno.removeSync(directory, { recursive: true });
  }
});

// HTTPS-evästeen asetusta testataan erikseen ilman oikean TLS-palvelimen käynnistämistä.
Deno.test("HTTPS-origin lisää Secure-määrityksen istuntoevästeeseen", async () => {
  // Kanta on vain tässä testissä tarvittava muistitietokanta.
  const db = openDatabase(":memory:");
  // HTTPS-origin kertoo sovellukselle julkisen palvelun olevan salattu.
  const origin = "https://kurssi.example";
  // Käsittelijä toimii Request-olioilla riippumatta siitä, onko testillä verkkoporttia.
  const app = createApp(db, { origin });
  // Lopussa muistitietokanta suljetaan.
  try {
    // Rekisteröintipyyntö käyttää täsmälleen tähän sovellukseen asetettua originia.
    const response = await app(
      new Request(`${origin}/api/auth/register`, {
        method: "POST",
        headers: { Origin: origin, "Content-Type": "application/json" },
        body: JSON.stringify({ email: "secure@example.test", password: PASSWORD }),
      }),
    );
    // Rekisteröinti onnistuu myös HTTPS-asetuksella.
    assert.equal(response.status, 201);
    // Secure estää selainta lähettämästä istuntotunnistetta salaamattomaan HTTP-yhteyteen.
    assert.match(response.headers.get("set-cookie") ?? "", /; Secure$/);
    // HSTS täydentää HTTPS-palvelun selaimelle antamaa ohjetta.
    assert.equal(response.headers.get("strict-transport-security"), "max-age=31536000");
  } finally {
    // Siivoamme tämän testin kannan.
    db.close();
  }
});
````

### `esimerkit/04-valmis/seed/admin.ts`

````typescript
// Paikallinen ylläpitokomento käyttää samaa tietokantaa ja migraatiota kuin palvelin.
import { openDatabase } from "../db.ts";
// Sama sähköpostin normalisointi estää erilaisten kirjainkokojen aiheuttaman epäselvyyden.
import { requireEmail } from "../http.ts";

// Deno.args sisältää skriptin jälkeen annetut komentoriviargumentit.
if (Deno.args.length !== 1) {
  // Tämä ohje ei sisällä salasanaa; salasanoja ei anneta komentoriviargumentteina.
  console.error(
    "Käyttö: deno task admin opiskelija@example.test. Rekisteröi tili ensin selaimessa.",
  );
  // Exit-koodi 1 kertoo, ettei komento onnistunut.
  Deno.exit(1);
}
// Tarkistamme osoitteen ennen tiedostojen avaamista.
const email = requireEmail(Deno.args[0]);
// Hakemisto luodaan tarvittaessa, mutta olemassa olevaa dataa ei poisteta.
await Deno.mkdir("./data", { recursive: true });
// Tämän tiedoston voi ajaa vain henkilö, jolla on paikallinen pääsy tietokantatiedostoon.
const db = openDatabase("./data/tehtavataulu.sqlite");
// finally varmistaa, että tietokantayhteys suljetaan myös virhetilanteessa.
try {
  // Rooli vaihdetaan nimenomaan paikallisessa CLI:ssä; julkinen API ei tarjoa tätä operaatiota.
  const result = db.prepare("UPDATE users SET role = 'admin' WHERE email = ?").run(email);
  // Jos käyttäjää ei löytynyt, päivitys ei osunut yhteenkään riviin.
  if (Number(result.changes) === 0) {
    // Rekisteröinti pitää tehdä ensin, jotta salasanan käsittely kulkee saman turvallisen polun kautta.
    console.error("Tiliä ei löytynyt. Rekisteröi tili selaimessa ja suorita komento uudelleen.");
    // exitCode asettaa epäonnistumiskoodin suorittamatta välitöntä poistumista ennen finally-lohkoa.
    Deno.exitCode = 1;
  } else {
    // Kerromme onnistumisesta paljastamatta kirjautumissalaisuutta.
    console.log("Ylläpitäjän rooli asetettiin. Päivitä sovelluksen sivu nähdäksesi tilastot.");
  }
} finally {
  // Suljemme yhteyden ennen komennon päättymistä.
  db.close();
}
````

## 12.9 Dockerin pakollinen PostgreSQL-peruslabra

### `docker-postgres/compose.yaml`

````yaml
# Sama projektinimi tekee harjoituksen kontit ja volumen helposti tunnistettaviksi.
name: tehtavataulu-pg-labra

# Services-osassa luetellaan tällä Compose-tiedostolla käynnistettävät palvelut.
services:
  # db on tietokantapalvelun nimi; toinen saman verkon kontti käyttää sitä osoitteena.
  db:
    # Käytämme PostgreSQL:n pääversiota 17, jonka datakansio on alla kuvattu polku.
    image: postgres:17
    # Environment välittää asetukset käynnistyvälle kontille.
    environment:
      # Tämä tietokanta luodaan, kun datavolume on ensimmäisellä käynnistyksellä tyhjä.
      POSTGRES_DB: kurssilabra
      # Tämä on labran alustava ylläpitotunnus, ei verkkosovelluksen käyttötunnus.
      POSTGRES_USER: lab_owner
      # Compose lukee arvon .env-tiedostosta; tyhjä tai puuttuva arvo estää käynnistyksen.
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?Aseta POSTGRES_PASSWORD tiedostoon .env}
    # Ports avaa yhteyden oman koneen osoitteesta kontin tietokantaporttiin.
    ports:
      # Vain oma kone: isännän osoite, isännän portti ja kontin portti tässä järjestyksessä.
      - "127.0.0.1:5432:5432"
    # Volumes liittää pysyvän tallennustilan ja tarvittavat harjoitustiedostot konttiin.
    volumes:
      # Nimetty volume säilyttää PostgreSQL 17:n datan myös kontin poistamisen jälkeen.
      - pgdata:/var/lib/postgresql/data
      # PostgreSQL suorittaa alustustiedoston vain, kun sen datakansio on tyhjä; ro on vain luku.
      - ./sql/01-schema.sql:/docker-entrypoint-initdb.d/01-schema.sql:ro
      # Näitä SQL-tiedostoja suoritetaan itse labran aikana; niitä saa vain lukea kontista.
      - ./sql:/lab-sql:ro
    # Healthcheck on automaattisesti toistuva tarkistus palvelun valmiudesta.
    healthcheck:
      # TCP-osoite odottaa varsinaista palvelinta, ei alustuksen väliaikaista paikallista yhteyttä.
      test: ["CMD", "pg_isready", "-h", "127.0.0.1", "-U", "lab_owner", "-d", "kurssilabra"]
      # Tarkistus aloitetaan viiden sekunnin välein.
      interval: 5s
      # Yksi tarkistus saa kestää enintään viisi sekuntia.
      timeout: 5s
      # Kymmenen peräkkäistä epäonnistumista johtaa epäterveeseen tilaan.
      retries: 10
      # Alustukselle annetaan aluksi kymmenen sekunnin käynnistymisaika.
      start_period: 10s

# Tässä määritellään projektin hallinnoimat nimetyt volumet.
volumes:
  # Compose luo volumen, jonka nimessä on projektin nimi ja tämä pgdata-osa.
  pgdata:
````

### `docker-postgres/.env.example`

````text
# Kopioi tiedosto nimelle .env ja kirjoita yhtäsuuruusmerkin jälkeen oma harjoitussalasana.
# Käytä vain paikalliseen labraan tarkoitettua salasanaa; älä palauta varsinaista .env-tiedostoa.
POSTGRES_PASSWORD=
````

### `docker-postgres/.gitignore`

````text
# Varsinainen salasana pysyy omalla koneella; mallipohjan saa lisätä versionhallintaan.
.env
````

### `docker-postgres/sql/01-schema.sql`

````sql
-- Tämä erillinen harjoitustaulu havainnollistaa SQL:ää ja Dockerin pysyvää tallennusta.
-- Se ei korvaa Tehtävätaulu-sovelluksen käyttäjä-, projekti-, tehtävä- ja istuntotauluja.
-- CREATE TABLE luo taulun. IF NOT EXISTS sallii tämän saman rakenteen luomiskomennon toistamisen.
CREATE TABLE IF NOT EXISTS lab_notes (
  -- BIGINT on suuri kokonaisluku; tietokanta tuottaa aina yksilöllisen pääavaimen automaattisesti.
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  -- TEXT on tekstiä. NOT NULL estää puuttuvan arvon ja CHECK rajaa siistityn tekstin pituuden.
  label TEXT NOT NULL CHECK (char_length(trim(label)) BETWEEN 1 AND 200),
  -- TIMESTAMPTZ kuvaa ajanhetkeä; DEFAULT antaa uudelle riville automaattisesti nykyhetken.
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
-- Sulkeva sulku päättää sarakeluettelon ja puolipiste päättää SQL-komennon.
);
````

### `docker-postgres/sql/02-write.sql`

````sql
-- PREPARE nimeää SQL-komennon ja määrittelee sen yhden parametrin tekstiksi.
-- Parametri on erikseen annettava arvo: sitä ei liimata osaksi SQL-komennon rakennetta.
PREPARE add_lab_note(text) AS
  -- INSERT lisää uuden rivin; id ja created_at saavat arvonsa automaattisesti.
  INSERT INTO lab_notes (label)
  -- $1 on ensimmäisen parametrin paikka, ei shell-muuttuja tässä SQL-tiedostossa.
  VALUES ($1);

-- EXECUTE antaa valmistellulle komennolle varsinaisen tekstiarvon.
EXECUTE add_lab_note('Tervehdys, pysyva data!');

-- DEALLOCATE vapauttaa nimetyn valmistellun komennon tässä tietokantayhteydessä.
DEALLOCATE add_lab_note;
````

### `docker-postgres/sql/03-read.sql`

````sql
-- SELECT valitsee luettavat sarakkeet, jotta tulosteessa näkyvät tunniste, teksti ja luontihetki.
SELECT id, label, created_at
-- FROM kertoo, mistä taulusta rivit luetaan.
FROM lab_notes
-- ORDER BY näyttää rivit aina tunnisteen mukaisessa nousevassa järjestyksessä.
ORDER BY id;
````

## 12.10 L2-lähtöpohja: koko SQLite-sovellus konttiin

### `esimerkit/04-valmis/Dockerfile`

````dockerfile
# Image on valmis pohja, jossa tämän materiaalin testattu Deno-versio on asennettuna.
FROM denoland/deno:2.9.7

# Rakennusvaiheessa valmistellaan kirjoitettava datakansio ylläpitäjän oikeuksin.
USER root

# WORKDIR valitsee kontin sisäisen hakemiston seuraaville komennoille.
WORKDIR /app

# Kopioi lähdekoodi konttiin deno-käyttäjän omistukseen; .dockerignore rajaa datan ja salaisuudet pois.
COPY --chown=deno:deno . .

# Luo tyhjä datakansio ja anna tavalliselle deno-käyttäjälle siihen kirjoitusoikeus.
RUN mkdir -p /app/data && chown deno:deno /app/data

# Välimuisti on väliaikainen; varsinainen SQLite-data tulee eri kansioon pysyvään volumeen.
ENV DENO_DIR=/tmp/deno-cache

# 0.0.0.0 saa ohjelman kuuntelemaan kontin verkkoliitäntöjä; Compose rajaa isännän julkaisun.
ENV APP_HOST=0.0.0.0

# Sovellus ja Compose käyttävät samaa kontin sisäistä porttia.
ENV APP_PORT=8000

# Selain avaa tämän alkuperän isäntäkoneella; tämä ei ole toisen kontin yhteysosoite.
ENV APP_ORIGIN=http://localhost:8000

# Varsinainen palvelin toimii tavallisena käyttäjänä, ei root-käyttäjänä.
USER deno

# EXPOSE kertoo kuunteluportin dokumentointia varten; se ei yksin julkaise porttia isännälle.
EXPOSE 8000

# Käynnistä selitetty start-task; sen Deno-oikeudet on rajattu deno.jsonc-tiedostossa.
CMD ["deno", "task", "start"]
````

### `esimerkit/04-valmis/compose.sqlite.yaml`

````yaml
# Nimi erottaa tämän SQLite-sovelluksen erillisestä PostgreSQL-peruslabrasta.
name: tehtavataulu-sqlite

# Services sisältää käynnistettävät palvelut; tässä riittää yksi backend-kontti.
services:
  # web on tämän sovelluspalvelun nimi Compose-verkossa.
  web:
    # Rakenna image tämän hakemiston Dockerfilestä ja lähdekoodista.
    build: .
    # Environment välittää nimetyt asetukset kontin Deno-prosessille.
    environment:
      # Kuuntele kontin liitäntöjä, jotta Composen porttiohjaus pääsee ohjelmaan.
      APP_HOST: 0.0.0.0
      # Sama portti on sallittu deno.jsonc-tiedoston verkkoluvassa.
      APP_PORT: "8000"
      # Selaimen tarkka alkuperä säilyy samana kuin paikallisessa Deno-ajossa.
      APP_ORIGIN: http://localhost:8000
    # Ports julkaisee yhden kontin portin vain omalle koneelle.
    ports:
      # Vasemmalla on isännän osoite ja portti, oikealla kontin sisäinen portti.
      - "127.0.0.1:8000:8000"
    # Volumes säilyttää tietokannan myös kontin poistamisen jälkeen.
    volumes:
      # Liitä nimetty taltio siihen hakemistoon, jota main.ts käyttää tietokannalle.
      - sqlite-data:/app/data
    # Palvelimen lähdekoodit ovat ajossa vain luettavia; data-volume on silti kirjoitettava.
    read_only: true
    # Deno tarvitsee välimuistille väliaikaisen kirjoituspaikan; /tmp ei ole pysyvä tietokanta.
    tmpfs:
      # Varaa korkeintaan 64 mebitavua väliaikaisille tiedoille.
      - /tmp:size=64m
    # Pudota ylimääräiset Linuxin erityisoikeudet; tavallinen HTTP-palvelin ei tarvitse niitä.
    cap_drop:
      # ALL tarkoittaa kaikkien pudotettavissa olevien lisäoikeuksien poistamista.
      - ALL
    # Estä prosessia hankkimasta uusia korkeampia käyttöoikeuksia ajon aikana.
    security_opt:
      # Tämä asetus täydentää Dockerfilen tavallista deno-käyttäjää.
      - no-new-privileges:true

# Määrittele Compose-projektin hallinnoima pysyvä taltio.
volumes:
  # Taltio syntyy ensimmäisessä käynnistyksessä; tavallinen down ei poista sitä.
  sqlite-data:
````

### `esimerkit/04-valmis/.dockerignore`

````text
# Oikeaa sovellusdataa tai väliaikaisia testikopioita ei pakata imageen.
data
# Tietokantatiedostot jätetään pois myös silloin, jos ne on luotu vahingossa väärään kansioon.
*.sqlite*
# Paikallista asetus- ja salaisuustiedostoa ei saa kopioida imageen.
.env
# Versionhallinnan sisäistä historiaa ei tarvita ajettavaan konttiin.
.git
# Editorin paikalliset asetukset eivät kuulu ajettavaan sovellukseen.
.vscode
````

## 12.11 Koko materiaalipaketin versionhallinnan rajaus

### `.gitignore`

````text
# Paikalliset salaisuudet eivät kuulu versionhallintaan; mallipohja saa kuulua.
.env
.env.*
!.env.example
# Harjoittelussa syntyvät SQLite-tiedostot ja niiden apuosat eivät ole lähdekoodia.
*.sqlite
*.sqlite-*
*.db
*.db-*
# Valmiin esimerkin ajonaikaiset tiedot ja testien väliaikaiset hakemistot.
**/data/
# Käyttöjärjestelmän omia hakemistonäkymän asetuksia ei tarvita palautuksessa.
.DS_Store
Thumbs.db
````
